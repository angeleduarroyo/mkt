# coding=utf-8
from pyspark.sql.functions import col as c
from pyspark.sql.window import Window
import pyspark.sql.functions as f
from datetime import date, timedelta, datetime
from pyspark.sql.types import IntegerType
from pyspark.sql.functions import lit, udf, concat


class Fide(object):

"""
    Class that contains function to  process and analize the FIDE table    -
    -
    """

    def __init__(self):
        self.name = "FIDE Analyzer"
        self.information_user_table = None

    @staticmethod
    def get_delta_amount(fide):
        field = "punctual_balance_amount"
        order_columns = ["customer_id", "information_date"]
        window_group = Window.partitionBy("customer_id").orderBy(*order_columns)
        fide = fide.withColumn("delta_amount", (c(field) - f.lag(c(field)).over(window_group)))
        return fide.where(c("delta_amount") > 300)

    @staticmethod
    def get_delta_days(fide):
        field = "information_date"
        order_columns = ["customer_id", "information_date"]
        substract = udf(lambda x, y: (x-y).days if y is not None else None, IntegerType())
        window_group = Window.partitionBy("customer_id").orderBy(*order_columns)
        return fide.withColumn("delta_days", substract(c(field), f.lag(c(field)).over(window_group)))

    @staticmethod
    def get_delta_periodicity(fide):
        fide_max_days = fide.groupBy("customer_id").agg(f.max("delta_days").alias("delta_max"))
        conditional_days = udf(lambda days: 7 if days <= 7 else (15 if days <= 15 else 30), IntegerType())
        fide_max_delta = fide.join(fide_max_days, "customer_id").where(c("delta_max") == c("delta_days"))
        fide_result = fide_max_delta.groupBy("customer_id").agg(f.max("information_date").alias("max_date"),
                                                                f.avg("delta_max").alias("delta_max"))
        return fide_result.withColumn("delta_max", conditional_days(c("delta_max")))

    def get_periodicity(self, fide):
        fide_amount = self.get_delta_amount(fide)
        fide_days = self.get_delta_days(fide_amount)
        return self.get_delta_periodicity(fide_days)

    def get_user_table(self, fide, predict_date):
        days_after_friday = predict_date.weekday() - 4
        if days_after_friday > 0:
            predict_date = predict_date - timedelta(days=days_after_friday)
            print "Date to predict is on weekend. Taking nearest friday"
        first_day_month = date(predict_date.year, predict_date.month, 1)
        filtered_fide = fide.where(c("information_date") == predict_date).\
            select("customer_id", "punctual_balance_amount", "credit_balance_amount")
        return filtered_fide.join(self.information_user_table, "customer_id", "left_outer").na.fill({'delta_max': 30})\
            .withColumn("max_date", f.when(c("max_date").isNotNull(), c("max_date")).otherwise(first_day_month))

    @staticmethod
    def get_rest_days(fide, start_date):
        rest_days = udf(lambda date_begin, date_max, periodicity: periodicity - (((datetime.strptime(date_begin,
                                                                                                     "%Y-%m-%d").date())
                                                                                  - date_max).days % periodicity),
                        IntegerType())
        return fide.withColumn("rest_days", rest_days(f.lit("{}".format(start_date)), c("max_date"), c("delta_max")))

    def fit(self, fide):
        self.information_user_table = self.get_periodicity(fide).cache()

    @staticmethod
    def classify_by_product_catalog(fide, tla451):
        clean_fide = fide.withColumn("full_cd_prod", concat(c("product_type"), lit(""), c("subproduct_type"))).\
            where((c('full_cd_prod').isNotNull()))

        complete_view = (f.col("NB_ETIQ_VIN").like("%CHEQUES%") |
                         f.col("NB_ETIQ_VIN").like("%LIBRETON%") |
                         f.col("NB_ETIQ_VIN").like("%LIB_NOM%") |
                         f.col("NB_ETIQ_VIN").like("%TARJ_NOM%") |
                         f.col("NB_ETIQ_VIN").like("%TARJ_PREP%") |
                         f.col("NB_ETIQ_VIN").like("%CTA_EXPRESS%") |
                         f.col("NB_ETIQ_VIN").like("%TDD_NEG%") |
                         f.col("NB_ETIQ_VIN").like("%CAPTA_BCI%") |
                         f.col("NB_ETIQ_VIN").like("%AGEN_VISTA%"))
        complete_term = (f.col("NB_ETIQ_VIN").like("%PLAZO_BASICO%") |
                         f.col("NB_ETIQ_VIN").like("%SEG_METASEGURA%") |
                         f.col("NB_ETIQ_VIN").like("%PLAZO_DIVER%") |
                         f.col("NB_ETIQ_VIN").like("%NOTAS_ESTRUC%") |
                         f.col("NB_ETIQ_VIN").like("%ILP%") |
                         f.col("NB_ETIQ_VIN").like("%PLAZO_AGENCIA%"))
        complete_saving = f.col("NB_ETIQ_VIN").like("%META_AHORRO%")
        complete_fund = (f.col("NB_ETIQ_VIN").like("%FONDO_CORTO%") |
                         f.col("NB_ETIQ_VIN").like("%FONDO_LARGO%") |
                         f.col("NB_ETIQ_VIN").like("%FONDO_COBERTURA%") |
                         f.col("NB_ETIQ_VIN").like("%FONDO_RVN%") |
                         f.col("NB_ETIQ_VIN").like("%FONDO_RVI%") |
                         f.col("NB_ETIQ_VIN").like("%FONDO_DIVER%"))
        complete_capting = (f.col("NB_ETIQ_VIN").like("%MCAP%") |
                            f.col("NB_ETIQ_VIN").like("%MDIN%") |
                            f.col("NB_ETIQ_VIN").like("%FIDEICOMISOS%") |
                            f.col("NB_ETIQ_VIN").like("%FX%"))

        complete_credit = (f.col("NB_ETIQ_VIN").like("%TDC_AZUL%") |
                           f.col("NB_ETIQ_VIN").like("%TDC_ORO%") |
                           f.col("NB_ETIQ_VIN").like("%TDC_CONGELADA%") |
                           f.col("NB_ETIQ_VIN").like("%TDC_EDUCACION%") |
                           f.col("NB_ETIQ_VIN").like("%TDC_MICRONEGOCIO%") |
                           f.col("NB_ETIQ_VIN").like("%TDC_RAYADOS%") |
                           f.col("NB_ETIQ_VIN").like("%TDC_BANCARIA%") |
                           f.col("NB_ETIQ_VIN").like("%TDC_PLATINUM%") |
                           f.col("NB_ETIQ_VIN").like("%TDC_CORPORATIVA%") |
                           f.col("NB_ETIQ_VIN").like("%TDC_EMPRESARIAL%") |
                           f.col("NB_ETIQ_VIN").like("%TDC_NEGOCIO%") |
                           f.col("NB_ETIQ_VIN").like("%CRED_LIQUIDO%") |
                           f.col("NB_ETIQ_VIN").like("%TDC_GARANTIZADA%") |
                           f.col("NB_ETIQ_VIN").like("%TDC_IPN%") |
                           f.col("NB_ETIQ_VIN").like("%TDC_UNAM%") |
                           f.col("NB_ETIQ_VIN").like("%CAPITAL_TRABAJO%") |
                           f.col("NB_ETIQ_VIN").like("%TDC_INFINITE%") |
                           f.col("NB_ETIQ_VIN").like("%CRED_PROVE%"))
        complete_other_credit = (f.col("NB_ETIQ_VIN").like("%CRED_AMCT%") |
                                 f.col("NB_ETIQ_VIN").like("%BILATERALES%") |
                                 f.col("NB_ETIQ_VIN").like("%SINDICADOS%") |
                                 f.col("NB_ETIQ_VIN").like("%COMERCIO_EXT%") |
                                 f.col("NB_ETIQ_VIN").like("%RIESGO_CONT%") |
                                 f.col("NB_ETIQ_VIN").like("%CRED_AMEQ%") |
                                 f.col("NB_ETIQ_VIN").like("%CRED_ARRE%") |
                                 f.col("NB_ETIQ_VIN").like("%PREST.PPI%") |
                                 f.col("NB_ETIQ_VIN").like("%PREST.NOMINA%") |
                                 f.col("NB_ETIQ_VIN").like("%PREST.OTROS%") |
                                 f.col("NB_ETIQ_VIN").like("%PREST.TRADIC%") |
                                 f.col("NB_ETIQ_VIN").like("%PREST.AUTO%") |
                                 f.col("NB_ETIQ_VIN").like("%PREST.VIVIENDA%"))
        complete_insurance = (f.col("NB_ETIQ_VIN").like("%SEG_VIDA%") |
                              f.col("NB_ETIQ_VIN").like("%SEG_ACCIDENTES Y ENF%") |
                              f.col("NB_ETIQ_VIN").like("%SEG_SALUD%") |
                              f.col("NB_ETIQ_VIN").like("%SEG_AUTO%") |
                              f.col("NB_ETIQ_VIN").like("%SEG_DAÑOS%"))
        complete_services = (f.col("NB_ETIQ_VIN").like("%DOM_SERV%") |
                             f.col("NB_ETIQ_VIN").like("%SERV_NEG%") |
                             f.col("NB_ETIQ_VIN").like("%DOM_TDC%") |
                             f.col("NB_ETIQ_VIN").like("%BCOM%") |
                             f.col("NB_ETIQ_VIN").like("%LINEA_BMR%") |
                             f.col("NB_ETIQ_VIN").like("%CASH_WINDOWS%") |
                             f.col("NB_ETIQ_VIN").like("%SMBS%") |
                             f.col("NB_ETIQ_VIN").like("%BANCA_MOVIL%") |
                             f.col("NB_ETIQ_VIN").like("%WALLET%") |
                             f.col("NB_ETIQ_VIN").like("%ALERTA_ELEC%") |
                             f.col("NB_ETIQ_VIN").like("%DISP_NOMINA%") |
                             f.col("NB_ETIQ_VIN").like("%ATM%") |
                             f.col("NB_ETIQ_VIN").like("%DISPERSIÓN%") |
                             f.col("NB_ETIQ_VIN").like("%SOLN_ESP%") |
                             f.col("NB_ETIQ_VIN").like("%MEM_PYME%") |
                             f.col("NB_ETIQ_VIN").like("%COBR_ELEC%") |
                             f.col("NB_ETIQ_VIN").like("%COBR_ELEC_MP%") |
                             f.col("NB_ETIQ_VIN").like("%COBR_EFEC%") |
                             f.col("NB_ETIQ_VIN").like("%DEM%") |
                             f.col("NB_ETIQ_VIN").like("%COBR_DOC%") |
                             f.col("NB_ETIQ_VIN").like("%COBR_MULT%"))
        filtered_catalog = tla451.select(
            f.col("CD_PRODUCTO").alias("full_cd_prod"), f.when(complete_view, f.lit("VISTA")).otherwise(
                f.when(complete_term, f.lit("PLAZO")).otherwise(
                    f.when(complete_saving, f.lit("META_AHORRO")).otherwise(
                        f.when(complete_fund, f.lit("FONDO")).otherwise(
                            f.when(complete_capting, f.lit("CAPTA_OTROS")).otherwise(
                                f.when(complete_credit, f.lit("TDC_REV")).otherwise(
                                    f.when(complete_other_credit, f.lit("OTROS_CRED")).otherwise(
                                        f.when(complete_insurance, f.lit("SEGUROS")).otherwise(
                                            f.when(complete_services, f.lit("DOM_Y_SERV")).otherwise(
                                                f.lit("NONE")
                                            )
                                        )
                                    )
                                )
                            )
                        )
                    )
                )
            ).alias("label")
        )
        filtered_clean_fide = clean_fide.join(filtered_catalog, "full_cd_prod", "left_outer")
        # Aggregating by products
        punctual_balance_group = ["META_AHORRO", "PLAZO", "VISTA", "CAPTA_OTROS", "FONDO"]
        expired_balance_group = ["OTROS_CRED", "TDC_REV", "NONE", "SEGUROS", "DOM_Y_SERV"]
        agregation_group = [
                               f.sum(f.when(c("label") == x, c("punctual_balance_amount")).otherwise(0)).
                                   alias(x + "_punctual_balance_amount") for x in punctual_balance_group
                           ]+[
                               f.sum(f.when(c("label") == x, c("current_balance_amount")).otherwise(0)).
                                   alias(x+"_current_balance_amount") for x in expired_balance_group
                           ]+[
                               f.sum(f.when(c("label") == x, c("overdue_amount")).otherwise(0)).
                                   alias(x+"_overdue_amount") for x in expired_balance_group
                           ]+[
                               f.sum(f.when(c("label") == x, c("credit_balance_amount")).otherwise(0)).
                                   alias(x+"_credit_balance_amount") for x in expired_balance_group
                           ]
        aggregated_fide = filtered_clean_fide.groupBy(
            "customer_id", "information_date").agg(*agregation_group).orderBy("customer_id", "information_date").cache()
        # Dataframe with product classification
        classified_fide = aggregated_fide.select("customer_id", "information_date",
                                                 (c("META_AHORRO_punctual_balance_amount") +
                                                  c("PLAZO_punctual_balance_amount") +
                                                  c("VISTA_punctual_balance_amount") +
                                                  c("CAPTA_OTROS_punctual_balance_amount") +
                                                  c("FONDO_punctual_balance_amount")).alias("punctual_balance_amount"),
                                                 (c("OTROS_CRED_current_balance_amount") +
                                                  c("TDC_REV_current_balance_amount") +
                                                  c("SEGUROS_current_balance_amount") +
                                                  c("DOM_Y_SERV_current_balance_amount") +
                                                  c("OTROS_CRED_overdue_amount") +
                                                  c("TDC_REV_overdue_amount") +
                                                  c("SEGUROS_overdue_amount") +
                                                  c("DOM_Y_SERV_overdue_amount")).alias("credit_balance_amount"),
                                                 ((c("META_AHORRO_punctual_balance_amount") +
                                                   c("PLAZO_punctual_balance_amount") +
                                                   c("VISTA_punctual_balance_amount") +
                                                   c("CAPTA_OTROS_punctual_balance_amount") +
                                                   c("FONDO_punctual_balance_amount")) -
                                                  (c("OTROS_CRED_current_balance_amount") +
                                                   c("TDC_REV_current_balance_amount") +
                                                   c("SEGUROS_current_balance_amount") +
                                                   c("DOM_Y_SERV_current_balance_amount") +
                                                   c("OTROS_CRED_overdue_amount") +
                                                   c("TDC_REV_overdue_amount") +
                                                   c("SEGUROS_overdue_amount") +
                                                   c("DOM_Y_SERV_overdue_amount"))).alias("balance")
                                                 )
        return classified_fide

    def predict(self, fide, tla451, predict_date):
        """
            Predict  the amount between date_begin and date_end
            Returns two data frames
            Example:
        """
        fide_to_predict = self.get_user_table(self.classify_by_product_catalog(fide, tla451), predict_date)
        return self.get_rest_days(fide_to_predict, predict_date)
