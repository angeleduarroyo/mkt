# coding=utf-8
from pyspark.sql.functions import col as c
from analytic_utils import AnalyticUtils
import conf.tla018_schema as tla018
import conf.tla026_schema as tla026
import conf.tla117_schema as tla117
import conf.tla1199_schema as tla1199
import conf.tla1872_schema as tla1872
import conf.tmlara14_schema as tmlara14


class TableLoader:
    """
    This class containst all functinos that  load tables and process them in order to have all the necesary fields or variables
    for model
    """



    def __init__(self, paths):
        """
        Constructor, initialize all paths and fields tables variables.

        Fields tables come from separated Schemas:
        conf/tla018_schema.py
        conf/tla026_schema.py
        conf/tla117_schema.py
        conf/tla1199_schema.py
        conf/tla1872_schema.py
        conf/tmlara14_schema.py




        :param paths: path tables
        """

        self.tla117_fields = tla117.net_balance_fields
        self.tla117_target_fields = tla117.target_fields
        self.tla1872_fields = tla1872.fields
        self.tmlara14_fields = tmlara14.fields
        self.tla018_fields = tla018.fields
        self.tla026_fields = ["*"]
        self.tla1199_fields = ["*"]

        self.tla117_path = paths['tla117_path']
        self.tla1872_path = paths['tla1872_path']
        self.tmlara14_path = paths['tmlara14_path']
        self.tla018_path = paths['tla018_path']
        self.tla026_path = paths['tla026_path']
        self.tla1199_path = paths['tla1199_path']
        self.tla451_path = paths['tla451_path']

        self.utils = AnalyticUtils()

    def load_tla018_data(self, sql_context):
        print "Loading TLA018..."
        table_data = sql_context.read.parquet(self.tla018_path).select(self.tla018_fields)
        print "Done"
        return table_data

    def load_tla026_data(self, sql_context, dates):
        print "Loading TLA026..."
        table_data, latest_date = self.utils.unify_partitioned_table(sql_context, self.tla026_path,
                                                                     tla026.information_date, dates['sn_inicio_fides'],
                                                                     dates['sn_fin_fides'], 'day', self.tla026_fields)
        table_data = table_data.where(c(tla026.information_date) == latest_date)
        print "Done"
        return table_data, latest_date

    def load_tla1199_data(self, sql_context, dates):
        print "Loading TLA1199..."
        table_data = self.utils.unify_partitioned_table(sql_context, self.tla1199_path, tla1199.information_date,
                                                        dates['sn_inicio_fides'], dates['sn_fin_fides'],
                                                        'day', self.tla1199_fields)[0]
        print "Done"
        return table_data

    def load_tla451_data(self, sql_context):
        print "Loading TLA451..."
        table_data = sql_context.read.parquet(self.tla451_path)
        print "Done"
        return table_data

    def load_tmlara14_data(self, sql_context, dates):
        print "Loading TMLARA14..."
        table_data, latest_date = self.utils.unify_partitioned_table(sql_context, self.tmlara14_path,
                                                                     tmlara14.transaction_date, dates['sn_inicio'],
                                                                     dates['sn_fin'], 'day', self.tmlara14_fields)
        print "Done"
        return table_data, latest_date

    def load_tla1872_data(self, sql_context, dates):
        print "Loading TLA1872..."
        table_data, latest_date = self.utils.unify_partitioned_table(sql_context, self.tla1872_path,
                                                                     tla1872.operation_date, dates['sn_inicio'],
                                                                     dates['sn_fin'], 'day', self.tla1872_fields)
        print "Done"
        return table_data, latest_date

    def load_net_balance_tables(self, sql_context, act_date, time_frame, lost_months, fide_time_frame):

        generated_dates = self.utils.generate_dates(act_date, time_frame, lost_months, fide_time_frame, "sn")
        print generated_dates

        tla018_data = self.load_tla018_data(sql_context)
        tla026_data, latest_tla026_date = self.load_tla026_data(sql_context, generated_dates)
        tla1199_data = self.load_tla1199_data(sql_context, generated_dates)
        tla451_data = self.load_tla451_data(sql_context)
        tmlara14_data, latest_tmlara14_date = self.load_tmlara14_data(sql_context, generated_dates)
        tla1872_data, latest_tla1872_date = self.load_tla1872_data(sql_context, generated_dates)

        return tmlara14_data, tla018_data, tla1872_data, tla1199_data, tla026_data, tla451_data, \
               latest_tla1872_date, latest_tla026_date
