
def read_text_file(spark,path):
    sc = spark.sparkContext
    sc.setLogLevel("DEBUG")
    rdd = sc.textFile(path)
    return rdd