import pyspark.sql.types as types
from datetime import datetime
from pyspark.sql.functions import udf


class AnalyticUtils:
    """ This is de AnalyticUtils component

    contains auxiliar methods used by Analytical Base Table Job 
    """

    """Constructor, initialize all the attribute variables
    """
    def __init__(self):
        pass

    """ Persist a DataFrame as Parquet in a specific HDFS URL
        Args:
            dataFrame: dataframe to be saved
            fileName: path
    """
    def persistDataFrameAsParquet(self, dataFrame, fileName):

        dataFrame.write.mode('overwrite').parquet(fileName)

    """Load DataFrame from a path using the sqlContext.
   
       Args:
            delimiter -- the delimiter of the table file (default ',')
            tableSchema -- the schema the table will adopt (default None): automaticaly infer the schema
    """
    def loadDF(self, sqlContext, tablePath, delimiter=",", tableSchema=None):
        print(tablePath)

        if (tableSchema == None):
            return sqlContext.read.format('com.databricks.spark.csv') \
                .option("delimiter", delimiter) \
                .options(header='true', inferschema='true') \
                .load(tablePath)
        return sqlContext.read.format('com.databricks.spark.csv') \
            .option("delimiter", delimiter) \
            .options(header='true') \
            .load(tablePath, schema=tableSchema)

    toDateUDF = udf(lambda value, dateFormat: datetime.strptime(str(value), dateFormat), types.DateType())
