import time
import sys
import conf.module as this_module
import utils.common_utils
from datetime import date
from utils.spark.spark_utils import get_spark_session
from mkt_eventos.net_balance.launch_job import NetBalanceJob


if __name__ == "__main__":
    # Initialize Spark Session
    spark_session = get_spark_session()

    # Initialize job
    model_name = this_module.MODEL_NAME
    job_name = this_module.JOB_NAME
    module_name = utils.common_utils.init_job(model_name, job_name)

    # Start time measure
    start_time = time.time()
    activation_date = date.today()

    # Load parameters file
    parameters_file_url = sys.argv[1]
    job_parameters = utils.common_utils.load_params(parameters_file_url)

    # Pass a Spark object and params to module here
    net_balance_process = NetBalanceJob()
    net_balance_process.start(activation_date, parameters_file_url, spark_session)

    # Finish job
    utils.common_utils.finish_job(module_name, start_time)

    # Stop Spark Session
    spark_session.stop()
