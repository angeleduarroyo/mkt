import unittest
import json

from main.DatioGaranti.TrainingJob.GarantiTrainingJob import GarantiTrainingJob
from main.DatioGaranti.commons.init_spark_session import spark_session
from pyspark.sql import SQLContext


class TestGarantiTrainingJob(unittest.TestCase):

    @staticmethod
    def make_test_parameters(path):
        with open(path) as params_json:
            params_dict = json.load(params_json)
        return params_dict

    def make_test_instance(self):
        test_params = self.make_test_parameters('tests/python/data/test_expected_params.json')
        test_hash = "31282017075f540c304c047a85cce12d172d84934c691c419cf5b83a8144ca884cda119b"
        test_instance = GarantiTrainingJob(test_params, test_hash)
        return test_instance

    def test_error_init(self):
        test_params = {"fractions": {0: 1.0, 1: 1.0}}
        test_hash = "31282017075f540c304c047a85cce12d172d84934c691c419cf5b83a8144ca884cda119b"
        test_instance = GarantiTrainingJob(test_params, test_hash)
        return test_instance

    def test_loadABT(self):
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_test_instance()
        test_instance.loadABT(test_sql_context)
        test_full_abt = test_instance.completeDataSetDF
        self.assertIsNotNone(test_full_abt)

    def test_startTraining(self):
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_test_instance()
        test_instance.loadABT(test_sql_context)
        test_model = test_instance.startTraining()
        self.assertIsNotNone(test_model)

    def test_startTesting(self):
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_test_instance()
        test_instance.loadABT(test_sql_context)
        test_instance.startTraining()
        test_result = test_instance.startTesting()
        self.assertIsNotNone(test_result)

    def test_persistModel(self):
        sc = spark_session()
        test_sql_context = SQLContext(sc.sparkContext)
        test_instance = self.make_test_instance()
        test_instance.loadABT(test_sql_context)
        test_instance.startTraining()
        print(type(sc.sparkContext))
        test_path = test_instance.persistModel(sc.sparkContext, "testing")
        self.assertIsInstance(test_path, basestring)

    def test_persistModelTest(self):
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_test_instance()
        test_instance.loadABT(test_sql_context)
        test_instance.startTraining()
        test_model = test_instance.startTesting()
        test_path = test_instance.persistModelTest(test_model, "train")
        self.assertIsInstance(test_path, basestring)


if __name__ == '__main__':
    unittest.main()
