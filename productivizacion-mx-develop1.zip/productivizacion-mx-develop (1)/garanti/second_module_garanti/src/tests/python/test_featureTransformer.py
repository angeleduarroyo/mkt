import unittest

from main.DatioGaranti.TrainingJob.GarantiUtils.InputUtils import InputUtils
from main.DatioGaranti.TrainingJob.FeatureTransformer import FeatureTransformer
from main.DatioGaranti.TrainingJob.spark_utils.readers import parquet
from main.DatioGaranti.commons.init_spark_session import spark_session
from pyspark.sql import SQLContext


class TestFeatureTransformer(unittest.TestCase):

    @staticmethod
    def make_test_instance():

        test_instance = FeatureTransformer(InputUtils.ABTColumnId,InputUtils.ABTColumnLabel, InputUtils.ABTColumnsToTransform, 0, 1)
        return test_instance

    @staticmethod
    def make_test_dataframe():
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_dataframe = parquet.read_parquet_file(test_sql_context,
                                                   'tests/python/data/garanti_abt'
                                                   ).dropna('any').select(InputUtils.ABTInputScheme)
        return test_dataframe

    def test_transform(self):
        test_instance = self.make_test_instance()
        test_dataframe = self.make_test_dataframe()
        test_result = test_instance.transform(test_dataframe)
        self.assertIsNotNone(test_result)


if __name__ == '__main__':
    unittest.main()
