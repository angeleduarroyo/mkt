class DateUtils:
    """

    """

    def __init__(self, target_year, target_month, month_window_before_1, month_window_before_2, month_window_after):
        if (isinstance(target_year, int)) & (isinstance(target_month, int)) & \
                (isinstance(month_window_before_1, int)) & (isinstance(month_window_before_2, int)) & \
                (isinstance(month_window_after, int)):

            if (target_year >= 1) & (target_month >= 1) & (target_month <= 12) & \
                    (month_window_before_1 >= 0) & (month_window_before_2 >= 0) & (month_window_after >= 0):
                self.month_before_1 = target_month - month_window_before_1
                self.month_before_2 = target_month - month_window_before_2
                self.month_after = target_month + month_window_after

                self.year_before_1 = target_year
                self.year_before_2 = target_year
                self.year_after = target_year

                while self.month_before_1 < 1:
                    self.year_before_1 -= 1
                    self.month_before_1 += 12

                while self.month_before_2 < 1:
                    self.year_before_2 -= 1
                    self.month_before_2 += 12

                while self.month_after > 12:
                    self.year_after += 1
                    self.month_after -= 12

            else:
                raise ValueError('Invalid values')

        else:
            raise ValueError('Invalid arguments')

    def year_before_1(self):
        return self.year_before_1

    def month_before_1(self):
        return self.month_before_1

    def year_before_2(self):
        return self.year_before_2

    def month_before_2(self):
        return self.month_before_2

    def year_after(self):
        return self.year_after

    def month_after(self):
        return self.month_after
