import json

class TestDatio(object):
    def __init__(self):
        self.errors = None
        self.missing = None

    def compareSchema(self, df, schema_comp):
        jschemaDF = json.loads(df.schema.json())
        squemaDF = {x["name"]:x["type"] for x in jschemaDF["fields"]}
        if(squemaDF == schema_comp):
            return True
        else:
            arr_missing = {x[0]:x[1] for x in set(schema_comp.items()) - set(squemaDF.items())}
            arr_error = {x[0]:x[1] for x in set(squemaDF.items()) - set(schema_comp.items())}
            self.errors = arr_error
            self.missing = arr_missing
            return False