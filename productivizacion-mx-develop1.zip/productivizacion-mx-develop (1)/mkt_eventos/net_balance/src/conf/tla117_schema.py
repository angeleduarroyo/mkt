"""
    Script for TLA117 scheme
"""

customer_id = "customer_id"
accounts_number = "accounts_number"
average_balance_amount = "average_balance_amount"
punctual_balance_amount = "punctual_balance_amount"
credit_card_status_type = "credit_card_status_type"
statement_balance_amount = "statement_balance_amount"
statement_finanzia_cards_amount = "statement_finanzia_cards_amount"
credit_limit_amount = "credit_limit_amount"
credit_limit_finanzia_amount = "credit_limit_finanzia_amount"
cards_number = "cards_number"
bank_credit_cards_number = "bank_credit_cards_number"
frozen_credit_cards_number = "frozen_credit_cards_number"
finanzia_cards_number = "finanzia_cards_number"
car_loans_accounts_number = "car_loans_accounts_number"
mortgage_accounts_number = "mortgage_accounts_number"
payroll_loan_accounts_number = "payroll_loan_accounts_number"
personal_loans_number = "personal_loans_number"
linea_bancomer_type = "linea_bancomer_type"
bmovil_type = "bmovil_type"
bcom_type = "bcom_type"
customer_products_number = "customer_products_number"

# Target fields (besides 'customer_id')
average_essential_fund_amount = "average_essential_fund_amount"
average_advanced_fund_amount = "average_advanced_fund_amount"
average_select_fund_amount = "average_select_fund_amount"
average_fr_fund_amount = "average_fr_fund_amount"
average_vr_fund_amount = "average_vr_fund_amount"
average_cm_fund_amount = "average_cm_fund_amount"
average_mm_fund_amount = "average_mm_fund_amount"
average_fc_fund_amount = "average_fc_fund_amount"


net_balance_fields = [customer_id, accounts_number, average_balance_amount, punctual_balance_amount,
                      credit_card_status_type, statement_balance_amount, statement_finanzia_cards_amount,
                      credit_limit_amount, credit_limit_finanzia_amount, cards_number, bank_credit_cards_number,
                      frozen_credit_cards_number, finanzia_cards_number, car_loans_accounts_number,
                      mortgage_accounts_number, payroll_loan_accounts_number, personal_loans_number,
                      linea_bancomer_type, bmovil_type, bcom_type, customer_products_number]
target_fields = [customer_id, average_essential_fund_amount, average_advanced_fund_amount, average_select_fund_amount,
                 average_fr_fund_amount, average_vr_fund_amount, average_cm_fund_amount, average_mm_fund_amount,
                 average_fc_fund_amount]
