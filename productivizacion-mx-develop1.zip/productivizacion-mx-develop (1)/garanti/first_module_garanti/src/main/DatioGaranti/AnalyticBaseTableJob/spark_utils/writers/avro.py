
def save_avro_file(df,path):
    return df.write.format('com.databricks.spark.avro').mode("overwrite").save(path)