# coding=utf-8
from pyspark.sql.functions import col as c
from pyspark.sql.window import Window
import pyspark.sql.functions as f
from datetime import timedelta, datetime
from dateutil.relativedelta import relativedelta
from pyspark.sql.types import IntegerType, DateType, FloatType
from pyspark.sql.functions import desc, udf
from scipy.stats import chi2
import conf.tmlara14_schema as tmlara14
import conf.tla018_schema as tla018


def put_average_delta_rows(transactions_data, columns_group, field):
    average_customer = transactions_data.groupBy(*columns_group).agg(f.avg(field).alias("delta_avg"),
                                                                     f.stddev(field).alias("delta_std"),
                                                                     f.count("*").alias("num_rows")
                                                                     )
    transactions_data = transactions_data.join(average_customer, columns_group, how="inner")
    return transactions_data


def get_date_delta(transactions_data, columns_group, field):
    order_columns = columns_group + [field]
    window_group = Window.partitionBy(*columns_group).orderBy(*order_columns)
    window_group_desc = Window.partitionBy(*columns_group).orderBy(desc(order_columns[-1], *(order_columns[:-1])))
    select_fields = [c(column) for column in transactions_data.columns]+[
        f.lag(transactions_data[field]).over(window_group).alias('prev_' + field),
        f.first(transactions_data[field]).over(window_group).alias('max_' + field),
        f.row_number().over(window_group_desc).alias("row_n")
    ]
    transactions_data = transactions_data.select(*select_fields).where(c("row_n") <= 14).drop("row_n")
    subtraction = udf(lambda x, y: (x-y).days if y is not None else None, IntegerType())
    transactions_data = transactions_data.withColumn('delta_' + field, subtraction(c(field), c('prev_' + field)))
    return transactions_data


def put_sum_delta_error(transaction_data, columns_group, field):
    select_fields = [c(column) for column in transaction_data.columns]+[
        f.sum(c(field)).over(Window.partitionBy(*columns_group)).alias("sum_delta"),
        f.row_number().over(Window.partitionBy(*columns_group).orderBy(f.desc("transaction_date"), *columns_group))
            .alias("row_number")
    ]
    transaction_data = transaction_data.select(*select_fields)
    return transaction_data


class Tmlara14Recurrency(object):
    """
    Class that contains function to  process and analize Tmlara14 table    -
    -
    """

    def __init__(self):
        self.col_tmlara14 = None
        self.avg_delta_tmlara14 = None
        self.std_avg_delta_tmlara14 = None
        self.goodness_tmlara = None
        self.client_tmlara = None
        self.final_date = None
        self.client_tmlara14_data = None
        self.no_recurrency_tmlara14_data = None

    @staticmethod
    def check_integrity_table(tmlara14_data, tla018_data, delta):
        """
         Verify  the existance of the fields in the tmlar14 and tla018, and also delta value mus be betwen 0-1
        :param tmlara14_data:
        :param tla018_data:
        :param delta:
        :return:
        """
        tmlara_columns_needed = [tmlara14.reference_number, tmlara14.channel_id, tmlara14.transaction_date,
                                 tmlara14.operation_amount, tmlara14.destiny_id, tmlara14.destiny_type,
                                 tmlara14.fuction_id, tmlara14.error_type, tmlara14.reverse_type]
        tla018_columns_needed = [tla018.transaction_id, tla018.group_name, tla018.platform_type]
        tmlara14_columns =  tmlara14_data.columns
        tla018_columns =  tla018_data.columns
        is_correct = True
        if delta >= 1 or delta <= 0:
            print "Delta value must be between 0-1"
            is_correct = False
            return is_correct

        for column in tmlara_columns_needed:
            if column not in tmlara14_columns:
                is_correct = False
                print tmlara14_columns
                print "Column: {}  not found".format(column)
        for column in tla018_columns_needed:
            if column not in tla018_columns:
                is_correct = False
                print tla018_columns
                print "Column: {}  not found".format(column)
        return is_correct

    @staticmethod
    def getting_user_active_and_util_transactions(tmlara14_data, tla018_data, final_date):
        """
            This function get only the transactions with an user active, for this task the function takes
            the last date in the sample TBL_VMLARA14
        """
        values_to_exclude=['ADMINISTRATIVA','SALDOS','SISTEMA','SISTEMAS','CONSULTA','VISTA', 'MOVIMIENTOS',
                           "TRASPASO CUENTAS PROPIAS"]
        successful_transactions = tmlara14_data.where((c(tmlara14.error_type).isNull()))
        three_months_back = final_date - relativedelta(months=3)
        active_users = successful_transactions.where((c(tmlara14.transaction_date) >= three_months_back) &
                                                     (c(tmlara14.operation_amount) > 0.0) &
                                                     (c(tmlara14.channel_id).isin('BNET','MBAN','SMSB')) &
                                                     (c(tmlara14.destiny_type) != 'None') &
                                                     (c(tmlara14.destiny_type).isNotNull()))\
            .select(tmlara14.reference_number).distinct()
        # Inner Join for drop users not actives
        record_tmlara = successful_transactions.join(active_users,tmlara14.reference_number).\
            select(tmlara14.reference_number, tmlara14.transaction_date, tmlara14.channel_id, tmlara14.operation_amount,
                   tmlara14.fuction_id, tmlara14.destiny_type, tmlara14.destiny_id, tmlara14.error_type,
                   tmlara14.reverse_type)
        work_tmlara = record_tmlara.join(
            tla018_data, record_tmlara[tmlara14.fuction_id]==tla018_data[tla018.transaction_id]).where(
            (c(tmlara14.channel_id).isin('BNET','MBAN','SMSB')) &
            (c(tla018.group_name).isin(values_to_exclude)==False) &
            (c(tmlara14.destiny_type).isNotNull()) &
            (c(tmlara14.operation_amount) > 0.0)
        ).select(tmlara14.reference_number, tmlara14.transaction_date, tmlara14.channel_id, tmlara14.operation_amount,
                 tmlara14.fuction_id, tla018.group_name, tmlara14.destiny_type, tla018.transaction_name,
                 tmlara14.destiny_id).distinct()
        return work_tmlara

    @staticmethod
    def filtering_transactions_by_newest(tmlara14_data, final_date):
        """
            This function filter transactions buffer that has less of 4 elements and  more of delta + 2 std in happened
        """
        route_function = udf(lambda end_date, standard_days, delta_avg, num_rows: (
            end_date - timedelta(days=int(delta_avg+(2*standard_days)))
        ) if num_rows > 2 else None, DateType())

        # This line create a column that has the value of permissible date
        std_avg_delta_tmlara = tmlara14_data.withColumn\
            ("range_date", route_function(f.lit(final_date), c("delta_std"), c("delta_avg"), c("num_rows")))
        # This line filter the transactions that has more of 4 rows and are happening in the last time
        filter_std_avg_delta_tmlara= std_avg_delta_tmlara.where((c("num_rows") >= 4) &
                                                                (c("max_transaction_date") >= c("range_date")))
        return filter_std_avg_delta_tmlara

    @staticmethod
    def get_discriminator(tmlara14_data):
        """
            Making a column that is the discriminator
            by default is equal to fuction_id
        """
        return tmlara14_data.withColumn("discriminator", c(tmlara14.fuction_id)).select(
            tmlara14.reference_number, "discriminator", tmlara14.transaction_date, tmlara14.operation_amount)

    @staticmethod
    def get_discriminator_2(tmlara14_data):
        """
            Making a column that is the discriminator_2
            by default is equal to fuction_id
        """
        return tmlara14_data.withColumn("discriminator", c(tmlara14.fuction_id)) \
            .groupBy(tmlara14.reference_number, tmlara14.transaction_date,"discriminator").agg(
            f.sum(tmlara14.operation_amount).alias("operation_amount"))

    @staticmethod
    def put_delta_and_metrics(tmlara14_data):
        # Getting days between transactions on buffer transactions
        delta_tmlara = get_date_delta(tmlara14_data, columns_group = ['reference_number','discriminator'],
                                           field = 'transaction_date')
        # Getting average of distance beetween transactions and getting num rows on buffers
        avg_delta_tmlara = put_average_delta_rows(delta_tmlara, ["reference_number","discriminator"],
                                                  "delta_transaction_date")
        return avg_delta_tmlara

    @staticmethod
    def get_goodness_fit(tmlara14_data, delta=0.7):
        """
            Make goodness Poisson proof for get only recurrent rows
        """
        # Defining lambda functions for goodness
        # Getting the buffer with max length
        # param depended of max num row
        max_rows = 16
        # Getting possible results
        chi2_array = ([0, 0, 0] + [float(chi2.isf(q=delta, df=(int(x)-2))) for x in range(3, max_rows+1)])
        subtraction_square = udf(lambda x,y:((x-y)*(x-y) )if x is not None and y is not None else None  , FloatType())
        metric = udf(lambda x,y: (x/y) if x is not None and y > 0 else None, FloatType())
        scoring = udf(lambda x,y,z: ((1 if x > y else 0) if x is not None and y is not None else None)
        if z > 2 else 0 , IntegerType())
        chi2_function = udf(lambda x: chi2_array[x] if x > 2 else None, FloatType())
        # Calculate de squared of the distance beetween delta and average delta ( x - x_avg)^2
        tmlara14_1 = tmlara14_data.withColumn('delta_error_squared',
                                              subtraction_square(c('delta_transaction_date'), c("delta_avg")))
        # Calculate the division between  (( x - x_avg)^2)/(x-media)
        tmlara14_2 = tmlara14_1.withColumn('delta_metric', metric(c('delta_error_squared'), c("delta_avg")))
        # Sum the error
        tmlara14_3 = put_sum_delta_error(tmlara14_2,["reference_number","discriminator"],"delta_metric")
        # Get the chi metric
        tmlara14_4 = tmlara14_3.withColumn('delta_chi2', chi2_function(c('num_rows')))
        # Make goodness proof and put 1 if passed and 0 if not passed
        tmlara14_5 = tmlara14_4.withColumn('target', scoring(c('delta_chi2'),c("sum_delta"),c('num_rows')))
        return tmlara14_5

    @staticmethod
    def reduce_by_client_and_discriminator(tmlara14_data):
        conditions = [
            f.avg(c("num_rows")).alias("num_rows"),
            f.avg(c("operation_amount")).alias("operation_amount"),
            f.stddev(c("operation_amount")).alias("std_oper"),
            f.avg(c("delta_avg")).alias("delta_avg"),
            f.avg(c("delta_std")).alias("delta_std"),
            f.first(c("max_transaction_date")).alias("max_transaction_date")
        ]
        customer_tmlara14 = tmlara14_data.where((c("target") == 1 ) & (c("row_number") <= 4)).\
            select(tmlara14.reference_number, "discriminator", tmlara14.transaction_date, "max_transaction_date",
                   tmlara14.operation_amount, "delta_avg", "delta_std", "num_rows").\
            groupBy(tmlara14.reference_number, "discriminator"
                    ).agg(*conditions)
        return customer_tmlara14

    @staticmethod
    def predict_recurrency(tmlara14_data, date_begin, date_end):
        """
            GETTING table for consume
        """
        # Get the amount only if is applicable in the date
        is_applicable = udf(
            lambda operation_amount, max_date, delta, delta_std, actual_date:
            operation_amount if
            ((datetime.strptime(actual_date, "%Y-%m-%d").date() - max_date).days % delta) < delta_std
            else 0.0, FloatType())
        activation_date = date_begin
        # Get expressions for the application and summary of the data in date
        aggregate_dates = []
        aggregate_sums = []
        while activation_date < date_end:
            aggregate_dates.append(is_applicable(c("operation_amount"), c("max_transaction_date"), c("delta_avg"),
                                                 c("delta_std"), f.lit("{}".format(activation_date))).
                                   alias("{}".format(activation_date)))
            aggregate_sums.append(f.sum("{}".format(activation_date)).alias("{}".format(activation_date)))
            activation_date = activation_date + timedelta(days = 1)
        # Applying the expressions
        dates_tmlara14 = tmlara14_data.select("*",*aggregate_dates)
        # Applying the expressions
        recurrency_amounts_tmlara14 = dates_tmlara14.groupBy("reference_number").agg(*aggregate_sums).cache()
        return recurrency_amounts_tmlara14

    @staticmethod
    def predict_recurrency_2(tmlara14_data, date_begin, date_end):
        """
            GETTING table for consume
        """
        def is_on_range(date_start, operation_amount, max_date, delta, delta_std, actual_date):
            actual =  datetime.strptime(actual_date, "%Y-%m-%d").date()
            begin =  datetime.strptime(date_start, "%Y-%m-%d").date()
            rest_days = (actual - max_date).days % delta
            rest_days = delta if rest_days == 0 else rest_days
            real_rest = int(delta - rest_days)
            if real_rest == int(2*delta_std):
                return operation_amount
            elif real_rest < 2*delta_std and begin == actual:
                return operation_amount
            elif real_rest >= (delta - 2*delta_std) and begin == actual:
                return operation_amount
            else:
                return 0.0

        # Get the amount only if is applicable in the date
        is_applicable = udf(is_on_range, FloatType())
        activation_date = date_begin
        # Getting the expressions for get the application and summarization of the data in date
        aggregate_dates = []
        aggregate_sums = []
        while activation_date < date_end:
            aggregate_dates.append(is_applicable(f.lit("{}".format(date_begin)),c("operation_amount"),
                                                 c("max_transaction_date"),c("delta_avg"), c("delta_std"),
                                                 f.lit("{}".format(activation_date)))
                                   .alias("{}".format(activation_date)))
            aggregate_sums.append(f.sum("{}".format(activation_date)).alias("{}".format(activation_date)))
            activation_date = activation_date + timedelta(days = 1)
        # Applying the expressions
        dates_tmlara14 = tmlara14_data.select("*",*aggregate_dates)
        # Applying the expressions
        recurrency_amounts_tmlara14 = dates_tmlara14.groupBy("reference_number").agg(*aggregate_sums).cache()
        return recurrency_amounts_tmlara14

    def recurrency_analysis(self, tmlara14_data, tla018_data, delta, final_date):
        """
            Make the process for create a Matrix recurrency
        """
        # Making column for discrimination
        self.col_tmlara14 = self.get_discriminator_2(tmlara14_data)
        # Getting average of distance beetween transactions and getting num rows on buffers
        self.avg_delta_tmlara14 = self.put_delta_and_metrics(self.col_tmlara14)
        # Getting the standart desviation and filtering dataFrame
        self.std_avg_delta_tmlara14 = self.filtering_transactions_by_newest(self.avg_delta_tmlara14,final_date)
        # Making goodness proof
        self.goodness_tmlara = self.get_goodness_fit(self.std_avg_delta_tmlara14,delta).cache()
        # Get recurrencies to client, discriminator level
        self.client_tmlara = self.reduce_by_client_and_discriminator(self.goodness_tmlara)
        return self.client_tmlara

    @staticmethod
    def remove_recurrency_transactions(tmlara14_data, recurrency_tlara14):
        """
            Remove recurrency transactions from full datasets
        """
        # Getting only recurrent clients with his 'fuction_id'
        recurrent_customers = recurrency_tlara14.select("reference_number", c("discriminator").alias("fuction_id"),
                                                        f.lit(1).alias("flag")).distinct()
        # Droppping recurrency transactions
        filter_tmlara = tmlara14_data.join(recurrent_customers,["reference_number","fuction_id"],
                                           "left_outer").where(c("flag").isNull()).drop("flag")
        return filter_tmlara

    @staticmethod
    def filter_value_transactions(tmlara14_data):
        """
            Filtering by group
        """
        # Only interesting groups
        groups = ["VENTA DE FONDOS","PAGO TDC INTERBANCARIAS","CHEQUE EN LINEA",
                  "DISPOSICION TDC","INTERBANCARIAS 24 HORAS","TRASPASO CUENTAS TERCEROS",
                  "PAGO DE IMPUESTOS","PAGO IMPUESTOS SAT",
                  'TRASPASO CUENTAS PROPIAS','PAGO TDC','INTERBANCARIAS MENORES',
                  'PAGO DE SERVICIOS','COMPRA TIEMPO AIRE']

        return tmlara14_data.where(c("group_name").isin(groups))

    @staticmethod
    def make_groups_by_groups(tmlara14_data):
        # Just only interesting groups
        groups = ["VENTA DE FONDOS","PAGO TDC INTERBANCARIAS","CHEQUE EN LINEA","DISPOSICION TDC",
                  "INTERBANCARIAS 24 HORAS","TRASPASO CUENTAS TERCEROS","PAGO DE IMPUESTOS","PAGO IMPUESTOS SAT",
                  'TRASPASO CUENTAS PROPIAS','PAGO TDC','INTERBANCARIAS MENORES',
                  'PAGO DE SERVICIOS','COMPRA TIEMPO AIRE']
        aggregations_group = [
                               f.sum("operation_amount").alias("im_diario"),
                               f.count("*").alias("num_diario"),
                           ] + [
                               f.sum(f.when(c("group_name") == group, c("operation_amount")).otherwise(0))
                                   .alias("im_"+group.replace(" ","_")) for group in groups
                           ] + [
                               f.sum(f.when(c("group_name") == group,1).otherwise(0)).
                                   alias("num_"+group.replace(" ","_")) for group in groups
                           ]
        return tmlara14_data.groupBy("reference_number","transaction_date").agg(*aggregations_group)

    @staticmethod
    def get_day_and_week_day(tmlara14_data):
        """
        Gets  day,  week  and month from transaction_day field
        :param tmlara14_data:
        :return:
        """

        get_day = udf(lambda d: d.day, IntegerType())
        get_week_day = udf(lambda d: d.weekday(), IntegerType())
        get_month = udf(lambda d: d.month, IntegerType())
        return tmlara14_data.select(get_day(c("transaction_date")).alias("day_trans"),
                                    get_week_day(c("transaction_date")).alias("weekday_trans"),
                                    get_month(c("transaction_date")).alias("month_number"), *tmlara14_data.columns
                                    )

    @staticmethod
    def get_average_days_2(tmlara14_data):
        """
            Get Min import by Month
        """
        aggregations_date = [(f.min("percentile_im")/30).alias("month_im")]
        group_date_group_tmlara = tmlara14_data.groupBy("reference_number").agg(*aggregations_date)
        return group_date_group_tmlara

    @staticmethod
    def get_average_days(tmlara14_data):
        """
            Get Average import on days and weekdays
        """
        aggregations_date = [
                              f.min("percentile_im").alias("percentile_im")
                          ]+[
                              f.sum("im_diario").alias("im_diario"),
                              f.count("*").alias("num_diario")
                          ]
        for x in range(1, 32):
            aggregations_date.append(
                f.sum(f.when(c("day_trans") == x, c("im_diario")).otherwise(0)).alias("im_day_"+str(x)))
            aggregations_date.append(
                f.sum(f.when(c("day_trans") == x, 1).otherwise(0)).alias("num_day_"+str(x))
            )
        for x in range(0, 7):
            aggregations_date.append(
                f.sum(f.when(c("weekday_trans") == x, c("im_diario")).otherwise(0)).alias("im_weekday_"+str(x)))
            aggregations_date.append(
                f.sum(f.when(c("weekday_trans") == x, 1).otherwise(0)).alias("num_weekday_"+str(x))
            )

        group_date_group_tmlara = tmlara14_data.groupBy("reference_number").agg(*aggregations_date)

        fields_amount = list(filter(lambda x: x.startswith("im_"),group_date_group_tmlara.columns))
        aggregation_median = [(f.when(c("num_"+x[3:]) != 0,(c(x)/c("num_"+x[3:]))).otherwise(0.0)).
                                 alias("prom_"+x[3:]) for x in fields_amount]
        # LUIS
        aggregation_median.append("reference_number")
        aggregation_median.append("percentile_im")
        aggregation_median.extend(group_date_group_tmlara.columns[2:])
        return group_date_group_tmlara.select(*aggregation_median)

    @staticmethod
    def get_percentile_no_recurrence_2(tmlara14_data):
        tmlara14_data_0 = tmlara14_data.groupBy("reference_number", "month_number").\
            agg(f.sum("im_diario").alias("im_diario"))
        reference_window = Window.partitionBy("reference_number").orderBy("im_diario")
        tmlara14_data_2 = tmlara14_data_0.withColumn("percentile", f.percent_rank().over(reference_window))
        customer_catalog = tmlara14_data_0.groupBy("reference_number").agg(f.count("*").alias("num_rows"))
        tmlara14_data_3 = tmlara14_data_2.join(customer_catalog, "reference_number", how="inner")
        return tmlara14_data_3.withColumn(
            "percentile_im", f.when(c("percentile") >= (1-(1/c("num_rows"))), c("im_diario")).otherwise(None))

    @staticmethod
    def get_percentile_no_recurrence(tmlara14_data):
        reference_window = Window.partitionBy("reference_number").orderBy("im_diario")
        tmlara14_data_2 = tmlara14_data.withColumn("percentile", f.percent_rank().over(reference_window))
        return tmlara14_data_2.withColumn("percentile_im",
                                          f.when(c("percentile") >= 0.85, c("im_diario")).otherwise(None))

    @staticmethod
    def predict_no_recurrency(tmlara14_data, date_begin, date_end):
        """
            GETTING table for consume
        """
        activation_date = date_begin
        aggregate_dates = []
        while activation_date < date_end:
            aggregate_dates.append(c("month_im").alias("{}".format(activation_date)))
            activation_date = activation_date + timedelta(days = 1)
        return tmlara14_data.select("reference_number", *aggregate_dates)

    def no_recurrency_analysis(self, tmlara14_data, tmlara14_data_recurrency):
        """
            This function returns the transactions that don't match with recurrent  cases
        """
        # Getting only the no recurrency transactions
        filtered_tmlara = self.remove_recurrency_transactions(tmlara14_data, tmlara14_data_recurrency).cache()
        # Just only interesting groups
        grouped_tmlara = self.filter_value_transactions(filtered_tmlara).cache()
        # Making aggregations by group
        amount_grouped_tmlara = self.make_groups_by_groups(grouped_tmlara).cache()
        # get Month number
        date_amount_grouped_tmlara= self.get_day_and_week_day(amount_grouped_tmlara).cache()
        # Get percentiles
        percentile_tmlara = self.get_percentile_no_recurrence_2(date_amount_grouped_tmlara)
        # Get import by Month percentile
        grouped_date_group_tmlara = self.get_average_days_2(percentile_tmlara).cache()
        return grouped_date_group_tmlara

    def fit(self, tmlara14_data, tla018_data, predict_date=None, delta=0.7):
        """
         Train the model for recurrent and no-recurrent analytic estimation using tmlara14_data and tla018_data
        """
        # Verifying integrity
        if not(self.check_integrity_table(tmlara14_data, tla018_data, delta)):
            print("Found errors")
            return 0
        # Getting last transaction
        if predict_date is None:
            self.final_date = tmlara14_data.select(f.max(tmlara14.transaction_date).alias("max")).collect()[0]["max"]
        else:
            self.final_date = predict_date
        # Filtering transactions by User active and util transactions
        user_tmlara14_data = self.getting_user_active_and_util_transactions(tmlara14_data, tla018_data,
                                                                            self.final_date).cache()
        # Getting dataframe for recurrency cases
        self.client_tmlara14_data = self.recurrency_analysis(user_tmlara14_data, tla018_data, delta,
                                                             self.final_date).cache()
        # Getting dataframe for no recurrency cases
        self.no_recurrency_tmlara14_data = self.no_recurrency_analysis(user_tmlara14_data,
                                                                       self.client_tmlara14_data).cache()
        return 1

    def predict(self, date_begin, date_end):
        """
            Predict  the amount between date_begin and date_end
            Returns two data frames
        """
        tmlara14_data_recurrency_amounts = self.predict_recurrency_2(self.client_tmlara14_data, date_begin, date_end)
        tmlara14_data_no_recurrency_amounts = self.predict_no_recurrency(self.no_recurrency_tmlara14_data,
                                                                         date_begin, date_end)
        return tmlara14_data_recurrency_amounts, tmlara14_data_no_recurrency_amounts
