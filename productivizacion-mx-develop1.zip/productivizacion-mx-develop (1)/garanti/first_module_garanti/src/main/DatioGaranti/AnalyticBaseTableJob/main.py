import hashlib
import json
from AnalyticBaseTableJob import AnalyticBaseTableJob
from GarantiUtils.DateUtils import DateUtils
from pyspark.sql.functions import lit
from pyspark.sql import HiveContext


class ABTmain:
    """ This is the main class for the ABT component
    """

    def __init__(self):
        """ Constructor, initialize the variables for the output paths of Training and Blind ABTs
            Args: none
        """
        self.final_abt = None
        self.run_id = None
        self.path = '/data/master/mpyt/data/garanti/t_mpyt_garanti_abt'

    @staticmethod
    def load_config_file(nexus_url):
        with open(nexus_url) as json_file:
            properties = json.load(json_file)
        return properties

    @staticmethod
    def generate_hash_value(config):
        union_array = config['bines'] + config['commerces']
        array_hash = hashlib.sha256(str(union_array).encode('utf-8', 'ignore')).hexdigest()
        hash_value = str(config['periodMonths']) + str(config['recurrentMonths']) + str(config['targetMonth']) + \
                     str(config['targetYear']) + array_hash
        return hash_value

    @staticmethod
    def generate_time_frame(config):
        target_month = config['targetMonth']
        target_year = config['targetYear']
        period_months = config['periodMonths']
        offset_months = 0
        granularity = 1

        date_utils = DateUtils(target_month, target_year, offset_months, period_months, granularity)
        time_frame_dict = {
            'train': {
                'year': date_utils.yearTrain,
                'month': date_utils.monthTrain
            },
            'test': {
                'year': date_utils.yearBlind,
                'month': date_utils.monthBlind
            }
        }

        return time_frame_dict

    @staticmethod
    def generate_abt(year, month, abt_type, config, spark_context):
        abt = AnalyticBaseTableJob(year, month, config)

        abt.loadTables(HiveContext(spark_context))
        # abt.commerceFilters()  # Commented while the VMIDSACM table is not ready for use
        abt.vmidsatoFilters()
        abt.generateCardLevelVariables()
        abt.getTargetsAndRecurrents()
        abt.addTargetsAndRecurrents()
        abt.getCustomerInformation()
        abt.addCustomerInformation()
        abt.generateCustomerLevelAggregations()
        abt.generateCustomerLevelVariables()
        abt.getCustomerFinancialInformation()
        abt.getPersonalCustomerInformation()
        abt.createABT()
        abt.addColumnToABT('purpose_type', abt_type)
        result_abt = abt.getABT()

        return result_abt

    def persist_abts(self, train_abt, test_abt, run_id):
        self.final_abt = train_abt.union(test_abt).withColumn('execution_id', lit(run_id))
        full_path = self.path + "/" + run_id + "/"
        print "Number of columns in train ABT AnalyticBaseTableJob main: " + str(len(self.final_abt.columns))
        self.final_abt.write.mode('overwrite').parquet(full_path)
        return full_path

    def run(self, url, spark_context):
        """ Run the ABT process
            Receive a static url of the config json file
            then generates and persists the resulting ABT for Training and Blind test

            Args:
                url: String containing the URL to the configuration file
                spark_context: Spark Context instance
        """
        run_config = self.load_config_file(url)
        self.run_id = self.generate_hash_value(run_config)
        time_frame = self.generate_time_frame(run_config)

        # Generate training and testing ABTs
        train_abt = self.generate_abt(time_frame['train']['year'], time_frame['train']['month'],
                                      'train', run_config, spark_context)
        ##
        #print "Number of columns in train ABT AnalyticBaseTableJob main: " + str(len(train_abt.columns))
        spark_context.catalog.clearCache()  # Clear cache so the job will not fail because of memory shortage
        test_abt = self.generate_abt(time_frame['test']['year'], time_frame['test']['month'],
                                     'test', run_config, spark_context)
        ##
        #print "Number of columns in test ABT AnalyticBaseTableJob main: " + str(len(train_abt.columns))

        hdfs_path = self.persist_abts(train_abt, test_abt, self.run_id)
        print("Train and test ABTs saved at: " + hdfs_path)
