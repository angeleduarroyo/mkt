from pyspark.sql import SparkSession
from utils.logging_utils import log
import conf.module as this_module


def get_spark_session():
    log.info("Initializing Spark Session")
    try:
        job_name = this_module.MODEL_NAME + "_" + this_module.JOB_NAME + "_job"

        spark = SparkSession.builder.appName(job_name).master(this_module.SPARK_MASTER)\
            .config("spark.sql.autoBroadcastJoinThreshold", "-1").getOrCreate()

        spark_configuration = str(spark.sparkContext.getConf().getAll())
        log.info("SparkSession configuration: " + spark_configuration)
    except Exception as an_exception:
        exception_message = an_exception.message
        log.info("SparkSession initialization failed: " + exception_message)
        spark = None
    return spark
