from datetime import datetime
from dateutil.relativedelta import relativedelta
from pyspark.sql.functions import lit, date_format
from calendar import monthrange

class AnalyticUtils:
    """ This is the AnalyticUtils component
        contains auxiliar methods used by Analytical Base Table Job

        Schemes:
            VMIDSATO
            FIDE
            VMIDSACM
            543
            806
    """

    def __init__(self):
        pass

    def generateDates(self, date, cutoffDate, targetDate, periodMonths, recurrentMonths, granularity):
        """Generate the necesary Dates to work with the Data Set

            Args:
                  date: last day of month for analyze,
                  cutoffDate: first day of month for analyze
                  targetDate: month to predict
                  periodMonths: time window for ABT
                  recurrentMonths: time window for recurrent info
                  granularity: number of months to use as analysis unit
        """
        try:
            fiini_cd = datetime.strptime(date, '%Y-%m-%d')
            ffin_cd = datetime.strptime(cutoffDate, '%Y-%m-%d')
            ftarget = datetime.strptime(targetDate, '%Y-%m-%d')

        except:
            print('incorrect date - Generating')
            return -1

        return {'fiini_cd_90': date_format(lit(ffin_cd - relativedelta(months=int(periodMonths - granularity))), 'YYYY-MM-dd'),
                'f_target': date_format(lit(ftarget), 'YYYY-MM-dd'),
                'f_recur': date_format(lit(fiini_cd - relativedelta(months=int(recurrentMonths))), 'YYYY-MM-dd'),
                'fiini_cd': date_format(lit(fiini_cd), 'YYYY-MM-dd'),
                'f_corte': date_format(lit(datetime.strptime(cutoffDate, '%Y-%m-%d')), 'YYYY-MM-dd'),
                'fiini': fiini_cd}

    def parseDates(self, year, month):
        """Obtains last day of date and cut off date
            Args:
                  year: year of the date to analize
                  month: month of the date to analize
        """
        monthTarget = month + 1
        yearTarget = year

        while monthTarget > 12:
            monthTarget -= 12
            yearTarget += 1

        month = '0' + str(month) if (len(str(month)) == 1) else str(month)

        try:
            date = str(year) + '-' + str(month) + '-' + str(monthrange(int(year), int(month))[1])
            dateTarget = str(yearTarget) + '-' + str(monthTarget) + '-' + str(
                monthrange(int(yearTarget), int(monthTarget))[1])

        except:
            raise('incorrect date - Parsing')

        cutOffDate = date[:-2] + '01'

        return date, cutOffDate, dateTarget

    def persistDataFrameAsParquet(self, dataFrame, fileName):
        """Persist a DataFrame as Parquet in a specific HDFS URL
        """
        dataFrame.write.mode('overwrite').parquet(fileName)
