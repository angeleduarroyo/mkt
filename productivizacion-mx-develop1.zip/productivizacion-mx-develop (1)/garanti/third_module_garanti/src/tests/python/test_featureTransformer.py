import unittest

from main.DatioGaranti.PredictionJob.FeatureTransformer import FeatureTransformer
from main.DatioGaranti.PredictionJob.spark_utils.readers import parquet
from main.DatioGaranti.PredictionJob.commons.init_spark_session import spark_session
from main.DatioGaranti.PredictionJob.GarantiUtils.InputUtils import InputUtils
from pyspark.sql import SQLContext


class TestFeatureTransformer(unittest.TestCase):
    """
    This class execute unit tests on the FeatureTransformer class, included in this module
    """

    @staticmethod
    def make_test_instance():
        """
        Create a dummy instance of the FeatureTransformer class, which will be useful for the correct execution of some
        unit tests
        :return: A FeatureTransformer instance
        """
        test_instance = FeatureTransformer("customer_id", InputUtils.ABTColumnsToTransform, 0, 1)
        return test_instance

    @staticmethod
    def make_test_dataframe():
        """
        Create a dummy dataframe, which is required for some of the unit tests in this class
        :return: A dummy dataframe
        """
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_dataframe = parquet.read_parquet_file(test_sql_context, 'tests/python/data/garanti_abt/*').dropna('any')
        return test_dataframe

    def test_transform(self):
        """
        Check that the result obtained from the transform method is well structured
        """
        test_instance = self.make_test_instance()
        test_dataframe = self.make_test_dataframe()
        test_result = test_instance.transform(test_dataframe)
        self.assertIsNotNone(test_result)


if __name__ == '__main__':
    unittest.main()
