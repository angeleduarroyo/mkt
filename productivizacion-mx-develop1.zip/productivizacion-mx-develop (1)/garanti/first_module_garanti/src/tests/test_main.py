import unittest
from tests.python.test_analyticbasetablejob import TestAnalyticBaseTableJob
from tests.python.test_analyticutils import TestAnalyticUtils
from tests.python.test_dateutils import TestDateUtils
from tests.python.test_main_abt import TestABTMain


def suite():
    test_suite = unittest.TestSuite()
    test_suite.addTest(TestAnalyticBaseTableJob('test_loadTables'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_schemas'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_vmidsatoFilters'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_generateCardLevelVariables'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_getTargetsAndRecurrents'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_addTargetsAndRecurrents'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_getCustomerInformation'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_addCustomerInformation'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_generateCustomerLevelAggregations'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_getCustomerFinancialInformation'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_getPersonalCustomerInformation'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_createABT'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_addColumnToABT'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_getABT'))

    test_suite.addTest(TestAnalyticUtils('test_parseDates'))
    test_suite.addTest(TestAnalyticUtils('test_error_parseDates'))
    test_suite.addTest(TestAnalyticUtils('test_generateDates'))
    test_suite.addTest(TestAnalyticUtils('test_error_generateDates'))
    test_suite.addTest(TestAnalyticUtils('test_persistDataFrameAsParquet'))

    test_suite.addTest(TestDateUtils('test_constructor'))
    test_suite.addTest(TestDateUtils('test_yearTrain'))
    test_suite.addTest(TestDateUtils('test_monthTrain'))
    test_suite.addTest(TestDateUtils('test_yearBlind'))
    test_suite.addTest(TestDateUtils('test_monthBlind'))

    test_suite.addTest(TestABTMain('test_load_config_file'))
    test_suite.addTest(TestABTMain('test_generate_hash_value'))
    test_suite.addTest(TestABTMain('test_generate_time_frame'))
    test_suite.addTest(TestABTMain('test_generate_abt'))
    test_suite.addTest(TestABTMain('test_persist_abts'))
    test_suite.addTest(TestABTMain('test_run'))

    return test_suite


if __name__ == '__main__':
    runner = unittest.TextTestRunner()
    runner.run(suite())