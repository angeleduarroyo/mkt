"""
    Script for TLA1872 scheme
"""
operation_date = "operation_date"

customer_id = "customer_id"
card_number = "card_number"
card_bin_number = "card_bin_number"
line_of_business_id = "line_of_business_id"
commerce_affiliation_id = "commerce_affiliation_id"
transaction_amount = "transaction_amount"
operation_id = "operation_id"
message_type = "message_type"
return_type = "return_type"
operation_time_date = "operation_time_date"
credit_limit_amount = "credit_limit_amount"
balance_amount = "balance_amount"
cutoff_date = "cutoff_date"
debit_type = "debit_type"
authorization_reference_number = "authorization_reference_number"
operation1_id = "operation1_id"
partitioning_type = "partitioning_type"
operation_card_owner_type = "operation_card_owner_type"
lynx_validation_type = "lynx_validation_type"
original_transaction_amount = "original_transaction_amount"
commerce_name = "commerce_name"


fields = [customer_id, card_number, card_bin_number, line_of_business_id, commerce_affiliation_id, transaction_amount,
          operation_id, message_type, return_type, operation_time_date, credit_limit_amount, balance_amount,
          cutoff_date, debit_type, authorization_reference_number, operation1_id, partitioning_type,
          operation_card_owner_type, lynx_validation_type, original_transaction_amount, commerce_name]
