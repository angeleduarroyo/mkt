import unittest
from main.DatioGaranti.AnalyticBaseTableJob.GarantiUtils.DateUtils import DateUtils


class TestDateUtils(unittest.TestCase):
    """
    This class execute unit tests to the DateUtils class, included in this module
    """

    @staticmethod
    def make_test_instance():
        """
        Create a dummy instance of Date Utils, required in order to execute this unit tests
        :return: A DateUtils instance
        """
        my_util = DateUtils(2, 2017, 0, 3, 1)
        return my_util

    def assert_expected_date_type(self, date_util):
        """
        Validate the expected date types in the time frame
        :param date_util: A DateUtils instance
        """
        self.assertIsInstance(date_util.yearBlind, int)
        self.assertIsInstance(date_util.monthBlind, int)
        self.assertIsInstance(date_util.yearTrain, int)
        self.assertIsInstance(date_util.monthTrain, int)

    def test_constructor(self):
        """
        Checks the integrity of the data types generated in the constructor method of DateUtils
        """
        test_month_target = 2
        test_year_target = 2017
        test_months_offset = 0
        test_months_period = 3
        test_granularity = 1

        test_instance = DateUtils(test_month_target, test_year_target, test_months_offset, test_months_period,
                                  test_granularity)

        self.assert_expected_date_type(test_instance)

    def test_yearTrain(self):
        """
        Checks that the training year has been correctly generated
        """
        test_instance = self.make_test_instance()
        self.assertIsInstance(test_instance.yearTrain, int)

    def test_monthTrain(self):
        """
        Checks that the training month has been correctly generated
        """
        test_instance = self.make_test_instance()
        self.assertIsInstance(test_instance.monthTrain, int)

    def test_yearBlind(self):
        """
        Checks that the testing year has been correctly generated
        """
        test_instance = self.make_test_instance()
        self.assertIsInstance(test_instance.yearBlind, int)

    def test_monthBlind(self):
        """
        Checks that the testing month has been correctly generated
        """
        test_instance = self.make_test_instance()
        self.assertIsInstance(test_instance.monthBlind, int)


#if __name__ == '__main__':
#    unittest.main()