""" Constants class for input scheme and main columns in ABT
"""
class InputUtils:
    # Values for filtering ABT according to governance
    ABTInputScheme = ["customer_id", "target_type", "recurrence_type", "dawning_transaction_number",
                      "morning_transaction_number", "afternoon_transaction_number", "night_transaction_number",
                      "total_operations_number", "sales_operations_number", "devolution_operations_number",
                      "ta_sales_number", "multi_payments_number", "payment_operations_number", "cash_operations_number",
                      "points_sales_number", "reverse_operations_number", "credit_card_operations_number",
                      "debit_card_operations_number", "mwi_operations_number", "correspondent_transactions_number",
                      "settled_transactions_number", "rejected_operations_number", "pending_operations_number",
                      "approved_operations_number", "rejected_operations1_number", "pending_operations1_number",
                      "sales_operations_per", "devolution_operations_per", "ta_sales_per", "multi_payments_per",
                      "payment_operations_per", "cash_operations_per", "points_sales_per", "reverse_operations_per",
                      "credit_card_operations_per", "debit_card_operations_per", "mwi_operations_per",
                      "correspondent_transactions_per", "sales_import_per", "devolution_import_per",
                      "ta_sales_import_per", "multi_payments_import_per", "cash_import_per", "points_sales_import_per",
                      "reverse_import_per", "credit_card_import_per", "debit_card_import_per", "mwi_import_per",
                      "correspondent_import_per", "current_account_amount", "customer_antiquity_number",
                      "linking_customer_number", "dawning_transaction_amount", "morning_transaction_amount",
                      "afternoon_transaction_amount", "night_transaction_amount", "total_operations_amount",
                      "operation_avg_amount", "operation_max_amount", "operation_min_amount", "sales_operations_amount",
                      "devolution_operations_amount", "ta_sales_amount", "multi_payments_amount",
                      "payment_operations_amount", "cash_operations_amount", "points_sales_amount",
                      "reverse_operations_amount", "credit_card_operations_amount", "debit_card_operations_amount",
                      "mwi_amount", "correspondent_operations_amount", "settled_operations_amount",
                      "rejected_operations_amount", "pending_operations_amount",
                      "rejected_operations1_amount", "pending_operations1_amount"]

    # Values for filtering ABT according to governance
    ABTColumnsToTransform = ["current_account_amount", "dawning_transaction_amount", "morning_transaction_amount",
                             "afternoon_transaction_amount", "night_transaction_amount", "total_operations_amount",
                             "operation_avg_amount", "operation_max_amount", "operation_min_amount",
                             "sales_operations_amount", "devolution_operations_amount", "ta_sales_amount",
                             "multi_payments_amount", "payment_operations_amount", "cash_operations_amount",
                             "points_sales_amount", "reverse_operations_amount", "credit_card_operations_amount",
                             "debit_card_operations_amount", "mwi_amount", "correspondent_operations_amount",
                             "settled_operations_amount", "rejected_operations_amount", "pending_operations_amount",
                             "rejected_operations1_amount", "pending_operations1_amount"]

    ABTColumnId = 'customer_id'

    ABTColumnLabel = 'target_type'
