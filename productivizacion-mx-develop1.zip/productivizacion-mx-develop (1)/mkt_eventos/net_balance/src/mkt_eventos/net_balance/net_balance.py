import pyspark.sql.functions as f
from datetime import timedelta, datetime
from mkt_eventos.net_balance.fide import Fide
from mkt_eventos.net_balance.tla1872_recurrency import Tla1872Recurrency
from mkt_eventos.net_balance.tmlara14_recurrency import Tmlara14Recurrency
import conf.net_balance_schema as nb


class NetBalance(object):
    """
    This class make an union of payments on vmlara14 and 1872 transactions,
    and give a liquidity definition
    """
    def __init__(self):
        self.vmlara_object = Tmlara14Recurrency()
        self.tla1872_object = Tla1872Recurrency()
        self.fide_object = Fide()

    @staticmethod
    def unify_dataframes(dataframe1, dataframe2, dataframe3, dataframe4, current_date, date_end):
        """
        This function union 4 calendar dataframes
        """
        aggregate = []
        counter = 1
        structure = "{}"
        while current_date < date_end:
            alias = structure.format(current_date)
            aggregate.append(f.sum(alias).alias(structure.format(counter)))
            current_date = current_date + timedelta(days=1)
            counter += 1
        unified_dataframe = dataframe1.union(dataframe2).union(dataframe3).union(dataframe4).\
            groupBy("customer_id").agg(*aggregate)
        return unified_dataframe

    @staticmethod
    def add_columns(calendar, fide):
        sum_expression = f.lit(0)
        columns = calendar.columns[1:]
        for column in columns:
            sum_expression = f.when(f.col(nb.rest_days) >= int(column), f.col(column)).otherwise(0) + sum_expression
        return fide.join(calendar, nb.customer_id).withColumn(nb.amount_predicted, sum_expression)

    @staticmethod
    def clean_final_table(table):
        return table.select(nb.customer_id, nb.punctual_balance_amount, nb.credit_balance_amount, nb.amount_predicted,
                            (f.col(nb.punctual_balance_amount) - f.col(nb.credit_balance_amount) -
                             f.col(nb.amount_predicted)).alias(nb.liquidity)).na\
            .fill({nb.amount_predicted: 0.0, nb.liquidity: 0.0})

    def make_calendar(self, amount, vmlara14, tla018, tla1872, tla1199, tla026, tla451, start_date, predict_date):
        """
            Do the calendar process take some params
            Params:
                TBL_VMLARA14 : 7 months of history
                       T_018 : Last catalog
                    TBL_1872 : 7 months of history
                TBL_Fide1199 : All information possible
                TBL_Fide026  : History on the dateToPredict date
             dateFromPredict : Date of first observation date on tmlara14 or 1872
               dateToPredict : Date prediction, this has to be equal to Fide 026 historic
        """
        date_format = "%Y-%m-%d"
        start_date = datetime.strptime(start_date, date_format).date()
        predict_date = datetime.strptime(predict_date, date_format).date()
        print "Fitting calendar..."
        self.fit(vmlara14, tla018, tla1872, tla1199, start_date)
        print "Done"
        print "Start prediction calendar..."
        return self.predict(tla026, tla451, predict_date, predict_date + timedelta(days=32), amount)

    def fit(self, vmlara14, tla018, tla1872, fide, start_date=None):
        """
         Do Proccess for prepare data for liquidez Analysis
        """
        print "Fitting VMLARA"
        self.vmlara_object.fit(vmlara14, tla018, start_date)
        print "Done"
        print "Fitting TLA1872"
        self.tla1872_object.fit(tla1872, start_date)
        print "Done"
        print "Fitting FIDE"
        self.fide_object.fit(fide)
        print "Done"

    def predict(self, fide, tla451, start_date, end_date, amount=1000):
        """
            Predict  the amount beetwen date_begin and date_end
            Returns two data frames
            Example:
        """
        # Calendar params
        date_begin_calendar = start_date + timedelta(days=1)
        vmlara_1, vmlara_2 = self.vmlara_object.predict(date_begin_calendar, end_date)
        tla1872_1, tla1872_2 = self.tla1872_object.predict(date_begin_calendar, end_date)
        calendar = self.unify_dataframes(tla1872_1, tla1872_2, vmlara_1, vmlara_2, date_begin_calendar, end_date)
        current_fide = self.fide_object.predict(fide, tla451, start_date)
        full_calendar = self.add_columns(calendar, current_fide).cache()
        # Customers with > 1000 of net balance
        full_table = self.clean_final_table(full_calendar).where(f.col("liquidity") > amount).\
            withColumn("fide_date", f.lit(start_date))
        return full_table.select("customer_id"), full_table
l