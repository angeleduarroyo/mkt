
def save_text_file(rdd,path, compressionCodecClass=None):
    rdd.saveAsTextFile(path, compressionCodecClass)
