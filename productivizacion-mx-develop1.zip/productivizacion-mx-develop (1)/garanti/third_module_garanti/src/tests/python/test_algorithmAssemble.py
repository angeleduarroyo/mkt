import unittest

from main.DatioGaranti.PredictionJob.AlgorithmAssemble import AlgorithmAssemble
from main.DatioGaranti.PredictionJob.FeatureTransformer import FeatureTransformer
from main.DatioGaranti.PredictionJob.spark_utils.readers import parquet
from main.DatioGaranti.PredictionJob.commons.init_spark_session import spark_session
from main.DatioGaranti.PredictionJob.GarantiUtils.InputUtils import InputUtils
from pyspark.sql import SQLContext


class TestAlgorithmAssemble(unittest.TestCase):
    """
    This class execute unit tests on the AlgorithmAssemble class, included in this module
    """

    @staticmethod
    def make_test_instance():
        """
        Create a dummy instance of the AlgorithmAssemble class, which will be useful for the correct execution of some
        unit tests
        :return: An AlgorithmAssemble instance
        """
        test_instance = AlgorithmAssemble("customer_id")
        return test_instance

    @staticmethod
    def make_test_dataframe():
        """
        Create a dummy dataframe, which is required for some of the unit tests in this class
        :return: A dummy dataframe
        """
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_dataframe = parquet.read_parquet_file(test_sql_context, 'tests/python/data/garanti_abt/*').dropna('any')
        return test_dataframe

    def assert_generated_nodes(self, node1, node2):
        """
        Check that both generated nodes of the Random Forest process, are well structured
        :param node1: First generated node
        :param node2: Second generated node
        """
        self.assertIsNotNone(node1)
        self.assertIsNotNone(node2)

    def test_loadRandomForestNodes(self):
        """
        Checks that the loaded nodes in the loadRandomForestNodes method are well structured
        """
        test_instance = self.make_test_instance()
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_hash_abt = "31282017075f540c304c047a85cce12d172d84934c691c419cf5b83a8144ca884cda119b/"
        test_hash_tnt = "d23d277c9eaa75f1353f6f7dff580fe4584602041e3e7e0cf7985ec5bdd613ec"
        test_hash = test_hash_abt + test_hash_tnt
        test_instance.loadRandomForestNodes(test_sql_context, test_hash)
        test_node1 = test_instance.randomForestNode1
        test_node2 = test_instance.randomForestNode2
        self.assert_generated_nodes(test_node1, test_node2)

    def test_predict(self):
        """
        Checks that the generated dataframe obtained from the predict method is well structured
        """
        test_instance = self.make_test_instance()
        test_dataframe = self.make_test_dataframe()
        test_dataframe = test_dataframe.dropna('any').select(InputUtils.ABTInputScheme)
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_feature_transformer = FeatureTransformer('customer_id', InputUtils.ABTColumnsToTransform, 0, 1)
        test_hash_abt = "31282017075f540c304c047a85cce12d172d84934c691c419cf5b83a8144ca884cda119b/"
        test_hash_tnt = "d23d277c9eaa75f1353f6f7dff580fe4584602041e3e7e0cf7985ec5bdd613ec"
        test_hash = test_hash_abt + test_hash_tnt
        test_instance.loadRandomForestNodes(test_sql_context, test_hash)
        test_normal_df = test_feature_transformer.transform(test_dataframe)
        test_predict_dataframe = test_instance.predict(test_normal_df)
        self.assertIsNotNone(test_predict_dataframe)


if __name__ == '__main__':
    unittest.main()