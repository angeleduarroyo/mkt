"""
    Script for TLA018 scheme
"""

transaction_id = "transaction_id"
group_name = "group_name"
transaction_name = "transaction_name"
platform_type = "platform_type"


fields = [transaction_id, group_name, transaction_name, platform_type]
