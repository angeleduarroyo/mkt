# coding=utf-8
from datetime import datetime, date

from pyspark.sql.functions import *
from pyspark.sql.functions import col as c
from pyspark.sql.types import StringType, IntegerType

from GarantiUtils.AnalyticUtils import AnalyticUtils
from GarantiUtils.SchemeDictionary import SchemeDictionaryTla117, SchemeDictionaryTla543, SchemeDictionaryTla806
from GarantiUtils.SchemeDictionary import SchemeDictionaryVmidsacm, SchemeDictionaryVmidsato, SchemeDictionaryABTOut
from spark_utils.readers import parquet


class AnalyticBaseTableJob:
    """This is the AnalyticBaseTableJob component
    Contains all the logic to load tables and process them
    with queries in order to generate an Analytic Base Table
    """

    def __init__(self, year, month, params):
        """Constructor, initialize all the attribute variables

        Args:
            year: Year number, Integer
            month: Month number, Integer
            params: Dictionary with the required parameters for the execution of the job
        """
        self.year = year
        self.month = month
        self.bines = params['bines']
        self.commerces = params['commerces']
        self.periodMonths = params['periodMonths']
        self.recurrentMonths = params['recurrentMonths']
        self.granularity = 1

        # self.tlaVmidsacmPath = params['input']['tlaVmidsacmPath']
        self.tlaFide117Path = params['input']['tlaFide117Path']
        self.tlaVmidsatoPath = params['input']['tlaVmidsatoPath']
        self.tlaInfoCte543Path = params['input']['tlaInfoCte543Path']
        self.tlaContrato806Path = params['input']['tlaContrato806Path']

        self.wtVmidsacmDF = None
        self.wtFide117DF = None
        self.wtVmidsatoDF = None
        self.wtVmidsatoFilteredDF = None
        self.wtInfoCte543DF = None
        self.wtContrato806DF = None

        self.cardLevelVariables = None
        self.targetsAndRecurrentes = None
        self.customerInformation = None
        self.customerLevelVariables = None

        self.utils = AnalyticUtils()
        endDate, initDate, targetDate = self.utils.parseDates(year, month)
        self.dates = self.utils.generateDates(endDate, initDate, targetDate, self.periodMonths,
                                              self.recurrentMonths, self.granularity)
        print("AnalyticBaseTableJob initiated")

    def loadTables(self, sqlContext):
        """Load tables from HDFS

        Tables:
            VMIDSACM
            FIDE117
            VMIDSATO
            543
            806

        Args:
            sqlContext: A spark sql context
        """

        # tlaVmidsacmPath = self.tlaVmidsacmPath
        tlaFide117Path = self.tlaFide117Path
        tlaVmidsatoPath = self.tlaVmidsatoPath
        tlaInfoCte543Path = self.tlaInfoCte543Path
        tlaContrato806Path = self.tlaContrato806Path

        print("table 806 1/5")
        self.wtContrato806DF = parquet.read_parquet_file(sqlContext, tlaContrato806Path)
        # print ("before month filter: ", self.wtContrato806DF.count())
        # self.wtContrato806DF.show()

        self.wtContrato806DF = self.wtContrato806DF.select('*') \
            .where((month(c(SchemeDictionaryTla806.FH_CORTE)) == self.month) &
                   (year(c(SchemeDictionaryTla806.FH_CORTE)) == self.year))
        # print ("after month filter: ", self.wtContrato806DF.count())
        # self.wtContrato806DF.show()

        print("table 543 2/5")
        self.wtInfoCte543DF = parquet.read_parquet_file(sqlContext, tlaInfoCte543Path)
        # print("before month filter: ", self.wtInfoCte543DF.count())
        # self.wtInfoCte543DF.show()

        # self.wtInfoCte543DF = self.wtInfoCte543DF.select('*') \
        #     .where(month(c(SchemeDictionaryTla543.load_date)) == self.month)
        # print("after month filter: ", self.wtInfoCte543DF.count())
        # self.wtInfoCte543DF.show()

        # self.wtVmidsacmDF = parquet.read_parquet_file(sqlContext, tlaVmidsacmPath)
        # print("tabla 3/5")

        print("table 117 4/5")
        self.wtFide117DF = parquet.read_parquet_file(sqlContext, tlaFide117Path)
        # print("rows: ", self.wtFide117DF.count())
        # self.wtFide117DF.show()

        self.wtFide117DF = self.wtFide117DF.select('*') \
            .where(c(SchemeDictionaryTla117.FH_CORTE) == self.dates['f_corte'])  # .distinct()

        # self.wtFide117DF.select('*').orderBy(self.wtFide117DF.customer_id).show(100)

        print("table vmidsato 5/5")
        self.wtVmidsatoDF = parquet.read_parquet_file(sqlContext, tlaVmidsatoPath)
        # print("rows: ", self.wtVmidsatoDF.count())
        # self.wtVmidsatoDF.show()
        print("loaded tables")

    def commerceFilters(self, end_date=None):
        """Importante: Si se desea filtrar solo por un mes el parámetro date
           debe estar en formato datetime.datetime,
           si se desea filtrar por un rango de tiempo los parámetros date y date2
           deben estar en formato Column'date_format'
           Nota: Modificar funcion para omitir la variable wtVmidsacmMod
                 cuando el campo de FEC_CIERRE venga de tipo Date,
                 corregir tambien el formato de self.commerces
            Nota #2: A la fecha de hoy (22-11-17), no se implementa este método en la ejecución

            Get a list of all commerce IDs listed in VMIDSACM table, given a time frame

            Note:
                This function calls an UDF

            Args:
                end_date: Time frame to filter
        """
        if end_date is None:
            end_date = date_format(lit(self.dates['fiini']), 'YYYY-MM-dd')

        commerces_cols = [c(SchemeDictionaryVmidsacm.COD_COMERCIO), c(SchemeDictionaryVmidsacm.FEC_CIERRE),
                          c(SchemeDictionaryVmidsacm.COD_EST_AFI), c(SchemeDictionaryVmidsacm.COD_INDBANC)]

        wtVmidsacmMod = self.wtVmidsacmDF.withColumn(SchemeDictionaryVmidsacm.FEC_CIERRE,
                                                     self.utils.toDateUDF(c(SchemeDictionaryVmidsacm.FEC_CIERRE),
                                                                          lit('%d/%m/%Y')))

        commerces_ = wtVmidsacmMod.select(commerces_cols)\
            .where((c(SchemeDictionaryVmidsacm.COD_COMERCIO).isin(self.commerces))
                   & (c(SchemeDictionaryVmidsacm.FEC_CIERRE).between(end_date, self.dates['fiini_cd']))
                   & (c(SchemeDictionaryVmidsacm.COD_EST_AFI) == '01')
                   & (c(SchemeDictionaryVmidsacm.COD_INDBANC) == '100'))\
            .distinct()

        commerces_list = commerces_.select(SchemeDictionaryVmidsacm.COD_COMERCIO).collect()
        self.commerces = ["000" + str(x.commerce_id) for x in commerces_list]
        print("filtered commerces")

    def vmidsatoFilters(self):
        """ Filter the vmidsato dataframe by date and other requirements
            Args: none
        """
        self.wtVmidsatoFilteredDF = self.wtVmidsatoDF.select('*') \
            .where((c(SchemeDictionaryVmidsato.FEC_OPERATRAN) > self.dates['fiini_cd_90'])
                   & (c(SchemeDictionaryVmidsato.FEC_OPERATRAN) <= self.dates['fiini_cd']))

        # print('vmidsato date filter')
        # self.wtVmidsatoFilteredDF.show()

        self.wtVmidsatoFilteredDF = self.wtVmidsatoFilteredDF.select('*') \
            .where((trim(c(SchemeDictionaryVmidsato.COD_INDDIVISA)) == 'P')
                   & (trim(c(SchemeDictionaryVmidsato.XTI_PROCTARJ)) == 'P'))

        # print('vmidsato P filter')
        # self.wtVmidsatoFilteredDF.show()

        self.wtVmidsatoFilteredDF = self.wtVmidsatoFilteredDF.select('*') \
            .where(c(SchemeDictionaryVmidsato.COD_PAN).substr(1, 6).isin(self.bines))

        print("filtered vmidsato")
        # self.wtVmidsatoFilteredDF.show()

    def generateCardLevelVariables(self):
        """ Generate an agregated dataframe with card level variables
            Args: none
        """
        self.cardLevelVariables = self.wtVmidsatoFilteredDF.groupBy(SchemeDictionaryVmidsato.COD_PAN).agg(
            sum(when(((c(SchemeDictionaryVmidsato.COD_HORATRAN).substr(1, 2) >= '00')
                      & (c(SchemeDictionaryVmidsato.COD_HORATRAN).substr(1, 2) <= '06')),
                     (c(SchemeDictionaryVmidsato.IMP_TRANSACC) + c(SchemeDictionaryVmidsato.IMP_CASH)))
                .otherwise(0))
                .alias('imp_madrugada'),
            sum(when(((c(SchemeDictionaryVmidsato.COD_HORATRAN).substr(1, 2) > '06')
                      & (c(SchemeDictionaryVmidsato.COD_HORATRAN).substr(1, 2) <= '11')),
                     (c(SchemeDictionaryVmidsato.IMP_TRANSACC) + c(SchemeDictionaryVmidsato.IMP_CASH)))
                .otherwise(0))
                .alias('imp_temprano'),
            sum(when(((c(SchemeDictionaryVmidsato.COD_HORATRAN).substr(1, 2) > '11')
                      & (c(SchemeDictionaryVmidsato.COD_HORATRAN).substr(1, 2) <= '18')),
                     (c(SchemeDictionaryVmidsato.IMP_TRANSACC) + c(SchemeDictionaryVmidsato.IMP_CASH)))
                .otherwise(0))
                .alias('imp_tarde'),
            sum(when(((c(SchemeDictionaryVmidsato.COD_HORATRAN).substr(1, 2) > '18')
                      & (c(SchemeDictionaryVmidsato.COD_HORATRAN).substr(1, 2) <= '23')),
                     (c(SchemeDictionaryVmidsato.IMP_TRANSACC) + c(SchemeDictionaryVmidsato.IMP_CASH)))
                .otherwise(0))
                .alias('imp_noche'),
            sum(when(((c(SchemeDictionaryVmidsato.COD_HORATRAN).substr(1, 2) >= '00')
                      & (c(SchemeDictionaryVmidsato.COD_HORATRAN).substr(1, 2) <= '06')), 1)
                .otherwise(0))
                .alias('txns_madrugada'),
            sum(when(((c(SchemeDictionaryVmidsato.COD_HORATRAN).substr(1, 2) > '06')
                      & (c(SchemeDictionaryVmidsato.COD_HORATRAN).substr(1, 2) <= '11')), 1)
                .otherwise(0))
                .alias('txns_temprano'),
            sum(when(((c(SchemeDictionaryVmidsato.COD_HORATRAN).substr(1, 2) > '11')
                      & (c(SchemeDictionaryVmidsato.COD_HORATRAN).substr(1, 2) <= '18')), 1)
                .otherwise(0))
                .alias('txns_tarde'),
            sum(when(((c(SchemeDictionaryVmidsato.COD_HORATRAN).substr(1, 2) > '18')
                      & (c(SchemeDictionaryVmidsato.COD_HORATRAN).substr(1, 2) <= '23')), 1)
                .otherwise(0))
                .alias('txns_noche'),
            count(c(SchemeDictionaryVmidsato.FEC_OPERATRAN)).alias('TXNS_TOT'),
            sum(when(c(SchemeDictionaryVmidsato.COD_TRANSACC) == '05', 1)
                .otherwise(0))
                .alias('txns_ventas'),
            sum(when(c(SchemeDictionaryVmidsato.COD_TRANSACC).isin(['06', '09', '11']), 1)
                .otherwise(0))
                .alias('txns_devoluciones'),
            sum(when(c(SchemeDictionaryVmidsato.COD_TRANSACC) == '00', 1)
                .otherwise(0))
                .alias('txns_ventas_TA'),
            sum(when(c(SchemeDictionaryVmidsato.COD_TRANSACC) == '25', 1)
                .otherwise(0))
                .alias('txns_ventas_multipagos'),
            sum(when(c(SchemeDictionaryVmidsato.COD_TRANSACC).isin(['5', '6', '9', '11', '0', '25']) == False, 1)
                .otherwise(0))
                .alias('txns_pagos'),
            sum(when(c(SchemeDictionaryVmidsato.XTI_CASH).isin(['', '0']) == False, 1)
                .otherwise(0))
                .alias('Txns_cash'),
            sum(when(c(SchemeDictionaryVmidsato.COD_EMISOR) == 'BV', 1)
                .otherwise(0))
                .alias('txns_bancomer'),
            sum(when(c(SchemeDictionaryVmidsato.XTI_MARCPUNT) == 'S', 1)
                .otherwise(0))
                .alias('Txns_pts'),
            sum(when(c(SchemeDictionaryVmidsato.XTI_REVERSO) == 1, 1)
                .otherwise(0))
                .alias('Txns_reverso'),
            sum(when(c(SchemeDictionaryVmidsato.XTI_TIPO_TAR) == 'C', 1)
                .otherwise(0))
                .alias('Txns_credito'),
            sum(when(c(SchemeDictionaryVmidsato.XTI_TIPO_TAR).isin(['A', 'S', 'T', 'D']), 1)
                .otherwise(0))
                .alias('Txns_debito'),
            sum(when(c(SchemeDictionaryVmidsato.XTI_PROCTARJ) == 'P', 1)
                .otherwise(0))
                .alias('Txns_em_propio'),
            sum(when(c(SchemeDictionaryVmidsato.COD_INDPUPRO) == 'S', 1)
                .otherwise(0))
                .alias('Txns_MSI'),
            sum(when(c(SchemeDictionaryVmidsato.XTI_CORRESPO) == 'S', 1)
                .otherwise(0))
                .alias('Txns_CORRESPO'),
            sum(when(c(SchemeDictionaryVmidsato.COD_ST_LIBER).isin(['LQ', 'LP', 'LO', 'L']), 1)
                .otherwise(0))
                .alias('TXNS_LIQUIDADAS'),
            sum(when(c(SchemeDictionaryVmidsato.COD_ST_LIBER).substr(1, 1).isin(['R', 'E']), 1)
                .otherwise(0))
                .alias('TXNS_RECHAZADAS'),
            sum(when(c(SchemeDictionaryVmidsato.COD_ST_LIBER).substr(1, 1) == 'P', 1)
                .otherwise(0))
                .alias('TXNS_pendientes'),
            sum(c(SchemeDictionaryVmidsato.IMP_TRANSACC) + c(SchemeDictionaryVmidsato.IMP_CASH))
                .alias('IM_TOT'),
            avg(c(SchemeDictionaryVmidsato.IMP_TRANSACC) + c(SchemeDictionaryVmidsato.IMP_CASH))
                .alias('IM_TOT_avg'),
            max(c(SchemeDictionaryVmidsato.IMP_TRANSACC) + c(SchemeDictionaryVmidsato.IMP_CASH))
                .alias('IM_TOT_max'),
            min(c(SchemeDictionaryVmidsato.IMP_TRANSACC) + c(SchemeDictionaryVmidsato.IMP_CASH))
                .alias('IM_TOT_min'),
            sum(when(c(SchemeDictionaryVmidsato.COD_TRANSACC) == '05', c(SchemeDictionaryVmidsato.IMP_TRANSACC))
                .otherwise(0))
                .alias('im_ventas'),
            sum(when(c(SchemeDictionaryVmidsato.COD_TRANSACC).isin(['06', '09', '11']),
                     (c(SchemeDictionaryVmidsato.IMP_TRANSACC) + c(SchemeDictionaryVmidsato.IMP_CASH)))
                .otherwise(0))
                .alias('im_devoluciones'),
            sum(when(c(SchemeDictionaryVmidsato.COD_TRANSACC) == '00', c(SchemeDictionaryVmidsato.IMP_TRANSACC))
                .otherwise(0))
                .alias('im_ventas_TA'),
            sum(when(c(SchemeDictionaryVmidsato.COD_TRANSACC) == '25', c(SchemeDictionaryVmidsato.IMP_TRANSACC))
                .otherwise(0))
                .alias('im_ventas_multipagos'),
            sum(when(c(SchemeDictionaryVmidsato.COD_TRANSACC).isin(['5', '6', '9', '11', '0', '25']) == False, 1)
                .otherwise(0))
                .alias('im_pagos'),
            sum(when(c(SchemeDictionaryVmidsato.XTI_CASH).isin(['', '0']) == False, c(SchemeDictionaryVmidsato.IMP_CASH))
                .otherwise(0))
                .alias('im_cash'),
            sum(when(c(SchemeDictionaryVmidsato.COD_EMISOR) == 'BV',
                     (c(SchemeDictionaryVmidsato.IMP_TRANSACC) + c(SchemeDictionaryVmidsato.IMP_CASH)))
                .otherwise(0))
                .alias('im_bancomer'),
            sum(when(c(SchemeDictionaryVmidsato.XTI_MARCPUNT) == 'S', c(SchemeDictionaryVmidsato.IMP_VENTPUNT))
                .otherwise(0))
                .alias('im_pts'),
            sum(when(c(SchemeDictionaryVmidsato.XTI_REVERSO) == '1',
                     (c(SchemeDictionaryVmidsato.IMP_TRANSACC) + c(SchemeDictionaryVmidsato.IMP_CASH)))
                .otherwise(0))
                .alias('im_reverso'),
            sum(when(c(SchemeDictionaryVmidsato.XTI_TIPO_TAR) == 'C',
                     (c(SchemeDictionaryVmidsato.IMP_TRANSACC) + c(SchemeDictionaryVmidsato.IMP_CASH)))
                .otherwise(0))
                .alias('im_credito'),
            sum(when(c(SchemeDictionaryVmidsato.XTI_TIPO_TAR).isin(['A', 'S', 'T', 'D']),
                     (c(SchemeDictionaryVmidsato.IMP_TRANSACC) + c(SchemeDictionaryVmidsato.IMP_CASH)))
                .otherwise(0))
                .alias('im_debito'),
            sum(when(c(SchemeDictionaryVmidsato.XTI_PROCTARJ) == 'P',
                     (c(SchemeDictionaryVmidsato.IMP_TRANSACC) + c(SchemeDictionaryVmidsato.IMP_CASH)))
                .otherwise(0))
                .alias('im_em_propio'),
            sum(when(c(SchemeDictionaryVmidsato.COD_INDPUPRO) == 'S', c(SchemeDictionaryVmidsato.IMP_PROMSI))
                .otherwise(0))
                .alias('im_MSI'),
            sum(when(c(SchemeDictionaryVmidsato.XTI_CORRESPO) == 'S', c(SchemeDictionaryVmidsato.IMP_TRANSACC))
                .otherwise(0))
                .alias('im_CORRESPO'),
            sum(when(c(SchemeDictionaryVmidsato.COD_ST_LIBER).isin(['LQ', 'LP', 'LO', 'L']),
                     (c(SchemeDictionaryVmidsato.IMP_TRANSACC) + c(SchemeDictionaryVmidsato.IMP_CASH)))
                .otherwise(0))
                .alias('im_LIQUIDADAS'),
            sum(when(c(SchemeDictionaryVmidsato.COD_ST_LIBER).isin(['R', 'E']),
                     (c(SchemeDictionaryVmidsato.IMP_TRANSACC) + c(SchemeDictionaryVmidsato.IMP_CASH)))
                .otherwise(0))
                .alias('im_RECHAZADAS'),
            sum(when(c(SchemeDictionaryVmidsato.COD_ST_LIBER).substr(1, 1) == 'P',
                     (c(SchemeDictionaryVmidsato.IMP_TRANSACC) + c(SchemeDictionaryVmidsato.IMP_CASH)))
                .otherwise(0))
                .alias('im_pendientes'),
            when(
                (isnan(stddev(c(SchemeDictionaryVmidsato.IMP_TRANSACC) + c(SchemeDictionaryVmidsato.IMP_CASH))) |
                 (stddev(c(SchemeDictionaryVmidsato.IMP_TRANSACC) + c(SchemeDictionaryVmidsato.IMP_CASH))).isNull()), 0)
                .otherwise(stddev(c(SchemeDictionaryVmidsato.IMP_TRANSACC) + c(SchemeDictionaryVmidsato.IMP_CASH)))
                .alias('std_imp_transa')
        )
        print("created card level variables")
        # self.cardLevelVariables.show()

    def getTargetsAndRecurrents(self):
        """ Create a Dataframe to retrieve target and recurrent variables, classified by card number
            Args: none
        """
        self.targetsAndRecurrentes = self.wtVmidsatoDF.groupBy(SchemeDictionaryVmidsato.COD_PAN).agg(
            sum(when(
                ((c(SchemeDictionaryVmidsato.FEC_OPERATRAN) >= self.dates['f_recur']) &
                 (c(SchemeDictionaryVmidsato.FEC_OPERATRAN) <= self.dates['fiini_cd']) &
                 (trim(c(SchemeDictionaryVmidsato.COD_INDDIVISA)) == 'P') &
                 (trim(c(SchemeDictionaryVmidsato.XTI_PROCTARJ)) == 'P') &
                 (c(SchemeDictionaryVmidsato.COD_COMERCIO).isin(self.commerces)) &
                 (c(SchemeDictionaryVmidsato.COD_PAN).substr(1, 6).isin(self.bines))
                 ), 1
            ).otherwise(0)).alias('es_recurrente')
        ).select(c(SchemeDictionaryVmidsato.COD_PAN).alias('oje'), c('es_recurrente'))

        print("created targets and recurrent by date")
        # self.targetsAndRecurrentes.show()

    def addTargetsAndRecurrents(self):
        """ Add target and recurrent variables to the Card level Dataframe by making a JOIN operation involving
            'cardLevelVariables' and 'targetsAndRecurrentes' dataframes
            Args: none
        """
        self.cardLevelVariables = self.cardLevelVariables \
            .join(self.targetsAndRecurrentes, (self.cardLevelVariables.pan_id == self.targetsAndRecurrentes.oje), 'left')

        print("joined cardLevelVariables and targetsAndRecurrents")

        self.cardLevelVariables = self.cardLevelVariables \
            .select('*', when(c('es_recurrente') > 0, 1).otherwise(0).alias('recur'))

        print("targets and recurrent added to card level info")
        # self.cardLevelVariables.show()

    def getCustomerInformation(self):
        """ Retrieve customer information, making a SELECT operation to the TLA806 Dataframe
            Args: none
        """
        self.customerInformation = self.wtContrato806DF \
            .select(c(SchemeDictionaryTla806.NU_CTE),
                    c(SchemeDictionaryTla806.NU_BIN),
                    c(SchemeDictionaryTla806.NU_TARJETA),
                    c(SchemeDictionaryTla806.FH_CORTE)) \
            .where((c(SchemeDictionaryTla806.NU_BIN).isin(self.bines))
                   & (c(SchemeDictionaryTla806.FH_CORTE) <= self.dates['f_corte'])) \
            .distinct()

        print("obtained customer/contract information")
        # self.customerInformation.show()

    def addCustomerInformation(self):
        """ Add card level customer information into the Card Level Variables Dataframe
            Args: none
        """
        self.cardLevelVariables = self.cardLevelVariables \
            .join(self.customerInformation,
                  self.cardLevelVariables[SchemeDictionaryVmidsato.COD_PAN].substr(7, 16) ==
                  self.customerInformation[SchemeDictionaryTla806.NU_TARJETA])

        self.cardLevelVariables.cache()
        # print("Added card level with customer information")

        print(self.cardLevelVariables.count(), " rows at card level with customer information")
        # self.cardLevelVariables.show()

    def generateCustomerLevelAggregations(self):
        """ Aggregates the card level variables Dataframe, and groups this information by customer ID
            Args: none
        """
        self.customerLevelVariables = self.cardLevelVariables.groupBy(c(SchemeDictionaryTla806.NU_CTE)).agg(
            sum(c('imp_madrugada')).alias(SchemeDictionaryABTOut.imp_madrugada),
            sum(c('imp_temprano')).alias(SchemeDictionaryABTOut.imp_temprano),
            sum(c('imp_tarde')).alias(SchemeDictionaryABTOut.imp_tarde),
            sum(c('imp_noche')).alias(SchemeDictionaryABTOut.imp_noche),
            sum(c('txns_madrugada')).alias(SchemeDictionaryABTOut.txns_madrugada),
            sum(c('txns_temprano')).alias(SchemeDictionaryABTOut.txns_temprano),
            sum(c('txns_tarde')).alias(SchemeDictionaryABTOut.txns_tarde),
            sum(c('txns_noche')).alias(SchemeDictionaryABTOut.txns_noche),
            sum(c('TXNS_TOT')).alias(SchemeDictionaryABTOut.TXNS_TOT),
            sum(c('txns_ventas')).alias(SchemeDictionaryABTOut.txns_ventas),
            sum(c('txns_devoluciones')).alias(SchemeDictionaryABTOut.txns_devoluciones),
            sum(c('txns_ventas_TA')).alias(SchemeDictionaryABTOut.txns_ventas_TA),
            sum(c('txns_ventas_multipagos')).alias(SchemeDictionaryABTOut.txns_ventas_multipagos),
            sum(c('txns_pagos')).alias(SchemeDictionaryABTOut.txns_pagos),
            sum(c('Txns_cash')).alias(SchemeDictionaryABTOut.Txns_cash),
            sum(c('Txns_pts')).alias(SchemeDictionaryABTOut.Txns_pts),
            sum(c('Txns_reverso')).alias(SchemeDictionaryABTOut.Txns_reverso),
            sum(c('Txns_credito')).alias(SchemeDictionaryABTOut.Txns_credito),
            sum(c('Txns_debito')).alias(SchemeDictionaryABTOut.Txns_debito),
            sum(c('Txns_MSI')).alias(SchemeDictionaryABTOut.Txns_MSI),
            sum(c('Txns_CORRESPO')).alias(SchemeDictionaryABTOut.Txns_CORRESPO),
            sum(c('TXNS_LIQUIDADAS')).alias(SchemeDictionaryABTOut.TXNS_LIQUIDADAS),
            sum(c('TXNS_RECHAZADAS')).alias(SchemeDictionaryABTOut.TXNS_RECHAZADAS),
            sum(c('TXNS_pendientes')).alias(SchemeDictionaryABTOut.TXNS_pendientes),
            sum(c('IM_TOT')).alias(SchemeDictionaryABTOut.IM_TOT),
            sum(c('IM_TOT_avg')).alias(SchemeDictionaryABTOut.IM_TOT_avg),
            sum(c('IM_TOT_max')).alias(SchemeDictionaryABTOut.IM_TOT_max),
            sum(c('IM_TOT_min')).alias(SchemeDictionaryABTOut.IM_TOT_min),
            sum(c('im_ventas')).alias(SchemeDictionaryABTOut.im_ventas),
            sum(c('im_devoluciones')).alias(SchemeDictionaryABTOut.im_devoluciones),
            sum(c('im_ventas_TA')).alias(SchemeDictionaryABTOut.im_ventas_TA),
            sum(c('im_ventas_multipagos')).alias(SchemeDictionaryABTOut.im_ventas_multipagos),
            sum(c('im_pagos')).alias(SchemeDictionaryABTOut.im_pagos),
            sum(c('im_cash')).alias(SchemeDictionaryABTOut.im_cash),
            sum(c('im_pts')).alias(SchemeDictionaryABTOut.im_pts),
            sum(c('im_reverso')).alias(SchemeDictionaryABTOut.im_reverso),
            sum(c('im_credito')).alias(SchemeDictionaryABTOut.im_credito),
            sum(c('im_debito')).alias(SchemeDictionaryABTOut.im_debito),
            sum(c('im_MSI')).alias(SchemeDictionaryABTOut.im_MSI),
            sum(c('im_CORRESPO')).alias(SchemeDictionaryABTOut.im_CORRESPO),
            sum(c('im_LIQUIDADAS')).alias(SchemeDictionaryABTOut.im_LIQUIDADAS),
            sum(c('im_RECHAZADAS')).alias(SchemeDictionaryABTOut.im_RECHAZADAS),
            sum(c('im_pendientes')).alias(SchemeDictionaryABTOut.im_pendientes),
            max(c('recur')).alias(SchemeDictionaryABTOut.recur)
        )

        print("created customer level aggregations")
        # self.customerLevelVariables.show()

    def generateCustomerLevelVariables(self):
        """ Generate a Dataframe with customer level variables
            Args: none
        """
        self.customerLevelVariables = self.customerLevelVariables \
            .select('*',
                    when((c(SchemeDictionaryABTOut.im_LIQUIDADAS) > 0)
                         & (c(SchemeDictionaryABTOut.TXNS_TOT) > 0), c(SchemeDictionaryABTOut.TXNS_LIQUIDADAS)
                         / c(SchemeDictionaryABTOut.TXNS_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txnsapro_otr),

                    when((c(SchemeDictionaryABTOut.TXNS_RECHAZADAS) > 0)
                         & (c(SchemeDictionaryABTOut.TXNS_TOT) > 0), c(SchemeDictionaryABTOut.TXNS_RECHAZADAS)
                         / c(SchemeDictionaryABTOut.TXNS_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txnsrec_otr),

                    when((c(SchemeDictionaryABTOut.TXNS_pendientes) > 0)
                         & (c(SchemeDictionaryABTOut.TXNS_TOT) > 0), c(SchemeDictionaryABTOut.TXNS_pendientes)
                         / c(SchemeDictionaryABTOut.TXNS_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txnsapend_otr),

                    when((c(SchemeDictionaryABTOut.txns_ventas) > 0)
                         & (c(SchemeDictionaryABTOut.TXNS_TOT) > 0), c(SchemeDictionaryABTOut.txns_ventas)
                         / c(SchemeDictionaryABTOut.TXNS_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_v_part),

                    when((c(SchemeDictionaryABTOut.txns_devoluciones) > 0)
                         & (c(SchemeDictionaryABTOut.TXNS_TOT) > 0), c(SchemeDictionaryABTOut.txns_devoluciones)
                         / c(SchemeDictionaryABTOut.TXNS_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_dev_part),

                    when((c(SchemeDictionaryABTOut.txns_ventas_TA) > 0)
                         & (c(SchemeDictionaryABTOut.TXNS_TOT) > 0), c(SchemeDictionaryABTOut.txns_ventas_TA)
                         / c(SchemeDictionaryABTOut.TXNS_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_ta_part),

                    when((c(SchemeDictionaryABTOut.txns_ventas_multipagos) > 0)
                         & (c(SchemeDictionaryABTOut.TXNS_TOT) > 0), c(SchemeDictionaryABTOut.txns_ventas_multipagos)
                         / c(SchemeDictionaryABTOut.TXNS_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_mp_part),

                    when((c(SchemeDictionaryABTOut.txns_pagos) > 0)
                         & (c(SchemeDictionaryABTOut.TXNS_TOT) > 0), c(SchemeDictionaryABTOut.txns_pagos)
                         / c(SchemeDictionaryABTOut.TXNS_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_pa_part),

                    when((c(SchemeDictionaryABTOut.Txns_cash) > 0)
                         & (c(SchemeDictionaryABTOut.TXNS_TOT) > 0), c(SchemeDictionaryABTOut.Txns_cash)
                         / c(SchemeDictionaryABTOut.TXNS_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_cs_part),

                    when((c(SchemeDictionaryABTOut.Txns_pts) > 0)
                         & (c(SchemeDictionaryABTOut.TXNS_TOT) > 0), c(SchemeDictionaryABTOut.Txns_pts)
                         / c(SchemeDictionaryABTOut.TXNS_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_pts_part),

                    when((c(SchemeDictionaryABTOut.Txns_reverso) > 0)
                         & (c(SchemeDictionaryABTOut.TXNS_TOT) > 0), c(SchemeDictionaryABTOut.Txns_reverso)
                         / c(SchemeDictionaryABTOut.TXNS_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_rv_part),

                    when((c(SchemeDictionaryABTOut.Txns_credito) > 0)
                         & (c(SchemeDictionaryABTOut.TXNS_TOT) > 0), c(SchemeDictionaryABTOut.Txns_credito)
                         / c(SchemeDictionaryABTOut.TXNS_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_cd_part),

                    when((c(SchemeDictionaryABTOut.Txns_debito) > 0)
                         & (c(SchemeDictionaryABTOut.TXNS_TOT) > 0), c(SchemeDictionaryABTOut.Txns_debito)
                         / c(SchemeDictionaryABTOut.TXNS_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_db_part),

                    when((c(SchemeDictionaryABTOut.Txns_MSI) > 0)
                         & (c(SchemeDictionaryABTOut.TXNS_TOT) > 0), c(SchemeDictionaryABTOut.Txns_MSI)
                         / c(SchemeDictionaryABTOut.TXNS_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_ms_part),

                    when((c(SchemeDictionaryABTOut.Txns_CORRESPO) > 0)
                         & (c(SchemeDictionaryABTOut.TXNS_TOT) > 0), c(SchemeDictionaryABTOut.Txns_CORRESPO)
                         / c(SchemeDictionaryABTOut.TXNS_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_co_part),

                    when((c(SchemeDictionaryABTOut.im_LIQUIDADAS) > 0)
                         & (c(SchemeDictionaryABTOut.IM_TOT) > 0), c(SchemeDictionaryABTOut.im_LIQUIDADAS)
                         / c(SchemeDictionaryABTOut.IM_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.imsapro_otr),

                    when((c(SchemeDictionaryABTOut.im_RECHAZADAS) > 0)
                         & (c(SchemeDictionaryABTOut.IM_TOT) > 0), c(SchemeDictionaryABTOut.im_RECHAZADAS)
                         / c(SchemeDictionaryABTOut.IM_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.imsrec_otr),

                    when((c(SchemeDictionaryABTOut.im_pendientes) > 0)
                         & (c(SchemeDictionaryABTOut.IM_TOT) > 0), c(SchemeDictionaryABTOut.im_pendientes)
                         / c(SchemeDictionaryABTOut.IM_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.imsapend_otr),

                    when((c(SchemeDictionaryABTOut.im_ventas) > 0)
                         & (c(SchemeDictionaryABTOut.IM_TOT) > 0), c(SchemeDictionaryABTOut.im_ventas)
                         / c(SchemeDictionaryABTOut.IM_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.m_v_part_im),

                    when((c(SchemeDictionaryABTOut.im_devoluciones) > 0)
                         & (c(SchemeDictionaryABTOut.IM_TOT) > 0), c(SchemeDictionaryABTOut.im_devoluciones)
                         / c(SchemeDictionaryABTOut.IM_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_dev_part_im),

                    when((c(SchemeDictionaryABTOut.im_ventas_TA) > 0)
                         & (c(SchemeDictionaryABTOut.IM_TOT) > 0), c(SchemeDictionaryABTOut.im_ventas_TA)
                         / c(SchemeDictionaryABTOut.IM_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_ta_part_im),

                    when((c(SchemeDictionaryABTOut.im_ventas_multipagos) > 0)
                         & (c(SchemeDictionaryABTOut.IM_TOT) > 0), c(SchemeDictionaryABTOut.im_ventas_multipagos)
                         / c(SchemeDictionaryABTOut.IM_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_mp_part_im),

                    when((c(SchemeDictionaryABTOut.im_pagos) > 0)
                         & (c(SchemeDictionaryABTOut.IM_TOT) > 0), c(SchemeDictionaryABTOut.im_pagos)
                         / c(SchemeDictionaryABTOut.IM_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_pa_part_im),

                    when((c(SchemeDictionaryABTOut.im_cash) > 0)
                         & (c(SchemeDictionaryABTOut.IM_TOT) > 0), c(SchemeDictionaryABTOut.im_cash)
                         / c(SchemeDictionaryABTOut.IM_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_cs_part_im),

                    when((c(SchemeDictionaryABTOut.im_pts) > 0)
                         & (c(SchemeDictionaryABTOut.IM_TOT) > 0), c(SchemeDictionaryABTOut.im_pts)
                         / c(SchemeDictionaryABTOut.IM_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_pts_part_im),

                    when((c(SchemeDictionaryABTOut.im_reverso) > 0)
                         & (c(SchemeDictionaryABTOut.IM_TOT) > 0), c(SchemeDictionaryABTOut.im_reverso)
                         / c(SchemeDictionaryABTOut.IM_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_rv_part_im),

                    when((c(SchemeDictionaryABTOut.im_credito) > 0)
                         & (c(SchemeDictionaryABTOut.IM_TOT) > 0), c(SchemeDictionaryABTOut.im_credito)
                         / c(SchemeDictionaryABTOut.IM_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_cd_part_im),

                    when((c(SchemeDictionaryABTOut.im_MSI) > 0)
                         & (c(SchemeDictionaryABTOut.IM_TOT) > 0), c(SchemeDictionaryABTOut.im_MSI)
                         / c(SchemeDictionaryABTOut.IM_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_ms_part_im),

                    when((c(SchemeDictionaryABTOut.im_CORRESPO) > 0)
                         & (c(SchemeDictionaryABTOut.IM_TOT) > 0), c(SchemeDictionaryABTOut.im_CORRESPO)
                         / c(SchemeDictionaryABTOut.IM_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_co_part_im),

                    when((c(SchemeDictionaryABTOut.im_debito) > 0)
                         & (c(SchemeDictionaryABTOut.IM_TOT) > 0), c(SchemeDictionaryABTOut.im_debito)
                         / c(SchemeDictionaryABTOut.IM_TOT)).otherwise(0)
                    .alias(SchemeDictionaryABTOut.txns_db_part_im))

        self.customerLevelVariables.cache()

        print("created customer level info")
        # self.customerLevelVariables.show()

    def getCustomerFinancialInformation(self):
        """ Gets the financial information of a customer with tenure of at least one credit card
            Uses content on TLA117
            Note:
                Calls the tenureCreditCard UDF
            Args: none
        """

        def tenureCreditCard(to_tarj, to_tdc_bancaria, to_tdc_congelada, to_tarj_tcd):
            """ Indicates the number of credit cards that belongs to a customer
                Returns the result of the sum of:
                to_tarj + to_tdc_bancaria + to_tdc_congelada + to_tarj_tcd
                Args:
                    to_tarj: integer
                    to_tdc_bancaria: integer
                    to_tdc_congelada: integer
                    to_tarj_tcd: integer
            """
            try:
                a = int(float(str(to_tarj)))
            except:
                a = 0
            try:
                b = int(float(str(to_tdc_bancaria)))
            except:
                b = 0
            try:
                c = int(float(str(to_tdc_congelada)))
            except:
                c = 0
            try:
                d = int(float(str(to_tarj_tcd)))
            except:
                d = 0

            return a + b + c + d

        tenureCreditCardUDF = \
            udf(lambda to_tarj, to_tdc_bancaria, to_tdc_congelada, to_tarj_tcd:
                tenureCreditCard(to_tarj, to_tdc_bancaria, to_tdc_congelada, to_tarj_tcd))

        self.customerFinancialInformation = self.customerLevelVariables \
            .join(self.wtFide117DF, SchemeDictionaryTla117.NU_CTE_FIDE, 'inner')

        self.customerFinancialInformation = self.customerFinancialInformation \
            .select(c(SchemeDictionaryTla117.NU_CTE_FIDE).alias(SchemeDictionaryABTOut.nu_cte_otro_vars),
                    c(SchemeDictionaryTla117.FH_CORTE),
                    c(SchemeDictionaryTla117.CD_OFICINA),
                    c(SchemeDictionaryTla117.IM_SDO_PUNTUAL).alias(SchemeDictionaryABTOut.Saldo_vista),
                    tenureCreditCardUDF(c(SchemeDictionaryTla117.TO_TARJ), c(SchemeDictionaryTla117.TO_TDC_BANCARIA),
                                        c(SchemeDictionaryTla117.TO_TDC_CONGELADA), c(SchemeDictionaryTla117.TO_TARJ_TCD))
                    .alias(SchemeDictionaryABTOut.tenencia_tdc),
                    c(SchemeDictionaryTla117.NU_IX_FIDELIZACION).alias(SchemeDictionaryABTOut.vinculacion))

        print("Obtained customer financial information")
        # self.customerFinancialInformation.show()

    def getPersonalCustomerInformation(self):
        """ Gets the personal information of a customer
            Uses the content of TLA543 table
            Note: Makes use of the calculateYearsAgo UDF
            Args: none
        """

        def calculateYearsAgo(strDate):
            """ Calculate the number of lapsed years between the actual date, and the date of information
                Returns a datetime that takes the value of the lapsed years
                Args:
                    strDate: Datetime -- Date of information load
            """
            if (strDate is None) | (len(strDate) <= 0):
                return None

            d = datetime.strptime(strDate, "%Y-%m-%d")
            f = d.year

            if f <= 100:
                return None

            result = datetime.today().year - f - int(
                (datetime.today().month, datetime.today().day) < (date.month, date.day))

            if result == 0:
                result = 1

            return result

        calculateYearsAgoUDF = udf(calculateYearsAgo, IntegerType())

        self.personalCustomerInformation = self.wtInfoCte543DF \
            .join(self.customerFinancialInformation, (self.customerFinancialInformation.customer2_id
                                                      == self.wtInfoCte543DF.customer_id), 'inner')

        self.personalCustomerInformation = self.personalCustomerInformation \
            .select(c(SchemeDictionaryABTOut.nu_cte_otro_vars).alias(SchemeDictionaryABTOut.cliente),
                    c(SchemeDictionaryTla543.fh_nacimiento),
                    c(SchemeDictionaryTla543.tp_persona),
                    c(SchemeDictionaryTla543.nu_sec_ident),
                    c(SchemeDictionaryTla543.cd_sexo),
                    c(SchemeDictionaryTla543.fh_antiguedad),
                    calculateYearsAgoUDF(self.personalCustomerInformation.seniority_date.cast(StringType()))
                    .alias(SchemeDictionaryABTOut.Antig_cte),
                    calculateYearsAgoUDF(self.personalCustomerInformation.birth_date.cast(StringType()))
                    .alias(SchemeDictionaryABTOut.Edad),
                    ).drop(c(SchemeDictionaryTla543.nu_cte))

        print("obtained customer personal information")
        # self.personalCustomerInformation.show()

    def createABT(self):
        """ Join all the information of a customer in a year, then return the resulting Dataframe
            Args: none
        """
        self.abt = self.customerLevelVariables \
            .join(self.customerFinancialInformation, self.customerLevelVariables.customer_id
                  == self.customerFinancialInformation.customer2_id)
        self.abt = self.abt \
            .join(self.personalCustomerInformation, self.abt.customer2_id ==
                  self.personalCustomerInformation.customer1_id)

        self.abt.cache()

        print("rows in ABT: ", self.abt.count())
        # self.abt.show()

    def addColumnToABT(self, columnName, columnContent):
        self.abt = self.abt.withColumn(columnName, lit(columnContent))

        self.abt.cache()

    def getABT(self):
        return self.abt