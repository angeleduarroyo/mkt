import unittest
from main.DatioGaranti.AnalyticBaseTableJob.GarantiUtils.AnalyticUtils import AnalyticUtils
from main.DatioGaranti.commons.init_spark_session import spark_session
from pyspark.sql import SQLContext


class TestAnalyticUtils(unittest.TestCase):
    """
    This class execute unit tests on the AnalyticUtils class, included in this module
    """

    @staticmethod
    def make_test_instance():
        """
        Create a dummy instance of the AnalyticUtils class
        :return: An AnalyticUtils instance
        """
        my_abt = AnalyticUtils()
        return my_abt

    def assert_parsed_dates(self, date, cutoff_date, date_target):
        """
        Check that every of the generated dates have a correct structure
        :param date: String with the date of the first day of the time frame to analyze
        :param cutoff_date: String with the cutoff date of a month to analyze
        :param date_target: String with the target date of the time frame to analyze
        """
        self.assertIsInstance(date, basestring)
        self.assertIsInstance(cutoff_date, basestring)
        self.assertIsInstance(date_target, basestring)

    def test_parseDates(self):
        """
        Check that the time frame has been correctly generated
        """
        test_instance = self.make_test_instance()
        test_date, test_cutoff_date, test_date_target = test_instance.parseDates(2017, 12)
        self.assert_parsed_dates(test_date, test_cutoff_date, test_date_target)

    def test_error_parseDates(self):
        """
        Check that the time frame has been correctly generated
        """
        test_instance = self.make_test_instance()
        self.assertRaises(TypeError,test_instance.parseDates,2017,2000)

    def test_generateDates(self):
        """
        Test generateDates function
        """

        sc = spark_session()
        test_instance = self.make_test_instance()
        endDate, initDate, targetDate = test_instance.parseDates(2017, 12)

        periodMonths = 3
        recurrentMonths = 12
        granularity = 1

        dates = test_instance.generateDates(endDate, initDate, targetDate, periodMonths,recurrentMonths, granularity)

        sc.stop()
        self.assertIsInstance(dates, dict)

    def test_error_generateDates(self):
        """
        Test generateDates function
        """

        test_instance = self.make_test_instance()

        result = test_instance.generateDates("un valor erroneo", "un valor erroneo", "un valor erroneo", "un valor erroneo",
                                             "un valor erroneo", "un valor erroneo")
        self.assertEqual(result, -1)

    def test_persistDataFrameAsParquet(self):
        """
        Test persist DataFrame, this method has a try because a case
        where the dataframe is written by other test
        :return:
        """
        sc = spark_session()
        spark = SQLContext(sc.sparkContext)
        dataframe = spark.read.parquet("tests/python/data/tlaInfoCte543/")
        test_instance = self.make_test_instance()
        try:
            test_instance.persistDataFrameAsParquet(dataFrame=dataframe, fileName="tests/python/data/mock/tlaInfoCte543")
        except:
            print("El archivo ya existia")
        dataframe2 = spark.read.parquet("tests/python/data/mock/tlaInfoCte543")
        number_df1 = dataframe.count()
        number_df2 = dataframe2.count()
        sc.stop()
        self.assertEqual(number_df1, number_df2)


#if __name__ == '__main__':
#    unittest.main()
