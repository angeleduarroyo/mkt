
def read_csv_file(spark,path):
    return spark.read.csv(path)