import json
import datetime as dt

from utils.analytic_utils import AnalyticUtils
from utils.table_loader import TableLoader
from mkt_eventos.net_balance.net_balance import NetBalance


class NetBalanceJob(object):
    """
        This class generates the net balance of a specific date. It has all main functions to start the model
        process
    """

    @staticmethod
    def load_parameters(nexus_url):
        """
        Opens and Loads json file parameters,  which contains tables paths and netbalance model parameters

        :param nexus_url: String containing the URL to the configuration file
        :return: Parameters Schema
        """
        with open(nexus_url) as parameters_json:
            parameters_dictionary = json.load(parameters_json)
        return parameters_dictionary

    @staticmethod
    def save_table(path, dataframe):
        Persist  ABT to HDFS
        """
        :param path:
        :param dataframe:
        :return:
        """
        print "Writing in HDFS: " + str(dt.datetime.now())
        dataframe.write.parquet(path)
        print "Saved in: " + path

    @staticmethod
    def make_net_balance_tables(parameters, spark_session, activation_date):
        """
         This function loads necesary tables for model according to date and time parameters

        Tables:
            tla1872
            tmlara14
            tla543
            tla451_path
            tla018_path
            tla117_path
            tlaFide117
            tla026
            tlaFide026
            tla1199

        :param parameters:
        :param spark_session:
        :param activation_date:
        :return: customers, customers_net_balance
        """
        input_paths = parameters["input"]
        module_parameters = parameters["net_balance"]
        time_frame = module_parameters['time_frame']
        lost_months = module_parameters['lost_months']
        fide_time_frame = module_parameters['fide_time_frame']
        minimum_threshold = module_parameters['minimum_threshold']
        table_loader = TableLoader(input_paths)
        net_balance = NetBalance()
        tmlara14_data, tla018_data, tla1872_data, tla1199_data, tla026_data, tla451_data, \
        latest_tla1872_date, latest_tla026_date = table_loader.load_net_balance_tables(spark_session,
                                                                                       activation_date, time_frame,
                                                                                       lost_months, fide_time_frame)
        customers, customers_net_balance = net_balance.make_calendar(minimum_threshold, tmlara14_data, tla018_data,
                                                                     tla1872_data, tla1199_data, tla026_data,
                                                                     tla451_data, latest_tla1872_date,
                                                                     latest_tla026_date)
        return customers, customers_net_balance

    def start(self, activation_date, nexus_url, spark_session):
        """This is a main function, which stars the model process
        :param activation_date: Process date
        :param nexus_url: String containing the URL to the configuration file
        :param spark_session: Initialize Spark Session
        :return:
        """
        # SparkSession, config parser and logging object are initiated in commons module
        spark_context = spark_session.sparkContext
        parameters = self.load_parameters(nexus_url)
        module_parameters = parameters["net_balance"]
        utils = AnalyticUtils()

        print "Start process: " + str(dt.datetime.now())

        #This step creates variables to build  paths adding the process date,  where the final tables (customer and customer net balance)will be saved

        users_path = module_parameters["users_path"] + "act_date=" + str(activation_date)
        information_path = module_parameters["information_path"] + "act_date=" + str(activation_date)

        # Load and save final tables validating  the non existance of final paths ,  otherwise the process ends
        if not utils.path_exists(users_path, spark_context) and not utils.path_exists(information_path, spark_context):
            print "Loading tables from HDFS: " + str(dt.datetime.now())
            customers, customers_net_balance = self.make_net_balance_tables(parameters, spark_session, activation_date)
            self.save_table(users_path, customers)
            self.save_table(information_path, customers_net_balance)
        else:
            print "Date processed previously: " + str(dt.datetime.now())
        print "End process: " + str(dt.datetime.now())
