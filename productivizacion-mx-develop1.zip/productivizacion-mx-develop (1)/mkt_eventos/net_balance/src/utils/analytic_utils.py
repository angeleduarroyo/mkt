from pyspark.sql.functions import lit
import pyspark.sql.functions as f
from dateutil import relativedelta as rd
import datetime as dt
from calendar import monthrange
from py4j.protocol import Py4JJavaError


class AnalyticUtils:

    def __init__(self):
        pass

    @staticmethod
    def unify_partitioned_table(sql_context, table_path, table_label, start_date, end_date, partition_by, fields):
       """
       Functions that validates  information date and paht existance in order to extract the tables
       :param sql_context: Initialize sql_context object
       :param table_path: Table path
       :param table_label:
       :param start_date:
       :param end_date:
       :param partition_by: day or month
       :param fields: it has the schema  fields for each table
       :return:
       """
        date_list = None
        if partition_by == "day":
            in_date = dt.date(start_date.year, start_date.month, start_date.day)
            end_date = dt.date(end_date.year, end_date.month, end_date.day)
            days_count = (end_date - in_date).days + 1
            date_list = list(map(str, [in_date + dt.timedelta(days=x) for x in range(0, days_count)]))
        elif partition_by == "month":
            in_date = dt.date(start_date.year, start_date.month, 1)
            end_date = dt.date(end_date.year, end_date.month, 1)
            months_count = (end_date.year - in_date.year) * 12 + end_date.month - in_date.month + 1
            date_list = list(map(str, [in_date + rd.relativedelta(months=x) for x in range(0, months_count)]))
        dates_without_data = []
        information_dataframe = None
        exist_data = False
        first_date_with_data = None
        for date in date_list[::-1]:
            date_structure = "{0}{1}={2}"
            if not exist_data:
                path = date_structure.format(table_path, table_label, date)
                try:
                    information_dataframe = sql_context.read.parquet(path).\
                        select(fields).withColumn(table_label, f.to_date(lit(date)))
                    exist_data = True
                    first_date_with_data = date
                except:
                    dates_without_data.append(path)
                    continue
            else:
                path = date_structure.format(table_path, table_label, date)
                try:
                    complement_table = sql_context.read.parquet(path).select(fields)\
                        .withColumn(table_label, f.to_date(lit(date)))
                except:
                    dates_without_data.append(path)
                    continue
                else:
                    information_dataframe = information_dataframe.union(complement_table)
        dates_without_data_count = len(dates_without_data)
        print "\tTotal errors: " + str(dates_without_data_count) + "\n\tDates: " + str(dates_without_data)
        return information_dataframe, first_date_with_data

    @staticmethod
    def generate_dates(target_date, time_frame, lost_months, fide_time_frame, module):
        if module == "abt":
            start_date = target_date - rd.relativedelta(months=lost_months + time_frame) - \
                             dt.timedelta(days=target_date.day - 1)

            end_date = start_date + rd.relativedelta(months=time_frame - lost_months)
            end_date = end_date + dt.timedelta(days=monthrange(end_date.year, end_date.month)[1] -
                                               end_date.day)

            fide_start_date = target_date - rd.relativedelta(months=lost_months + fide_time_frame) - \
                              dt.timedelta(days=target_date.day - 1)

            target_start_date = target_date - rd.relativedelta(months=1)
            dates = {
                "start_date": start_date,
                "end_date": end_date,
                "fide_start_date": fide_start_date,
                "target_start_date": target_start_date
            }
            return dates
        elif module == "net_balance":
            start_date = target_date - rd.relativedelta(months=time_frame)
            end_date = target_date
            fide_start_date = target_date - rd.relativedelta(months=fide_time_frame)
            fide_end_date = target_date
            dates = {
                "start_date": start_date,
                "end_date": end_date,
                "fide_start_date": fide_start_date,
                "fide_end_date": fide_end_date
            }
            return dates
        else:
            return None

    @staticmethod
    def path_exists(path, spark_context):
        #validate path existance
        try:
            dataset = spark_context.textFile(path)
            dataset.take(1)
            return True
        except Py4JJavaError:
            return False
