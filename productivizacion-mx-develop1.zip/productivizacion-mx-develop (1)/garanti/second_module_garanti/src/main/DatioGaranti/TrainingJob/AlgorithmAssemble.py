from pyspark.mllib.regression import LabeledPoint
from pyspark.mllib.tree import RandomForest, RandomForestModel
from pyspark.sql.functions import col as c

""" This is the Algorithm Assemble component
    contains an assemble of ml machine learning nodes (random forest) that computes de probability to 
    belong a binary category
"""


class AlgorithmAssemble:
    """ Constructor: Initializes an AlgorithmAssemble instance
        Args:
            columnId: Sort of primary key for the Dataframe
            threshold: Double that determine the threshold for the fit process
    """
    def __init__(self, columnId, threshold=0.5):
        self.columnId = columnId
        self.threshold = threshold
        self.randomForestNode1 = None
        self.randomForestNode2 = None
        self.randomForestNode1Path = None
        self.randomForestNode2Path = None

    """Zips dataframes of labels and the dataframe of predictions
        Args:
            labelsDF: datframe that contains training instances,
            predictionsDF: datframe that contains training probabilities
    """
    def zipLabelsAndPredictions(self, labelsDF, predictionsDF):
        return labelsDF.map(lambda lp: (lp.features, lp.label)) \
            .zip(predictionsDF) \
            .map(lambda lp: (lp[0][0], lp[0][1], lp[1])) \
            .toDF(['features', 'label', 'prediction'])

    """Performs the fit of random fores node 1 and node 2
        Args:
            trainingDataNode1RDD: dataframe that contains training instances for node 1,
            trainingDataNode2RDD: dataframe that contains training instances for node 2
    """
    def fitAssemble(self, trainingDataNode1RDD, trainingDataNode2RDD):
        print('training node 1')
        randomForestNode1 = RandomForest.trainRegressor(data=trainingDataNode1RDD, categoricalFeaturesInfo={},
                                                        impurity='variance', maxDepth=10, maxBins=70, numTrees=250,
                                                        seed=12345)

        predictionsNode1RDD = randomForestNode1.predict(trainingDataNode2RDD.map(self.getFeatures))

        trainingLabelsAndPredictionsNode2DF = self.zipLabelsAndPredictions(trainingDataNode2RDD, predictionsNode1RDD)\
            .select('*').where(c('prediction') < self.threshold)

        trainingLabelsAndPredictionsNode2RDD = trainingLabelsAndPredictionsNode2DF.rdd.map(self.toLabeledPoint)

        print('training node 2')
        randomForestNode2 = RandomForest.trainRegressor(data=trainingLabelsAndPredictionsNode2RDD,
                                                        categoricalFeaturesInfo={}, impurity='variance', maxDepth=10,
                                                        maxBins=70, numTrees=250, seed=12345)

        return randomForestNode1, randomForestNode2

    """Definition for rdd map function
    """
    def toLabeledPoint(self, row):
        return LabeledPoint(row.label, row.features)

    """Definition for rdd map function
    """
    def getFeatures(self, row):
        return row.features

    """Generates oversampling and training datasets for node 1 and node 2, and perform the fit of the assemble
        Args:
            trainingDataDF: datframe that contains training instances,
            fractions: contains fractions of versampling classes,
            ratios: contains the simmple random ratios to generate node 1 and node 2 dataset
    """
    def fit(self, trainingDataDF, fractions={0: 1 / 85, 1: 1.0}, ratios=[0.6, 0.40]):
        stratifiedDataDF = trainingDataDF.sampleBy('label', fractions=fractions, seed=12345).cache()
        (trainingDataNode1DF, trainingDataNode2DF) = stratifiedDataDF.randomSplit(ratios, seed=12345)
        trainingDataNode1RDD = trainingDataNode1DF.rdd.map(self.toLabeledPoint)
        trainingDataNode2RDD = trainingDataNode2DF.rdd.map(self.toLabeledPoint)
        self.randomForestNode1, self.randomForestNode2 = self.fitAssemble(trainingDataNode1RDD, trainingDataNode2RDD)
        return self

    """ Save the Random Forest nodes, given a main path
        Args: 
            sc: Spark Context to implement
            path: String containing the main path to store the nodes
    """
    def saveRF(self, sc, path):
        self.randomForestNode1Path = path + "/randomForestNode1/"
        self.randomForestNode2Path = path + "/randomForestNode2/"

        try:
            self.randomForestNode1.save(sc, path=self.randomForestNode1Path)
            self.randomForestNode2.save(sc, path=self.randomForestNode2Path)

        except:
            print("model already saved")
            self.randomForestNode1 = RandomForestModel.load(sc, path=self.randomForestNode1Path)
            self.randomForestNode2 = RandomForestModel.load(sc, path=self.randomForestNode2Path)

    """ Returns the path of the first node of the Random Forest process
        Args: None
    """
    def getRandomForestNode1Path(self):
        return self.randomForestNode1Path

    """ Returns the path of the second node of the Random Forest process
        Args: None
    """
    def getRandomForestNode2Path(self):
        return self.randomForestNode2Path

    """ Function that calculates a behavior prediction given a dataset
        Args:
            datasetToPredictDF: Dataframe with the data to implement in order to give a prediction
        Return a Dataframe with the data of the prediction
    """
    def predict(self, datasetToPredictDF):
        dataSetDF = datasetToPredictDF.select([self.columnId, 'features'])

        predictionsNode1DF = self.randomForestNode1 \
            .predict(dataSetDF.rdd.map(lambda r: r.features)) \
            .zip(dataSetDF.rdd) \
            .map(lambda r: (r[1][0], r[0], r[1][1])) \
            .toDF([self.columnId, 'prediction', 'features'])
        upperlabelsAndPredictionsNode1DF = predictionsNode1DF.select('*').where(c('prediction') >= self.threshold)
        lowerLabelsAndFeaturessNode1DF = predictionsNode1DF.select('*').where(c('prediction') < self.threshold) \
            .select([self.columnId, 'features'])
        predictionsNode2RDD = self.randomForestNode2.predict(lowerLabelsAndFeaturessNode1DF \
                                                             .rdd.map(lambda x: x.features)) \
            .zip(lowerLabelsAndFeaturessNode1DF.rdd) \
            .map(lambda r: (r[1][0], r[0], r[1][1]))

        return upperlabelsAndPredictionsNode1DF.rdd.union(predictionsNode2RDD) \
            .map(lambda r: (r[0], float(r[1]), float(r[2][0]))) \
            .toDF([self.columnId, 'prediction', 'recurrent'])
