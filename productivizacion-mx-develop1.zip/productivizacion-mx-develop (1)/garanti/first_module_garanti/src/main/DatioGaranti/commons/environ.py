import os
import sys
#DAN from config import conf
from config import conf
''' MAW: change this implementation for json
if conf.get('GARANTI', 'local_mode')=="true":
    os.environ["SPARK_HOME"] = "/opt/spark-2.1.0-bin-hadoop2.7"
    os.environ["SPARK_JOB_HOME"] = "/root/"

    spark_home = os.environ.get('SPARK_HOME')
    sys.path.insert(0, spark_home + "/python")
    sys.path.insert(0, os.path.join(spark_home, 'python/lib/py4j-0.10.4-src.zip'))
'''


