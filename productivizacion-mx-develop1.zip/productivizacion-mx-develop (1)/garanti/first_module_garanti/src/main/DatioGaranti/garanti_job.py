import sys
from AnalyticBaseTableJob.main import ABTmain
from commons.logging_tools import log


class Job:
    @staticmethod
    def start(spark):
        log.info("Start Garanti ABT")

        argumento = sys.argv[1]
        log.info("argument: " + argumento)
        params = argumento

        abtProcess = ABTmain()
        abtProcess.run(params, spark)

        log.info("Finish Garanti ABT")
