# from config import config
from logging_tools import log
# from logging import log
from pyspark.sql import SparkSession

def spark_session():
    job_name= 'garanti_job' # config.get('GARANTI','job_name')
    #spark=SparkSession.builder.appName(job_name).master("spark://daniel-Inspiron-5567:7077").getOrCreate()
    spark=SparkSession.builder.appName(job_name).master("local").getOrCreate()
    #sc = spark.sparkContext
    log.info("Initiating SparkSession and SparkContext")
    return spark