class DateUtils:

    def __init__(self, monthTarget, yearTarget, monthsOffset, granularity):
        self.monthTarget = monthTarget
        self.yearTarget = yearTarget
        self.granularity = granularity

        self.yearPredict = yearTarget

        self.monthPredict = monthTarget - granularity - monthsOffset

        while self.monthPredict < 1:
            self.yearPredict -= 1
            self.monthPredict += 12

    def yearPredict(self):
        return self.yearPredict

    def monthPredict(self):
        return self.monthPredict