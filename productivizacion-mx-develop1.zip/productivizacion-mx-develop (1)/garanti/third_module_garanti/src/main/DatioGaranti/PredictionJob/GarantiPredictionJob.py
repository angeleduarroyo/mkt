from AnalyticBaseTableJob import AnalyticBaseTableJob
from GarantiUtils.DateUtils import DateUtils
from pyspark.sql import HiveContext
from FeatureTransformer import FeatureTransformer
from AlgorithmAssemble import AlgorithmAssemble
from GarantiUtils.InputUtils import InputUtils
from GarantiUtils.AnalyticUtils import AnalyticUtils


class GarantiPredictionJob:
    def __init__(self, params, abt_id, tnt_id):
        """ Constructor method, initializes variables in order to create an instance of this class
            Args:
                params: Dictionary that contains configuration variables
                abt_id: String. Hash value of the first module
                tnt_id: String. Hash value of the second module
        """
        self.params = params
        self.abt_id = abt_id
        self.tnt_id = tnt_id
        self.abtBlind = None
        self.spark = None
        self.utils = AnalyticUtils()

        # Initializes variables that are retrieved from InputUtils
        self.columnId = InputUtils.ABTColumnId
        self.schema = InputUtils.ABTInputScheme
        self.columnsToTransform = InputUtils.ABTColumnsToTransform

        # Handle lambdaCoefficient and shiftFactor variables for Testing process
        try:
            self.myLambdaCoefficient = params['lambdaCoefficient']
            if isinstance(self.myLambdaCoefficient, int):
                try:
                    self.myShiftFactor = params['shiftFactor']
                    if not isinstance(self.myShiftFactor, int):
                        self.myShiftFactor = None
                except:
                    self.myShiftFactor = None
            else:
                self.myLambdaCoefficient = None
                self.myShiftFactor = None
        except:
            self.myLambdaCoefficient = None
            self.myShiftFactor = None

        # Initializes variables in order to start the testing process
        self.garantiModel = AlgorithmAssemble(self.columnId)
        self.featureTransformer = FeatureTransformer(self.columnId, self.columnsToTransform,
                                                     self.myLambdaCoefficient, self.myShiftFactor)

    def getPredictABT(self, sc):
        """ Run the ABT process
            Receive a static url of the config json file
            then generates and persists the resulting ABT for Testing

            Args:
                sc: Spark Context
        """
        self.spark = sc

        # Load configuration file
        monthsOffset = 0
        monthTarget = self.params['targetMonth']
        yearTarget = self.params['targetYear']
        # monthsPeriod = self.params['periodMonths']
        granularity = 1

        dateUtils = DateUtils(monthTarget, yearTarget, monthsOffset, granularity)

        yearPredict = dateUtils.yearPredict
        monthPredict = dateUtils.monthPredict

        # Begin the process to generate the blind ABT
        abtBlindJob = AnalyticBaseTableJob(yearPredict, monthPredict, self.params)

        abtBlindJob.loadTables(HiveContext(sc))
        # Commented while the table VMIDSACM is not available
        # abtBlind.commerceFilters()
        abtBlindJob.vmidsatoFilters()
        abtBlindJob.generateCardLevelVariables()
        abtBlindJob.getTargetsAndRecurrents()
        abtBlindJob.addTargetsAndRecurrents()
        abtBlindJob.getCustomerInformation()
        abtBlindJob.addCustomerInformation()
        abtBlindJob.generateCustomerLevelAggregations()
        abtBlindJob.generateCustomerLevelVariables()
        abtBlindJob.getCustomerFinancialInformation()
        abtBlindJob.getPersonalCustomerInformation()
        abtBlindJob.createABT()
        # abtBlindJob.addColumnToABT('purpose_type', 'test')
        self.abtBlind = abtBlindJob.getABT()
        print("Generated ABT third module:")
        # self.abtBlind.show(5)
        return self.abtBlind

    def startTesting(self, abt, sc=None):
        """ Start the testing process
            Args:
                abt: Dataframe that contains the predict ABT
                sc: Optional SparkSession instance
            Return a dataframe with the prediction results
        """
        # Unit test Luis
        if sc is not None:
            self.spark = sc

        # Load the nodes from the training of the second module
        self.garantiModel.loadRandomForestNodes(self.spark.sparkContext, self.abt_id + "/" + self.tnt_id)

        # Load the predictive Dataframe
        tempABT = abt.select("*")
        testingDatasetDF = tempABT.dropna('any').select(self.schema)
        testingNormalizedDataframe = self.featureTransformer.transform(testingDatasetDF).cache()

        # testingNormalizedDataframe.show()

        # Get the Dataframe with the prediction results
        testPredictionsDatasetDF = self.garantiModel.predict(testingNormalizedDataframe) \
            .join(testingNormalizedDataframe, on=self.columnId) \
            .select([self.columnId, 'prediction', 'recurrent', 'execution_date'])
        return testPredictionsDatasetDF

    def persistModel(self, model):
        """Persist model into HDFS
            Args:
                model: Dataframe containing the model to persist
        """

        parquet_name = "/data/master/mpyt/data/garanti/t_mpyt_garanti_pred/" \
                       + self.abt_id + "/" + self.tnt_id + "/"

        model.cache()
        self.utils.persistDataFrameAsParquet(model, parquet_name)
        print("Prediction results saved at: ", parquet_name)
        return parquet_name
