
def save_parquet_file(df,path):
    return df.write.parquet(path)