import json
import time
from utils.logging_utils import log


def init_job(model_name, job_name):
    try:
        log.info("Initializing job")
        module_name = model_name + "_" + job_name
        log.info("Starting module " + module_name)

    except Exception as an_exception:
        module_name = None
        exception_message = an_exception.message
        log.info("Cannot get module info: " + exception_message)
    return module_name


def load_params(nexus_url):
    try:
        log.info("Parameters file: " + nexus_url)

        with open(nexus_url) as parameters_json:
            parameters = json.load(parameters_json)

    except ValueError as ve:
        raise ValueError(ve.message)

    except Exception as e:
        raise Exception("Error reading params: " + e.message)

    return parameters


def finish_job(module_name, start_time):
    try:
        log.info("Finishing module " + module_name)

        end = time.time()

        log.info("Finished job")
        log.info("Execution time of job %s seconds" % (end - start_time))

    except Exception as e:
        log.info("Error finishing module: " + e.message)


def parser_function(to_parse):
    if to_parse is None:
        return None

    elif len(str(to_parse)) == 1:
        return '0' + str(to_parse) \

    else:
        return str(to_parse)
