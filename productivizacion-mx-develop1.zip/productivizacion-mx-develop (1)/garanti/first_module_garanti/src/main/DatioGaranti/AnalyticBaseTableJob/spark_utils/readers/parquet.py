
def read_parquet_file(spark,path):
    return spark.read.parquet(path)