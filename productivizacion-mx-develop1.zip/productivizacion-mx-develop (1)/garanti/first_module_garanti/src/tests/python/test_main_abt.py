import unittest
from main.DatioGaranti.AnalyticBaseTableJob.main import ABTmain
from main.DatioGaranti.commons.init_spark_session import spark_session
from pyspark.sql import SQLContext


class TestABTMain(unittest.TestCase):
    """
    This class execute unit tests on the ABTmain class, included in this module
    """

    @staticmethod
    def make_test_instance():
        """
        Create an instance of the ABTmain class
        The majority of the Unit Tests executed in this class, need an instance of said class
        :return: An ABTmain instance
        """
        my_abt = ABTmain()
        return my_abt

    def make_expected_config(self):
        """
        Create a dictionary containing the expected values of a param file for the model
        :return: The dictionary with the expected values
        """
        test_abt = self.make_test_instance()
        expected_config = test_abt.load_config_file('tests/python/data/test_params.json')
        return expected_config

    def make_expected_time_frame(self):
        """
        Create a dictionary with example values that a time frame variable should contain
        :return: An expected time frame dictionary
        """
        test_abt = self.make_test_instance()
        expected_time_frame = test_abt.load_config_file('tests/python/data/expected_time_frame.json')
        return expected_time_frame

    @staticmethod
    def make_test_abt():
        """
        Create a dummy ABT, with dummy values that will be useful for testing methods that
        require this for a successful execution
        :return: A dataframe object which simulate an ABT
        """
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_df = test_sql_context.read.format('com.databricks.spark.csv') \
            .option("delimiter", ",") \
            .options(header='true', inferschema='true') \
            .load("tests/python/data/test_data_abt.csv")
        return test_df

    def test_load_config_file(self):
        """
        Test the load_config_file method, that load the parameters file into a dictionary,
        and checks that have the same properties as expected
        """
        test_abt = self.make_test_instance()
        test_config = self.make_expected_config()

        loaded_config = test_abt.load_config_file('tests/python/data/test_params.json')

        self.assertEqual(test_config, loaded_config)

    def test_generate_hash_value(self):
        """
        Test the generate_hash_value method, that generate a hash value for the job execution
        and checks that have the required structure to consider it valid
        """
        test_abt = self.make_test_instance()
        test_config = self.make_expected_config()
        test_hash = test_abt.generate_hash_value(test_config)

        self.assertIsInstance(test_hash, basestring)

    def test_generate_time_frame(self):
        """
        Test the generate_time_frame method, which create a dictionary with the time frame values required to
        generate the ABTs required for the execution of the second module of Garanti
        Check that the generated dictionary has the expected structure of response
        """
        test_abt = self.make_test_instance()
        test_config = self.make_expected_config()
        test_time_frame = self.make_expected_time_frame()
        loaded_time_frame = test_abt.generate_time_frame(test_config)

        self.assertEqual(test_time_frame, loaded_time_frame)

    def test_generate_abt(self):
        """
        Test the generate_abt method, which create an ABT which will be the input for the training, or testing
        process, of the second module of Garanti
        Check that the generated ABT has the expected structure, so the second module can run properly
        """
        test_abt = self.make_test_instance()
        test_config = self.make_expected_config()
        test_session = spark_session()
        test_result = test_abt.generate_abt(2017, 3, 'test', test_config, test_session)
        test_abt_columns_number = len(test_result.columns)
        #This was modified D: by LPH
        test_expected_columns = 91
        self.assertEqual(test_expected_columns, test_abt_columns_number)

    def test_persist_abts(self):
        """
        Test the persist_abts method, which store two ABTs into a distributed file in Parquet,
        and return the HDFS path in which both dataframes has been persisted
        Check that the path has the expected structure to consider it valid
        """
        test_abt = self.make_test_instance()
        test_df = self.make_test_abt()
        test_id = "1a2b3c"
        test_path = test_abt.persist_abts(test_df, test_df, test_id)

        self.assertIsInstance(test_path, basestring)

    def test_run(self):
        """
        Test the run method, which can be considered as the 'main' method of the ABTmain class,
        because it execute all methods listed above, in order to generate the ABTs that are required to execute
        the second module, and storing them into HDFS.
        Check that the program flow is executed as intended, and validate the structure of the output path
        """
        test_abt = self.make_test_instance()
        test_config_file = 'tests/python/data/test_params.json'
        test_session = spark_session()
        test_abt.run(test_config_file, test_session)
        test_path = test_abt.path
        self.assertIsInstance(test_path, basestring)


#if __name__ == '__main__':
#    unittest.main()
