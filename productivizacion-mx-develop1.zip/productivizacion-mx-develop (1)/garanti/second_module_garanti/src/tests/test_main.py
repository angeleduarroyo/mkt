import unittest
from tests.python.test_algorithmAssemble import TestAlgorithmAssemble
from tests.python.test_featureTransformer import TestFeatureTransformer
from tests.python.test_garantiTrainingJob import TestGarantiTrainingJob


def suite():
    test_suite = unittest.TestSuite()
    test_suite.addTest(TestAlgorithmAssemble('test_zipLabelsAndPredictions'))
    test_suite.addTest(TestAlgorithmAssemble('test_fitAssemble'))
    test_suite.addTest(TestAlgorithmAssemble('test_fit'))
    test_suite.addTest(TestAlgorithmAssemble('test_saveRF'))
    test_suite.addTest(TestAlgorithmAssemble('test_predict'))

    test_suite.addTest(TestFeatureTransformer('test_transform'))

    test_suite.addTest(TestGarantiTrainingJob('test_error_init'))
    test_suite.addTest(TestGarantiTrainingJob('test_loadABT'))
    test_suite.addTest(TestGarantiTrainingJob('test_startTraining'))
    test_suite.addTest(TestGarantiTrainingJob('test_startTesting'))
    test_suite.addTest(TestGarantiTrainingJob('test_persistModel'))
    test_suite.addTest(TestGarantiTrainingJob('test_persistModelTest'))

    return test_suite


if __name__ == '__main__':
    runner = unittest.TextTestRunner()
    runner.run(suite())