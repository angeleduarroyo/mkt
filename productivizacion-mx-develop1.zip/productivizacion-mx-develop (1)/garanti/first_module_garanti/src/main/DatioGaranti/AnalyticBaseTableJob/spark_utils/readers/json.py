
def read_json_file(spark,path):
    return spark.read.json(path)