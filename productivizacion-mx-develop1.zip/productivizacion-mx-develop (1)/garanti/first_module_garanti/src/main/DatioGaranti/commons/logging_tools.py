import logging

logging.basicConfig(format='%(asctime)s %(levelname)s %(name)s: %(message)s',
                    datefmt='%y/%m/%d %H:%M:%S')
log_instance = logging.getLogger('JobLog')
log_instance.setLevel("INFO")
log=log_instance

