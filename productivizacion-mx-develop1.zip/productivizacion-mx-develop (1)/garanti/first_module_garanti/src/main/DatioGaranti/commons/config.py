import sys
# DAN Python3+
# import configparser
# DAN Python2.7
import ConfigParser


configFile = sys.argv[1]
# DAN
config = ConfigParser.ConfigParser()
# config = configparser.ConfigParser()
# config.read(configFile)
conf = config

