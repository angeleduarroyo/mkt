def save_csv_file(df,path):
    return df.write.csv(path)