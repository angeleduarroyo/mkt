from pyspark.sql.functions import col as c
import numpy as np
import pandas as pd
from pylab import *
import matplotlib.pyplot as plt
from pyspark.sql import functions as f
from pyspark.mllib.evaluation import *
from pyspark.sql.window import Window
from pyspark.sql.functions import *


class AnalyticMetrics(object):
    """
        This is the AnalyticMetrics component.
        Creates the necessary metrics to understand the statistical health of the model
    """
    def __init__(self, sc, first_hash, second_hash):
        """
            Constructor, initialize all the attribute variables
        """
        self.spark = sc
        self.abtHash = first_hash
        self.tntHash = second_hash
        self.recurrentSummary = None
        self.metricas = None
        self.rankSummary = None
        self.universeTwentyPercent = None
        self.recallTwentyPercent = None
        self.imputeTarget = lambda value, threshold: float(1.0) if(value >= threshold) else float(0.0)

    def loadTesting(self):
        fullPath = "/data/master/mpyt/data/garanti/t_mpyt_garanti_tnt/test/" + self.abtHash + "/" + self.tntHash + "/*"
        return self.spark.read.parquet(fullPath)

    def computeSummaryRecurrentMetrics(self, p, validatingLabelsAndPredictionsDF):
        """
            Creates a DataFrame with relevant information about recurrency
            Args:
                p: Threshold
                validatingLabelsAndPredictionsDF: Predictions Spark DataFrame
        """
        imputeTarget = self.imputeTarget

        self.recurrentSummary = validatingLabelsAndPredictionsDF.select('recurrent', 'label', 'prediction') \
            .rdd.map(lambda r: (r[0], r[1], imputeTarget(r[2], p))) \
            .toDF(['Recurrentes', 'Target', 'Label']) \
            .dropna('any') \
            .groupBy('Recurrentes', 'Target', 'Label').count() \
            .select('Recurrentes', 'Target', 'Label', c('count').alias('Conteo')).toPandas()
        index = ['Model', 'Recurrent', 'Model with Recurrent']
        columns = ['Efectividad', 'Recall', 'POB', 'POB_Efectiva', 'Universo']
        self.metricas = pd.DataFrame(index=index, columns=columns)

        self.metricas.Efectividad['Model'] = np.sum(self.recurrentSummary.Conteo[(self.recurrentSummary.Label == 1) & \
                                                                                 (self.recurrentSummary.Target == 1)])*1.0 \
                                             /np.sum(self.recurrentSummary.Conteo[(self.recurrentSummary.Label == 1)])
        self.metricas.Recall['Model'] = np.sum(self.recurrentSummary.Conteo[(self.recurrentSummary.Label == 1) & \
                                                                            (self.recurrentSummary.Target == 1)])*1.0 \
                                        /np.sum(self.recurrentSummary.Conteo[(self.recurrentSummary.Target == 1)])
        self.metricas.POB['Model'] = np.sum(self.recurrentSummary.Conteo[(self.recurrentSummary.Label == 1)])*1.0
        self.metricas.POB_Efectiva['Model'] = np.sum(self.recurrentSummary.Conteo[(self.recurrentSummary.Label == 1) & \
                                                                                  (self.recurrentSummary.Target == 1)])*1.0
        self.metricas.Universo['Model'] = np.sum(self.recurrentSummary.Conteo[(self.recurrentSummary.Label == 1)])*1.0 \
                                          /np.sum(self.recurrentSummary.Conteo)

        self.metricas.Efectividad['Recurrent'] = np.sum(self.recurrentSummary. \
                                                        Conteo[(self.recurrentSummary.Recurrentes == 1) & \
                                                               (self.recurrentSummary.Target == 1)])*1.0 \
                                                 /np.sum(self.recurrentSummary.Conteo[(self.recurrentSummary.Recurrentes == 1)])
        self.metricas.Recall['Recurrent'] = np.sum(self.recurrentSummary. \
                                                   Conteo[(self.recurrentSummary.Recurrentes == 1) & \
                                                          (self.recurrentSummary.Target == 1)])*1.0 \
                                            /np.sum(self.recurrentSummary.Conteo[(self.recurrentSummary.Target == 1)])
        self.metricas.POB['Recurrent'] = np.sum(self.recurrentSummary.Conteo[(self.recurrentSummary.Recurrentes == 1)])*1.0
        self.metricas.POB_Efectiva['Recurrent'] = np.sum(self.recurrentSummary. \
                                                         Conteo[(self.recurrentSummary.Recurrentes == 1) & \
                                                                (self.recurrentSummary.Target == 1)])*1.0
        self.metricas.Universo['Recurrent'] = np.sum(self.recurrentSummary.Conteo[(self.recurrentSummary.Recurrentes == 1)])*1.0 \
                                              /np.sum(self.recurrentSummary.Conteo)

        self.metricas.Efectividad['Model with Recurrent'] = np.sum(self.recurrentSummary. \
                                                                   Conteo[(self.recurrentSummary.Label == 1) & \
                                                                          (self.recurrentSummary.Recurrentes == 1) & \
                                                                          (self.recurrentSummary.Target == 1)])*1.0 \
                                                            /np.sum(self.recurrentSummary.Conteo[(self.recurrentSummary.Label == 1) & \
                                                                                                 (self.recurrentSummary.Recurrentes == 1)])
        self.metricas.Recall['Model with Recurrent'] = np.sum(self.recurrentSummary. \
                                                              Conteo[(self.recurrentSummary.Label == 1) & \
                                                                     (self.recurrentSummary.Recurrentes == 1) & \
                                                                     (self.recurrentSummary.Target == 1)])*1.0 \
                                                       /np.sum(self.recurrentSummary.Conteo[(self.recurrentSummary.Target == 1)])
        self.metricas.POB['Model with Recurrent'] = np.sum(self.recurrentSummary.Conteo[(self.recurrentSummary.Label == 1) & \
                                                                                        (self.recurrentSummary.Recurrentes == 1)])*1.0
        self.metricas.POB_Efectiva['Model with Recurrent'] = np.sum(self.recurrentSummary. \
                                                                    Conteo[(self.recurrentSummary.Label == 1) & \
                                                                           (self.recurrentSummary.Recurrentes == 1) & \
                                                                           (self.recurrentSummary.Target == 1)])*1.0
        self.metricas.Universo['Model with Recurrent'] = np.sum(self.recurrentSummary.Conteo[(self.recurrentSummary.Label == 1) & \
                                                                                             (self.recurrentSummary.Recurrentes == 1)])*1.0 \
                                                         /np.sum(self.recurrentSummary.Conteo)
        dfToPersist = self.metricas.reset_index(drop=True)
        dfToPersist.columns = ["contact_effectiveness_per", "contact_catchment_per", "target_population_number",
                               "effective_target_population_number", "universe_per"]
        fullHash = self.abtHash + self.tntHash
        dfToPersist = dfToPersist.assign(execution_id=fullHash)
        # PENDING: PERSIST THE DATAFRAME FROM ABOVE
        # dfToPersist.to_parquet("/data/master/mpyt/data/garanti/t_mpyt_metrics/" + self.abtHash + "/" + self.tntHash)
        self.metricas.columns = ['Effectiveness', 'Recall', 'Population', 'Effective population', 'Universe']
        return self.metricas

    def validatingMetrics(self, validatingLabelsAndPredictionsDF):
        """Prints the Area under Precision Recall Curve and Area under Receiver Operating Characteristic Curve

        Args:
            validatingLabelsAndPredictionsDF: Predictions Spark DataFrame

        """
        fullHash = self.abtHash + self.tntHash
        validatingMetrics = BinaryClassificationMetrics(validatingLabelsAndPredictionsDF.select('prediction', 'label').rdd)
        data = {
            'area_under_curve_per': [validatingMetrics.areaUnderPR],
            'roc_curve_per': [validatingMetrics.areaUnderROC],
            'execution_id': [fullHash]
        }
        dftoPersist = pd.DataFrame(data)
        # PENDING: PERSIST THE DATAFRAME FROM ABOVE
        # dfToPersist.to_parquet("/data/master/mpyt/data/garanti/t_mpyt_area_under_curve/" + self.abtHash + "/" + self.tntHash)
        index = ['Area under the precision recall curve', 'Area under the Receiver Operating Characteristic curve']
        columns = ['area']
        dftoShow = pd.DataFrame(index=index, columns=columns)
        dftoShow.area['Area under the precision recall curve'] = str(validatingMetrics.areaUnderPR)
        dftoShow.area['Area under the Receiver Operating Characteristic curve'] = str(validatingMetrics.areaUnderROC)
        return dftoShow

    def computeStaticMetricsByThreshold(self, validatingLabelsAndPredictionsDF):
        """Prints the Confussion Matrix, Precision, Recall and fMeasure by Threshold

        Args:
            validatingLabelsAndPredictionsDF: Predictions Spark DataFrame

        """
        imputeTarget = self.imputeTarget

        schemaStaticMetricsTable = ['threshold', 'TrueNegatives', 'FalseNegatives',
                                    'FalsePositives', 'TruePositives',
                                    'PrecisionTrue', 'PrecisionFalse', 'RecallTrue',
                                    'RecallFalse', 'ScoreF1']
        staticMetricsTable = []
        for p in np.arange(0, 1, 0.1):
            imputedPredictionsDF = validatingLabelsAndPredictionsDF.select('prediction', 'label') \
                .rdd.map(lambda r: (imputeTarget(r[0], p), r[1])) \
                .toDF(['prediction', 'label']) \
                .dropna('any')
            testStaticMetricsMulticlass = MulticlassMetrics(imputedPredictionsDF.rdd)
            confusionMatrix = testStaticMetricsMulticlass.confusionMatrix().toArray()
            rowTuple = [p,
                        confusionMatrix[0][0],
                        confusionMatrix[0][1],
                        confusionMatrix[1][0],
                        confusionMatrix[1][1],
                        testStaticMetricsMulticlass.precision(1),
                        testStaticMetricsMulticlass.precision(0),
                        testStaticMetricsMulticlass.recall(1),
                        testStaticMetricsMulticlass.recall(0),
                        testStaticMetricsMulticlass.fMeasure()]
            staticMetricsTable.append(rowTuple)

        fullHash = self.abtHash + self.tntHash
        dftoPersist = pd.DataFrame(staticMetricsTable)
        dftoPersist.columns = ['threshold_per', 'true_negatives_number', 'false_negatives_number',
                               'false_positives_number', 'true_positives_number', 'precision_true_per',
                               'precision_false_per', 'recall_true_per', 'recall_false_per', 'score_f_per']
        dftoPersist = dftoPersist.assign(execution_id=fullHash)
        # PENDING: PERSIST THE DATAFRAME FROM ABOVE
        # dfToPersist.to_parquet("/data/master/mpyt/data/garanti/t_mpyt_static_metrics/" + self.abtHash + "/" + self.tntHash)
        return pd.DataFrame(staticMetricsTable, columns=schemaStaticMetricsTable)

    def plotBinaryTargetsDensitiesHistograms(self,validatingLabelsAndPredictionsDF,limitNegativeClass,bins=40,alpha=0.65):
        """Plots the densities by class

           Args:
             validatingLabelsAndPredictionsDF: Predictions Spark DataFrame
             limitNegativeClass: Number of observations from the negative class to consider in the plot
             bins: Number of bars in the histogram
             alpha: The alpha blending value
        """
        class0 = validatingLabelsAndPredictionsDF.where(c('label')==0) \
            .limit(limitNegativeClass) \
            .select('prediction') \
            .toPandas()
        class1 = validatingLabelsAndPredictionsDF.where(c('label')==1) \
            .select('prediction') \
            .toPandas()
        plt.style.use('ggplot')
        plt.figure(figsize=(20,10))
        plt.hist(class0['prediction'],color='Blue',alpha=alpha,bins=bins)
        plt.hist(class1['prediction'],color='Red',alpha=alpha,bins=bins)
        return plt.show()

    def computeStaticMetricsByRanking(self, partitionSize, validatingLabelsAndPredictionsDF):
        """Prints the Cumulative Efective POB, Cumulative POB, Cumulative Effectiveness, Cumulative Recall and Cumulative Universe

        Args:
            partitionSize: Number of observations by each rank
            validatingLabelsAndPredictionsDF: Predictions Spark DataFrame

        """
        rank = (f.dense_rank().over(Window.orderBy(c('prediction').desc())))
        ranking = validatingLabelsAndPredictionsDF.select('*',
                                                          f.floor(rank/partitionSize).alias('rank'))

        wf = Window.partitionBy('aux').rowsBetween(-sys.maxsize, 0)
        wf2 = Window.partitionBy('aux')

        self.rankSummary = ranking.groupBy('rank').agg(f.sum('label').alias('efectivos'), f.count('*').alias('enviados'), \
                                                       lit(1).alias('aux')) \
            .select('*'
                    , (f.sum('efectivos').over(wf)).alias('ac_efectivos')
                    , (f.sum('enviados').over(wf)).alias('ac_enviados')
                    , (f.sum('efectivos').over(wf)/f.sum('enviados').over(wf)).alias('efectividad')
                    , (f.sum('efectivos').over(wf)/f.sum('efectivos').over(wf2)).alias('recall')
                    , (f.sum('enviados').over(wf)/f.sum('enviados').over(wf2)).alias('universo')
                    ).toPandas()

        self.universeTwentyPercent = self.rankSummary[self.rankSummary['universo'] >= .2][0:1]
        self.recallTwentyPercent = self.rankSummary[self.rankSummary['recall'] >= .2][0:1]

        fullHash = self.abtHash + self.tntHash
        dftoPersist = self.rankSummary
        dftoPersist.columns = ['rank_group_number', 'rank_effective_customers_number', 'sent_customers_number', 'aux',
                               'cumulative_effective_customers_number', 'cumulative_sent_customers_number',
                               'rank_contact_effectiveness_per', 'rank_contact_catchment_per', 'rank_universe_per']
        dftoPersist = dftoPersist.assign(execution_id=fullHash)
        dftoPersist.drop('aux', axis=1, inplace=True)
        # PENDING: PERSIST THE DATAFRAME FROM ABOVE
        # dfToPersist.to_parquet("/data/master/mpyt/data/garanti/t_mpyt_rank_summary/" + self.abtHash + "/" + self.tntHash)
        self.rankSummary.columns = ['rank', 'effective', 'sent', 'aux', 'total_effective', 'total_sent',
                                    'effectiveness', 'recall', 'universe']
        return self.rankSummary

    def plotUniverseRecall(self):
        """Shows the Universe vs Recall plot and compares the development of the model taking the top 20% universe against
        recurrents and random selection

        """
        sDF = self.rankSummary[(self.rankSummary['universe'] <= float(self.universeTwentyPercent.universo))]
        x1= np.array(sDF['universe'])
        y1= np.array(sDF['recall'])

        sDF2 = self.rankSummary[(self.rankSummary['universe'] >= float(self.universeTwentyPercent.universo))]
        x2= np.array(sDF2['universe'])
        y2= np.array(sDF2['recall'])

        x3= np.array([0,1])
        y3= np.array([0,1])

        plt.figure(figsize=(20,10)).suptitle('Universe vs Recall', fontsize=45)
        plt.plot(self.rankSummary['universe'],self.rankSummary['recall'],label='RecallFalse')
        plt.fill_between(x1, y1, color='blue', alpha= 0.5)
        plt.fill_between(x2, y2, color='blue',alpha= 0.25)
        plt.fill_between(x3, y3, color='black',alpha= 0.5)

        axes = plt.gca()
        axes.set_xlim([0,1])
        axes.set_ylim([0,1])

        plt.xlabel('Universe', fontsize=30)
        plt.ylabel('Recall', fontsize=30)

        x1=[float(self.universeTwentyPercent.universo),float(self.universeTwentyPercent.universo)]
        y1=[0,float(self.universeTwentyPercent.recall)]
        x2=[0,float(self.universeTwentyPercent.universo)]
        y2=[float(self.universeTwentyPercent.recall),float(self.universeTwentyPercent.recall)]
        point1=[float(self.universeTwentyPercent.universo)]
        point2=[float(self.universeTwentyPercent.recall)]
        plt.plot(x1,y1,color='r',ls='--',lw=5)
        plt.plot(x2,y2,color='r',ls='--',lw=5)
        plt.scatter(point1,point2,marker='o',c='r',s=350)

        x1=[float(self.universeTwentyPercent.recall),float(self.universeTwentyPercent.recall)]
        y1=[0,float(self.universeTwentyPercent.recall)]
        x2=[0,float(self.universeTwentyPercent.recall)]
        y2=[float(self.universeTwentyPercent.recall),float(self.universeTwentyPercent.recall)]
        point1=[float(self.universeTwentyPercent.recall)]
        point2=[float(self.universeTwentyPercent.recall)]
        plt.plot(x1,y1,color='r',ls='--',lw=5)
        plt.plot(x2,y2,color='r',ls='--',lw=5)
        plt.scatter(point1,point2,marker='o',c='r',s=350)

        x1=[self.metricas.Universe[1],self.metricas.Universe[1]]
        y1=[0,self.metricas.Recall[1]]
        x2=[0,self.metricas.Universe[1]]
        y2=[self.metricas.Recall[1],self.metricas.Recall[1]]
        point1=[self.metricas.Universe[1]]
        point2=[self.metricas.Recall[1]]
        plt.plot(x1,y1,color='r',ls='--',lw=5)
        plt.plot(x2,y2,color='r',ls='--',lw=5)
        plt.scatter(point1,point2,marker='*',c='r',s=350)

        gca().set_yticklabels(['{:.0f}%'.format(x*100) for x in gca().get_yticks()])
        gca().set_xticklabels(['{:.0f}%'.format(x*100) for x in gca().get_xticks()])

        plt.annotate('MODEL SELECTION', xy=(0.13, 0.78), xytext=(12, -12), va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')
        plt.annotate('20.0% of the universe,', xy=(0.14, 0.73), xytext=(12, -12), va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')
        plt.annotate(str(float(np.round(self.universeTwentyPercent.recall*100))) + '% of recall', xy=(0.13, 0.68), \
                     xytext=(12, -12), va='top',xycoords='axes fraction', textcoords='offset points', fontsize=15, \
                     color='black',fontweight='bold')

        plt.annotate('RANDOM SELECTION', \
                     xy=(float(np.round(self.universeTwentyPercent.recall,2)), \
                         float(np.round(self.universeTwentyPercent.recall,2))+.15) \
                     , xytext=(12, -12), va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')
        plt.annotate(str(float(np.round(self.universeTwentyPercent.recall*100))) + '% of the universe,', \
                     xy=(float(np.round(self.universeTwentyPercent.recall,2)), \
                         float(np.round(self.universeTwentyPercent.recall,2))+.1), \
                     xytext=(12, -12), va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')
        plt.annotate(str(float(np.round(self.universeTwentyPercent.recall*100))) + '% of recall', \
                     xy=(float(np.round(self.universeTwentyPercent.recall,2)), \
                         float(np.round(self.universeTwentyPercent.recall,2))+.05), xytext=(12, -12), va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')

        plt.annotate('RECURRENT SELECTION', xy=(self.metricas.Universe[1], self.metricas.Recall[1]+.15), xytext=(12, -12), \
                     va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')
        plt.annotate(str(np.round(self.metricas.Universe[1]*100)) + '% of the universe,', \
                     xy=(self.metricas.Universe[1], self.metricas.Recall[1]+.1), xytext=(12, -12), va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')
        plt.annotate(str(np.round(self.metricas.Recall[1]*100)) + '% of recall', \
                     xy=(self.metricas.Universe[1], self.metricas.Recall[1]+.05), xytext=(12, -12), va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')
        return plt.show()

    def plotUniverseEffectiveness(self):
        """Shows the Universe vs Effectiveness plot  and compares the development of the model taking the top 20% universe against
        recurrents and random selection

        """
        sDF = self.rankSummary[(self.rankSummary['universe'] <= float(self.universeTwentyPercent.universo))]
        x1= np.array(sDF['universe'])
        y1= np.array(sDF['effectiveness'])

        sDF2 = self.rankSummary[(self.rankSummary['universe'] >= float(self.universeTwentyPercent.universo)) & \
                                (self.rankSummary['universe'] <= float(self.universeTwentyPercent.recall))]
        x2= np.array(sDF2['universe'])
        y2= np.array(sDF2['effectiveness'])

        sDF3 = self.rankSummary[self.rankSummary['universe'] >= float(self.universeTwentyPercent.recall)]
        x3= np.array(sDF3['universe'])
        y3= np.array(sDF3['effectiveness'])

        plt.figure(figsize=(20,10)).suptitle('Universe vs Effectiveness', fontsize=45)
        plt.plot(self.rankSummary['universe'],self.rankSummary['effectiveness'],label='RecallFalse')
        plt.fill_between(x1, y1, color='blue', alpha= 0.5)
        plt.fill_between(x2, y2, color='blue',alpha= 0.25)
        plt.fill_between(x3, y3, color='black',alpha= 0.5)

        axes = plt.gca()
        axes.set_xlim([0,1])
        axes.set_ylim([0,np.max(self.rankSummary.effectiveness)])

        plt.xlabel('Universe', fontsize=30)
        plt.ylabel('Effectiveness', fontsize=30)

        x1=[float(self.universeTwentyPercent.universo),float(self.universeTwentyPercent.universo)]
        y1=[0,float(self.universeTwentyPercent.efectividad)]
        x2=[0,float(self.universeTwentyPercent.universo)]
        y2=[float(self.universeTwentyPercent.efectividad),float(self.universeTwentyPercent.efectividad)]
        point1=[float(self.universeTwentyPercent.universo)]
        point2=[float(self.universeTwentyPercent.efectividad)]
        plt.plot(x1,y1,color='r',ls='--',lw=5)
        plt.plot(x2,y2,color='r',ls='--',lw=5)
        plt.scatter(point1,point2,marker='o',c='r',s=350)

        x1=[float(self.universeTwentyPercent.recall),float(self.universeTwentyPercent.recall)]
        y1=[0,float(self.universeTwentyPercent.efectividad)]
        x2=[0,float(self.universeTwentyPercent.recall)]
        y2=[float(self.universeTwentyPercent.efectividad),float(self.universeTwentyPercent.efectividad)]
        point1=[float(self.universeTwentyPercent.recall)]
        point2=[float(self.universeTwentyPercent.efectividad)]
        plt.plot(x1,y1,color='r',ls='--',lw=5)
        plt.plot(x2,y2,color='r',ls='--',lw=5)
        plt.scatter(point1,point2,marker='o',c='r',s=350)

        x1=[self.metricas.Universe[1],self.metricas.Universe[1]]
        y1=[0,self.metricas.Effectiveness[1]]
        x2=[0,self.metricas.Universe[1]]
        y2=[self.metricas.Effectiveness[1],self.metricas.Effectiveness[1]]
        point1=[self.metricas.Universe[1]]
        point2=[self.metricas.Effectiveness[1]]
        plt.plot(x1,y1,color='r',ls='--',lw=5)
        plt.plot(x2,y2,color='r',ls='--',lw=5)
        plt.scatter(point1,point2,marker='*',c='r',s=350)

        gca().set_yticklabels(['{:.0f}%'.format(x*100) for x in gca().get_yticks()])
        gca().set_xticklabels(['{:.0f}%'.format(x*100) for x in gca().get_xticks()])

        plt.annotate('MODEL SELECTION', xy=(0.14,float(np.round(self.universeTwentyPercent.efectividad+.3,2))), \
                     xytext=(12, -12), \
                     va='top',xycoords='axes fraction', textcoords='offset points', fontsize=15, \
                     color='black',fontweight='bold')
        plt.annotate('20.0% of the universe,', xy=(0.14,float(np.round(self.universeTwentyPercent.efectividad,2))+.25), \
                     xytext=(12, -12), va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')
        plt.annotate(str(float(np.round(self.universeTwentyPercent.efectividad*100))) + '% of effectiveness', \
                     xy=(0.14,float(np.round(self.universeTwentyPercent.efectividad,2))+.2), xytext=(12, -12), va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')

        plt.annotate('RANDOM SELECTION', xy=(float(np.round(self.universeTwentyPercent.recall,2)), \
                                             float(np.round(self.universeTwentyPercent.efectividad,2))+.3), \
                     xytext=(12, -12), va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')
        plt.annotate(str(float(np.round(self.universeTwentyPercent.recall*100))) + '% of the universe,', \
                     xy=(float(np.round(self.universeTwentyPercent.recall,2)), \
                         float(np.round(self.universeTwentyPercent.efectividad,2))+.25), \
                     xytext=(12, -12), va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')
        plt.annotate(str(float(np.round(self.universeTwentyPercent.efectividad*100))) + '% of effectiveness', \
                     xy=(float(np.round(self.universeTwentyPercent.recall,2)), \
                         float(np.round(self.universeTwentyPercent.efectividad,2))+.2), xytext=(12, -12), va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')

        plt.annotate('RECURRENT SELECTION', xy=(self.metricas.Universe[1], self.metricas.Effectiveness[1]+.8), \
                     xytext=(12, -12), \
                     va='top',xycoords='axes fraction', textcoords='offset points', fontsize=15, \
                     color='black',fontweight='bold')
        plt.annotate(str(np.round(self.metricas.Universe[1]*100)) + '% of the universe,', xy=(self.metricas.Universe[1], \
                                                                                              self.metricas.Effectiveness[1]+.75), \
                     xytext=(12, -12), va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')
        plt.annotate(str(np.round(self.metricas.Effectiveness[1]*100)) + '% of effectiveness', xy=(self.metricas.Universe[1], \
                                                                                                   self.metricas.Effectiveness[1]+.7), \
                     xytext=(12, -12), va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')
        return plt.show()

    def plotRecallEffectiveness(self):
        """Shows the Recall vs Effectiveness plot and compares the development of the model taking the top 20% universe against
        recurrents and random selection
        """
        sDF = self.rankSummary[(self.rankSummary['recall'] <= float(self.recallTwentyPercent.recall))]
        x1= np.array(sDF['recall'])
        y1= np.array(sDF['effectiveness'])

        sDF2 = self.rankSummary[(self.rankSummary['recall'] >= float(self.recallTwentyPercent.recall)) & \
                                (self.rankSummary['recall'] <= float(self.universeTwentyPercent.recall))]
        x2= np.array(sDF2['recall'])
        y2= np.array(sDF2['effectiveness'])

        sDF3 = self.rankSummary[self.rankSummary['recall'] >= float(self.universeTwentyPercent.recall)]
        x3= np.array(sDF3['recall'])
        y3= np.array(sDF3['effectiveness'])

        plt.figure(figsize=(20,10)).suptitle('Recall vs Effectiveness', fontsize=45)
        plt.plot(self.rankSummary['recall'],self.rankSummary['effectiveness'],label='RecallFalse')
        plt.fill_between(x1, y1, color='blue', alpha= 0.5)
        plt.fill_between(x2, y2, color='blue',alpha= 0.25)
        plt.fill_between(x3, y3, color='black',alpha= 0.5)

        axes = plt.gca()
        axes.set_xlim([0,1])
        axes.set_ylim([0,np.max(self.rankSummary.effectiveness)])

        plt.xlabel('Recall', fontsize=30)
        plt.ylabel('Effectiveness', fontsize=30)

        x1=[float(self.recallTwentyPercent.recall),float(self.recallTwentyPercent.recall)]
        y1=[0,float(self.recallTwentyPercent.efectividad)]
        x2=[0,float(self.recallTwentyPercent.recall)]
        y2=[float(self.recallTwentyPercent.efectividad),float(self.recallTwentyPercent.efectividad)]
        point1=[float(self.recallTwentyPercent.recall)]
        point2=[float(self.recallTwentyPercent.efectividad)]
        plt.plot(x1,y1,color='r',ls='--',lw=5)
        plt.plot(x2,y2,color='r',ls='--',lw=5)
        plt.scatter(point1,point2,marker='o',c='r',s=350)

        x1=[float(self.universeTwentyPercent.recall),float(self.universeTwentyPercent.recall)]
        y1=[0,float(self.universeTwentyPercent.efectividad)]
        x2=[0,float(self.universeTwentyPercent.recall)]
        y2=[float(self.universeTwentyPercent.efectividad),float(self.universeTwentyPercent.efectividad)]
        point1=[float(self.universeTwentyPercent.recall)]
        point2=[float(self.universeTwentyPercent.efectividad)]
        plt.plot(x1,y1,color='r',ls='--',lw=5)
        plt.plot(x2,y2,color='r',ls='--',lw=5)
        plt.scatter(point1,point2,marker='o',c='r',s=350)

        x1=[self.metricas.Recall[1],self.metricas.Recall[1]]
        y1=[0,self.metricas.Effectiveness[1]]
        x2=[0,self.metricas.Recall[1]]
        y2=[self.metricas.Effectiveness[1],self.metricas.Effectiveness[1]]
        point1=[self.metricas.Recall[1]]
        point2=[self.metricas.Effectiveness[1]]
        plt.plot(x1,y1,color='r',ls='--',lw=5)
        plt.plot(x2,y2,color='r',ls='--',lw=5)
        plt.scatter(point1,point2,marker='*',c='r',s=350)

        gca().set_yticklabels(['{:.0f}%'.format(x*100) for x in gca().get_yticks()])
        gca().set_xticklabels(['{:.0f}%'.format(x*100) for x in gca().get_xticks()])

        plt.annotate('MODEL SELECTION', xy=(0.14,float(np.round(self.recallTwentyPercent.efectividad+.3,2))), \
                     xytext=(12, -12), \
                     va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')
        plt.annotate('20.0% of recall,', xy=(0.14,float(np.round(self.recallTwentyPercent.efectividad,2))+.25), \
                     xytext=(12, -12), \
                     va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')
        plt.annotate(str(float(np.round(self.recallTwentyPercent.efectividad*100))) + '% of effectiveness', \
                     xy=(0.14,float(np.round(self.recallTwentyPercent.efectividad,2))+.2), xytext=(12, -12), va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')

        plt.annotate('RANDOM SELECTION', xy=(float(np.round(self.universeTwentyPercent.recall,2)), \
                                             float(np.round(self.universeTwentyPercent.efectividad,2))+.3), \
                     xytext=(12, -12), va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')
        plt.annotate(str(float(np.round(self.universeTwentyPercent.recall*100))) + '% of recall,', \
                     xy=(float(np.round(self.universeTwentyPercent.recall,2)), \
                         float(np.round(self.universeTwentyPercent.efectividad,2))+.25), xytext=(12, -12), va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')
        plt.annotate(str(float(np.round(self.universeTwentyPercent.efectividad*100))) + '% of effectiveness', \
                     xy=(float(np.round(self.universeTwentyPercent.recall,2)), \
                         float(np.round(self.universeTwentyPercent.efectividad,2))+.2), xytext=(12, -12), va='top',
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')

        plt.annotate('RECURRENT SELECTION', xy=(self.metricas.Recall[1], self.metricas.Effectiveness[1]+.8), \
                     xytext=(12, -12), va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')
        plt.annotate(str(np.round(self.metricas.Recall[1]*100)) + '% of recall,', xy=(self.metricas.Recall[1], \
                                                                                      self.metricas.Effectiveness[1]+.75), \
                     xytext=(12, -12), va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')
        plt.annotate(str(np.round(self.metricas.Effectiveness[1]*100)) + '% of effectiveness', xy=(self.metricas.Recall[1], \
                                                                                                   self.metricas.Effectiveness[1]+.7), \
                     xytext=(12, -12), va='top', \
                     xycoords='axes fraction', textcoords='offset points', fontsize=15, color='black',fontweight='bold')
        return plt.show()
