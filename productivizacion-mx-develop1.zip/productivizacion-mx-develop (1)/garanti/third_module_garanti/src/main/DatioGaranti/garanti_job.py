import hashlib
import json
import sys
from PredictionJob.commons.init_spark_session import spark_session
from PredictionJob.GarantiPredictionJob import GarantiPredictionJob
from PredictionJob.commons import log


class Job:
    @staticmethod
    def start(spark):
        # Initialize variables
        sc = spark
        fractionsValue = None
        log.info("Start Garanti Model")

        # Declare an display a message for the execution of the job
        input = "HelloThirdModule"
        output = "GoodbyeThirdModule"
        log.info(input)

        # Load the parameters in the configuration file
        confFile = sys.argv[1]
        log.info("configurationFile: " + confFile)
        params = confFile
        with open(params) as params_json:
            p = json.load(params_json)

        # Initializes a Spark session
        # spark = spark_session()

        # Declare hash values for every module before
        fullArray = p['bines'] + p['commerces']
        fullHash = hashlib.sha256(str(fullArray).encode('utf-8', 'ignore')).hexdigest()
        abt_id = str(p['periodMonths']) + str(p['recurrentMonths']) + str(p['targetMonth']) + str(p['targetYear']) + \
                 fullHash

        # Display the hash value of the first module
        print ("abt_id: " + abt_id)

        # Handle variables in order to get the hash value of the second module
        preFractionsValue = p['fractions']
        if isinstance(preFractionsValue, dict):
            fractionsValue = {}
            for key in preFractionsValue.keys():
                fractionsValue[int(key)] = float(preFractionsValue[key])
            fractionsValue = fractionsValue
        try:
            ratioValue = p['ratios']
        except:
            ratioValue = None
        try:
            myLambdaCoefficient = p['lambdaCoefficient']
            if isinstance(myLambdaCoefficient, int):
                try:
                    myShiftFactor = p['shiftFactor']
                    if not isinstance(myShiftFactor, int):
                        myShiftFactor = None
                except:
                    myShiftFactor = None
            else:
                myLambdaCoefficient = None
                myShiftFactor = None
        except:
            myLambdaCoefficient = None
            myShiftFactor = None
        fullKey = str(fractionsValue) + str(ratioValue) + str(myLambdaCoefficient) + str(myShiftFactor)
        tnt_id = hashlib.sha256(fullKey).hexdigest()

        # Display the hash value of the second module
        print ('tnt_id: ' + tnt_id)

        # Initializes and get the predictive ABT
        garantiPredictionJob = GarantiPredictionJob(p, abt_id, tnt_id)
        predictABT = garantiPredictionJob.getPredictABT(sc)

        # predictABT.show()

        # Calculates and persist the predictive model
        testModel = garantiPredictionJob.startTesting(predictABT)

        # testModel.show()

        garantiPredictionJob.persistModel(testModel)

        # Implement in a Jupyter notebook
        # The percentage parameter may not be in the final version of the config file
        # percentage = p['percentage']

        # am.computeSummaryRecurrentMetrics(percentage)
        # am.validatingMetrics()
        # am.computeStaticMetricsByThreshold()

        log.info(output)
