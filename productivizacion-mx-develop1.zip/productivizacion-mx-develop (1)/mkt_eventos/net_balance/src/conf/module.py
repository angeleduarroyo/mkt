
MODEL_NAME = "mkt_eventos"
JOB_NAME = "net_balance"
SPARK_MASTER = "local"
