"""
    Script for TMLARA14 scheme
"""

information_date = "information_date"
transaction_date = "transaction_date"

reference_number = "reference_number"
operation_amount = "operation_amount"
channel_id = "channel_id"
destiny_type = "destiny_type"
error_type = "error_type"
fuction_id = "fuction_id"
destiny_id = "destiny_id"
reverse_type = "reverse_type"


fields = [reference_number, operation_amount, channel_id, destiny_type, error_type, fuction_id, destiny_id, reverse_type]
