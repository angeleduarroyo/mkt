class DateUtils:

    def __init__(self, monthTarget, yearTarget, monthsOffset, monthsPeriod, granularity):
        self.monthTarget = monthTarget
        self.yearTarget = yearTarget
        self.monthsPeriod = monthsPeriod
        self.granularity = granularity

        self.yearTrain = yearTarget
        self.yearBlind = yearTarget

        self.monthTrain = monthTarget - monthsPeriod * granularity - granularity * 2 - monthsOffset
        self.monthBlind = monthTarget - granularity * 2 - monthsOffset

        while self.monthTrain < 1:
            self.yearTrain -= 1
            self.monthTrain += 12

        while self.monthBlind < 1:
            self.yearBlind -= 1
            self.monthBlind += 12

    def yearTrain(self):
        return self.yearTrain

    def monthTrain(self):
        return self.monthTrain

    def yearBlind(self):
        return self.yearBlind

    def monthBlind(self):
        return self.monthBlind