import unittest
from main.DatioGaranti.AnalyticBaseTableJob.GarantiUtils.SchemeDictionary import SchemeDictionaryABTOut
from main.DatioGaranti.AnalyticBaseTableJob.AnalyticBaseTableJob import AnalyticBaseTableJob
from main.DatioGaranti.AnalyticBaseTableJob.main import ABTmain
from main.DatioGaranti.commons.init_spark_session import spark_session
from tests.python.classes.TestDatio import TestDatio
from pyspark.sql import SQLContext
from pyspark.sql.functions import col
import json


class TestAnalyticBaseTableJob(unittest.TestCase):
    """
    This class execute unit tests on the AnalyticBaseTableJob class, included in this module
    """

    def load_json(self, nexus_url):  # copia de load_config_file en main
        """
        Load a json dictionary
        :type nexus_url: basestring
        """
        with open(nexus_url) as json_file:
            properties = json.load(json_file)
        return properties

    def make_parameters(self):
        """
        Create the expected values of a config file
        :return: A dictionary with the expected proper values of a config file
        """
        test_main = ABTmain()
        expected_config = test_main.load_config_file('tests/python/data/test_params.json')
        return expected_config

    def make_abt_instance(self):
        """
        Create a dummy instance of the AnalyticBaseTableJob class, which will be useful for some of the
        unit tests created below
        :return: An AnalyticBaseTableJob instance
        """
        test_year = 2017
        test_month = 6
        test_params = self.make_parameters()
        test_instance = AnalyticBaseTableJob(test_year, test_month, test_params)
        return test_instance

    def assert_not_empty_data(self, abt_instance):
        """
        Checks that every loaded table has been initialized correctly
        :param abt_instance: Instance of AnalyticBaseTableJob which will be tested
        """
        self.assertIsNotNone(abt_instance.wtFide117DF)
        self.assertIsNotNone(abt_instance.wtInfoCte543DF)
        self.assertIsNotNone(abt_instance.wtContrato806DF)
        self.assertIsNotNone(abt_instance.wtVmidsatoDF)

    def test_loadTables(self):
        """
        Test the loadTables method, which reads the paths of all of the required tables for the execution of the
        model, which are persisted in HDFS, and create a dataframe for every table required
        Check that every table has been loaded properly
        """

        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        self.assert_not_empty_data(test_instance)

    def test_schemas(self):
        '''
        Check the Schema of every table
        :return:
        '''

        tables_schemas = self.load_json('tests/python/data/test_schemas.json')
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_schema = TestDatio()
        self.assertTrue(test_schema.compareSchema(test_instance.wtFide117DF,tables_schemas['schema117']))
        self.assertTrue(test_schema.compareSchema(test_instance.wtInfoCte543DF,tables_schemas['schemaInfoCte543']))
        self.assertTrue(test_schema.compareSchema(test_instance.wtContrato806DF,tables_schemas['schemaContrato806']))
        self.assertTrue(test_schema.compareSchema(test_instance.wtVmidsatoDF,tables_schemas['schemaVmidsato']))

    def test_vmidsatoFilters(self):
        """
        Test the vmidsatoFilters method, which generates a new dataframe with data on the VMIDSATO table
        Check that the new dataframe has been loaded properly
        """
        test_schema = TestDatio()
        tables_schemas = self.load_json('tests/python/data/test_schemas.json')

        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        self.assertIsNotNone(test_instance.wtVmidsatoFilteredDF)
        self.assertTrue(test_schema.compareSchema(test_instance.wtVmidsatoFilteredDF,tables_schemas['schemaVmidsato']))

    def test_generateCardLevelVariables(self):
        """
        Test the generateCardLevelVariables method, which generates a new dataframe
        Check that the new dataframe has been loaded properly
        """
        test_schema = TestDatio()
        tables_schemas = self.load_json('tests/python/data/test_schemas.json')

        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_expected = 49

        self.assertIsNotNone(test_instance.cardLevelVariables)
        self.assertEqual(test_expected, len(test_instance.cardLevelVariables.columns))
        self.assertTrue(test_schema.compareSchema(test_instance.cardLevelVariables, tables_schemas['cardLevelVariablesSchema']))

    def test_getTargetsAndRecurrents(self):
        """
        Test the getTargetsAndRecurrents method, which generates a new dataframe
        Check that the new dataframe has been loaded properly
        """

        test_schema = TestDatio()
        tables_schemas = self.load_json('tests/python/data/test_schemas.json')

        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_instance.getTargetsAndRecurrents()
        test_expected = 3

        self.assertIsNotNone(test_instance.targetsAndRecurrentes)
        self.assertEqual(test_expected, len(test_instance.targetsAndRecurrentes.columns))
        self.assertTrue(test_schema.compareSchema(test_instance.targetsAndRecurrentes, tables_schemas['targetsAndRecurrentesSchema']))

    def test_addTargetsAndRecurrents(self):
        """
        Test the addTargetsAndRecurrents method, which generates a new dataframe
        Check that the new dataframe has been loaded properly
        """
        test_schema = TestDatio()
        tables_schemas = self.load_json('tests/python/data/test_schemas.json')

        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_instance.getTargetsAndRecurrents()
        test_instance.addTargetsAndRecurrents()
        test_expected = 54
        self.assertIsNotNone(test_instance.cardLevelVariables)
        self.assertEqual(test_expected, len(test_instance.cardLevelVariables.columns))
        self.assertTrue(test_schema.compareSchema(test_instance.cardLevelVariables, tables_schemas['addTargetsandRecurrentscardLevelVariablesSchema']))

    def test_getCustomerInformation(self):
        """
        Test the getCustomerInformation method, which generates a new dataframe
        Check that the new dataframe has been loaded properly
        """
        test_schema = TestDatio()
        tables_schemas = self.load_json('tests/python/data/test_schemas.json')

        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_instance.getTargetsAndRecurrents()
        test_instance.addTargetsAndRecurrents()
        test_instance.getCustomerInformation()
        test_expected = 4
        self.assertIsNotNone(test_instance.customerInformation)
        self.assertEqual(test_expected, len(test_instance.customerInformation.columns))
        self.assertTrue(test_schema.compareSchema(test_instance.customerInformation, tables_schemas['getCustomerInformationSchema']))

    def test_addCustomerInformation(self):
        """
        Test the addCustomerInformation method, which generates a new dataframe
        Check that the new dataframe has been loaded properly
        """
        test_schema = TestDatio()
        tables_schemas = self.load_json('tests/python/data/test_schemas.json')

        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_instance.getTargetsAndRecurrents()
        test_instance.addTargetsAndRecurrents()
        test_instance.getCustomerInformation()
        test_instance.addCustomerInformation()
        test_expected = 58
        self.assertIsNotNone(test_instance.cardLevelVariables)
        self.assertEqual(test_expected, len(test_instance.cardLevelVariables.columns))
        self.assertTrue(test_schema.compareSchema(test_instance.cardLevelVariables, tables_schemas['addCustomerInformationSchema']))

    def test_generateCustomerLevelAggregations(self):
        """
        Test the generateCustomerLevelAggregations method, which generates a new dataframe
        Check that the new dataframe has been loaded properly
        """
        test_schema = TestDatio()
        tables_schemas = self.load_json('tests/python/data/test_schemas.json')

        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_instance.getTargetsAndRecurrents()
        test_instance.addTargetsAndRecurrents()
        test_instance.getCustomerInformation()
        test_instance.addCustomerInformation()
        test_instance.generateCustomerLevelAggregations()
        test_expected = 46
        self.assertIsNotNone(test_instance.customerLevelVariables)
        self.assertEqual(test_expected, len(test_instance.customerLevelVariables.columns))
        self.assertTrue(test_schema.compareSchema(test_instance.customerLevelVariables, tables_schemas['generateCustomerLevelAggregationsSchema']))

    def test_getCustomerFinancialInformation(self):
        """
        Test the getCustomerFinancialInformation method, which generates a new dataframe
        Check that the new dataframe has been loaded properly
        """
        test_schema = TestDatio()
        tables_schemas = self.load_json('tests/python/data/test_schemas.json')

        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_instance.getTargetsAndRecurrents()
        test_instance.addTargetsAndRecurrents()
        test_instance.getCustomerInformation()
        test_instance.addCustomerInformation()
        test_instance.generateCustomerLevelAggregations()
        test_instance.getCustomerFinancialInformation()
        test_expected = 6
        self.assertIsNotNone(test_instance.customerFinancialInformation.where(col(SchemeDictionaryABTOut.tenencia_tdc) == 1).count())
        self.assertIsNotNone(test_instance.customerFinancialInformation)
        self.assertEqual(test_expected, len(test_instance.customerFinancialInformation.columns))
        self.assertTrue(test_schema.compareSchema(test_instance.customerFinancialInformation, tables_schemas['getCustomerFinancialInformationSchema']))

    def test_getPersonalCustomerInformation(self):
        """
        Test the getPersonalCustomerInformation method, which generates a new dataframe
        Check that the new dataframe has been loaded properly
        """
        test_schema = TestDatio()
        tables_schemas = self.load_json('tests/python/data/test_schemas.json')

        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_instance.getTargetsAndRecurrents()
        test_instance.addTargetsAndRecurrents()
        test_instance.getCustomerInformation()
        test_instance.addCustomerInformation()
        test_instance.generateCustomerLevelAggregations()
        test_instance.getCustomerFinancialInformation()
        test_instance.getPersonalCustomerInformation()
        test_expected = 8
        #self.assertIsNotNone(test_instance.personalCustomerInformation)
        #self.assertIsNotNone(test_instance.personalCustomerInformation.select(col('customer1_id')))
        #print "Esto es getPersonalCustomerInformation"
        #for i in test_instance.personalCustomerInformation.columns:
        #    print "Esto es getPersonalCustomerInformation " + i
        #print "getPersonalCustomerInformation tiene " + str(len(test_instance.personalCustomerInformation.columns))
        #jschemaDF = json.loads(test_instance.personalCustomerInformation.schema.json())
        #squemaDF = {x["name"]:x["type"] for x in jschemaDF["fields"]}
        #print(squemaDF)
        self.assertEqual(test_expected, len(test_instance.personalCustomerInformation.columns))
        self.assertTrue(test_schema.compareSchema(test_instance.personalCustomerInformation, tables_schemas['getPersonalCustomerInformationSchema']))

    def test_createABT(self):
        """
        Test the createABT method, which generates a final dataframe which will be the ABT to persist
        Check that the created ABT has been generated correctly
        """
        test_schema = TestDatio()
        tables_schemas = self.load_json('tests/python/data/test_schemas.json')

        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_instance.getTargetsAndRecurrents()
        test_instance.addTargetsAndRecurrents()
        test_instance.getCustomerInformation()
        test_instance.addCustomerInformation()
        test_instance.generateCustomerLevelAggregations()
        test_instance.generateCustomerLevelVariables()
        test_instance.getCustomerFinancialInformation()
        test_instance.getPersonalCustomerInformation()
        test_instance.createABT()
        test_abt_columns_number = len(test_instance.abt.columns)
        test_expected_columns = 90
        self.assertIsNotNone(test_instance.abt)
        self.assertEqual(test_expected_columns, test_abt_columns_number)
        self.assertTrue(test_schema.compareSchema(test_instance.abt, tables_schemas['schemaABT']))

    def test_addColumnToABT(self):
        """
        Test the addColumnToABT method, which appends a column with the execution ID of the job in order to persist
        the ABT into HDFS
        Check that the column has been correctly appended into the ABT
        """
        test_schema = TestDatio()
        tables_schemas = self.load_json('tests/python/data/test_schemas.json')

        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_instance.getTargetsAndRecurrents()
        test_instance.addTargetsAndRecurrents()
        test_instance.getCustomerInformation()
        test_instance.addCustomerInformation()
        test_instance.generateCustomerLevelAggregations()
        test_instance.generateCustomerLevelVariables()
        test_instance.getCustomerFinancialInformation()
        test_instance.getPersonalCustomerInformation()
        test_instance.createABT()
        test_abt = test_instance.abt
        test_abt_columns_number = len(test_abt.columns)
        test_expected_columns = 90
        self.assertIsNotNone(test_abt)
        self.assertEqual(test_expected_columns, test_abt_columns_number)
        self.assertTrue(test_schema.compareSchema(test_abt, tables_schemas['schemaABT']))
        test_instance.addColumnToABT('hola', 1)
        test_abt2 = test_instance.abt
        self.assertIsNotNone(test_abt2.select('hola'))

    def test_getABT(self):
        """
        Test the getABT method, which returns the processed ABT, which will be loaded into the second module
        Check that the ABT has been generated correctly
        """

        test_schema = TestDatio()
        tables_schemas = self.load_json('tests/python/data/test_schemas.json')

        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_instance.getTargetsAndRecurrents()
        test_instance.addTargetsAndRecurrents()
        test_instance.getCustomerInformation()
        test_instance.addCustomerInformation()
        test_instance.generateCustomerLevelAggregations()
        test_instance.generateCustomerLevelVariables()
        test_instance.getCustomerFinancialInformation()
        test_instance.getPersonalCustomerInformation()
        test_instance.createABT()
        test_abt = test_instance.getABT()
        test_abt_columns_number = len(test_abt.columns)
        test_expected_columns = 90
        self.assertIsNotNone(test_abt)
        self.assertEqual(test_expected_columns, test_abt_columns_number)
        self.assertTrue(test_schema.compareSchema(test_abt, tables_schemas['schemaABT']))


#if __name__ == '__main__':
#    unittest.main()