import unittest
import json
from main.DatioGaranti.PredictionJob.spark_utils.readers import parquet
from main.DatioGaranti.PredictionJob.GarantiPredictionJob import GarantiPredictionJob
from main.DatioGaranti.PredictionJob.commons.init_spark_session import spark_session
from pyspark.sql import SQLContext


class TestGarantiPredictionJob(unittest.TestCase):
    """
    This class execute unit tests on the ABTmain class, included in this module
    """

    @staticmethod
    def make_expected_parameters(path):
        """
        Create the expected values of a config file
        :return: A dictionary with the expected proper values of a config file
        """
        with open(path) as params_json:
            params_dict = json.load(params_json)
        return params_dict

    def make_test_instance(self):
        """
        Create an instance of the ABTmain class
        The majority of the Unit Tests executed in this class, need an instance of said class
        :return: An ABTmain instance
        """
        test_params = self.make_expected_parameters('tests/python/data/test_params.json')
        test_hash_abt = "31282017075f540c304c047a85cce12d172d84934c691c419cf5b83a8144ca884cda119b/"
        test_hash_tnt = "d23d277c9eaa75f1353f6f7dff580fe4584602041e3e7e0cf7985ec5bdd613ec"
        my_prediction_job = GarantiPredictionJob(test_params, test_hash_abt, test_hash_tnt)
        return my_prediction_job

    @staticmethod
    def make_test_dataframe():
        """
        Create a dummy dataframe, which is required for some of the unit tests in this class
        :return: A dummy dataframe
        """
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_dataframe = parquet.read_parquet_file(test_sql_context, 'tests/python/data/garanti_abt/*').dropna('any')
        return test_dataframe

    def test_getPredictABT(self):
        """
        Check that the ABT obtained from getPredictABT has a correct structure
        """
        test_instance = self.make_test_instance()
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_abt = test_instance.getPredictABT(test_sql_context)
        self.assertIsNotNone(test_abt)

    def test_startTesting(self):
        """
        Check that the model obtained from startTesting has a correct structure
        """
        test_instance = self.make_test_instance()
        test_sql_context = spark_session()
        test_abt = self.make_test_dataframe()
        test_prediction = test_instance.startTesting(test_abt, test_sql_context)
        self.assertIsNotNone(test_prediction)

    def test_persistModel(self):
        """
        Check that the generated path obtained from persistModel has been successfully structured
        """
        test_instance = self.make_test_instance()
        test_sql_context = spark_session()
        test_abt = self.make_test_dataframe()
        test_prediction = test_instance.startTesting(test_abt, test_sql_context)
        test_path = test_instance.persistModel(test_prediction)
        response_df = parquet.read_parquet_file(SQLContext(spark_session().sparkContext), test_path)
        self.assertIsNotNone(response_df)


if __name__ == '__main__':
    unittest.main()
