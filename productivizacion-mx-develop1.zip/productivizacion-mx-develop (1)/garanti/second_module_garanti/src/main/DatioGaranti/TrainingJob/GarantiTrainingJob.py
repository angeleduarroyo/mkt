import hashlib

from pyspark.sql.functions import col

from AlgorithmAssemble import AlgorithmAssemble
from FeatureTransformer import FeatureTransformer
from GarantiUtils.AnalyticUtils import AnalyticUtils
from GarantiUtils.InputUtils import InputUtils
from GarantiUtils.SchemeDictionary import SchemeDictionaryABTOut
from spark_utils.readers import parquet

""" This is the GarantiTrainingJob component
    Initializes and retrieves the training and testing models, with the option to persist
"""


class GarantiTrainingJob:
    """ Constructor: Initializes an instance of GarantiTrainingJob
        Args:
            p: Dictionary with parameters
            run_id: ABT execution id
    """
    def __init__(self, p, run_id):
        self.abt_id = run_id

        # Declare a column ID
        self.columnId = InputUtils.ABTColumnId

        # Retrieve parameters from InputUtils
        self.columnLabel = InputUtils.ABTColumnLabel
        self.schema = InputUtils.ABTInputScheme
        self.columnsToTransform = InputUtils.ABTColumnsToTransform

        # Retrieve parameters from the config file
        preFractionsValue = p['fractions']

        if isinstance(preFractionsValue, dict):
            fractionsValue = {}

            for key in preFractionsValue.keys():
                fractionsValue[int(key)] = float(preFractionsValue[key])

            self.fractionsValue = fractionsValue

        try:
            self.ratioValue = p['ratios']

        except:
            self.ratioValue = None

        try:
            self.myLambdaCoefficient = p['lambdaCoefficient']

            if isinstance(self.myLambdaCoefficient, int):
                try:
                    self.myShiftFactor = p['shiftFactor']

                    if not isinstance(self.myShiftFactor, int):
                        self.myShiftFactor = None

                except:
                    self.myShiftFactor = None

            else:
                self.myLambdaCoefficient = None
                self.myShiftFactor = None

        except:
            self.myLambdaCoefficient = None
            self.myShiftFactor = None

        # Initialize properties
        self.modelPath = None
        self.rootPath = None
        self.utils = AnalyticUtils()
        self.featureTransformer = None
        self.garantiModel = None
        self.completeDataSetDF = None

    """ Load complete ABT data, for post filtering
        Args:
            sc: Spark Context
    """
    def loadABT(self, sc):
        self.completeDataSetDF = parquet \
            .read_parquet_file(sc, '/data/master/mpyt/data/garanti/t_mpyt_garanti_abt/'
                               + self.abt_id)\
            .dropna('any')

    """ Execute the training process
        Args:
            none
    """
    def startTraining(self):
        trainingDatasetDF = self.completeDataSetDF.select(self.schema)\
            .where((col(SchemeDictionaryABTOut.id_ejecucion) == self.abt_id)
                   & (col(SchemeDictionaryABTOut.proposito) == 'train'))

        self.featureTransformer = FeatureTransformer(self.columnId, self.columnLabel, self.columnsToTransform,
                                                     self.myLambdaCoefficient, self.myShiftFactor)

        trainingNormalizedDataframe = self.featureTransformer.transform(trainingDatasetDF)

        # print("Training normalized DF")
        # trainingNormalizedDataframe.show()

        garantiAssemble = AlgorithmAssemble(self.columnId)

        if self.fractionsValue:
            if self.ratioValue:
                self.garantiModel = garantiAssemble.fit(trainingNormalizedDataframe, self.fractionsValue,
                                                        self.ratioValue)
            else:
                self.garantiModel = garantiAssemble.fit(trainingNormalizedDataframe, self.fractionsValue)

        else:
            self.garantiModel = garantiAssemble.fit(trainingNormalizedDataframe)

        return self.garantiModel

    """ Execute the testing process
        Args:
            none
    """
    def startTesting(self):
        testingDatasetDF = self.completeDataSetDF.select(self.schema)\
            .where((col(SchemeDictionaryABTOut.id_ejecucion) == self.abt_id)
                   & (col(SchemeDictionaryABTOut.proposito) == 'test'))

        testingNormalizedDataframe = self.featureTransformer.transform(testingDatasetDF).cache()

        # print("Testing normalized dataset")
        # testingNormalizedDataframe.show()

        testPredictionsDatasetDF = self.garantiModel.predict(testingNormalizedDataframe)\
            .join(testingNormalizedDataframe, on=self.columnId)\
            .select([self.columnId, 'prediction', 'label', 'recurrent'])

        # print("Tested dataset")
        # testPredictionsDatasetDF.show()

        return testPredictionsDatasetDF

    """Persist model into HDFS
        Args:
            sc: Spark Context
            name: name for model, could be train or test
    """
    def persistModel(self, sc, name):
        fullKey = str(self.fractionsValue) + str(self.ratioValue) + str(self.myLambdaCoefficient) \
                  + str(self.myShiftFactor)

        tnt_id = hashlib.sha256(fullKey).hexdigest()

        finalPath = "/data/master/mpyt/data/garanti/t_mpyt_garanti_tnt/" \
                    + name + "/" + self.abt_id + "/" + tnt_id

        self.garantiModel.saveRF(sc, finalPath)

        print("random forest model saved at: " + finalPath)
        return finalPath

    """ Persist the test of model into HDFS
        Args:
            model: Dataframe containing the test for the model
            modelType: String that indicates the path
    """
    def persistModelTest(self, model, modelType):
        fullKey = str(self.fractionsValue) + str(self.ratioValue) + str(self.myLambdaCoefficient) \
                  + str(self.myShiftFactor)

        tnt_id = hashlib.sha256(fullKey).hexdigest()

        parquet_name = "/data/master/mpyt/data/garanti/t_mpyt_garanti_tnt/" \
                       + modelType + "/" + self.abt_id + "/" + tnt_id + "/"

        model.cache()
        self.utils.persistDataFrameAsParquet(model, parquet_name)

        print("rows in tested dataframe: ", model.count())
        print("dataframe saved at: ", parquet_name)
        return parquet_name
