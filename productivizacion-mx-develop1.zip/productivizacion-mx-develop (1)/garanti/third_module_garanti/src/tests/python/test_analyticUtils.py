import unittest
from main.DatioGaranti.PredictionJob.GarantiUtils.AnalyticUtils import AnalyticUtils


class TestAnalyticUtils(unittest.TestCase):
    """
    This class execute unit tests on the AnalyticUtils class, included in this module
    """

    @staticmethod
    def make_test_instance():
        """
        Create a dummy instance of the AnalyticUtils class
        :return: An AnalyticUtils instance
        """
        my_abt = AnalyticUtils()
        return my_abt

    def assert_parsed_dates(self, date, cutoff_date, date_target):
        """
        Check that every of the generated dates have a correct structure
        :param date: String with the date of the first day of the time frame to analyze
        :param cutoff_date: String with the cutoff date of a month to analyze
        :param date_target: String with the target date of the time frame to analyze
        """
        self.assertIsInstance(date, basestring)
        self.assertIsInstance(cutoff_date, basestring)
        self.assertIsInstance(date_target, basestring)

    def test_parseDates(self):
        """
        Check that the time frame has been correctly generated
        """
        test_instance = self.make_test_instance()
        test_date, test_cutoff_date, test_date_target = test_instance.parseDates(2017, 1)
        self.assert_parsed_dates(test_date, test_cutoff_date, test_date_target)


if __name__ == '__main__':
    unittest.main()
