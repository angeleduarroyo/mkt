
def save_json_file(df,path):
    return df.write.json(path)