import math as mt

from pyspark.ml.feature import VectorAssembler
from pyspark.mllib.util import MLUtils
from pyspark.ml.pipeline import Transformer
from pyspark.sql.functions import udf, col
from pyspark.sql.types import FloatType, StringType


class FeatureTransformer(Transformer):
    """ It has been suggested by the IDE to implement all abstract methods inherited from Transformer
    """
    def _transform(self, dataset):
        pass

    """ Constructor: Initializes an instance of FeatureTransformer
        Args:
            columnId: Name of the primary column of the dataframe
            columnLabel: Name of the column to manipulate
            columnsToTransform: Array containing names of columns, according to Governance
            lambdaCoef: Integer that represents the lambda coefficient
            shiftFact: Integer that represents the shift factor for model processing
    """
    def __init__(self, columnId, columnLabel, columnsToTransform, lambdaCoef, shiftFac):
        super(FeatureTransformer, self).__init__()
        self.columnId = columnId
        self.columnLabel = columnLabel
        self.columnsToTransform = columnsToTransform
        self.nonTransformableCols = None
        self.lambdaCoefficient = lambdaCoef
        self.shiftFactor = shiftFac

    """ Applies transformation algorithm to a given dataFrame
        Args:
            inputDatasetDF: DataFrame to transform
            params: arg defined un super class
    """
    def transform(self, inputDatasetDF, params=None):
        def transformToLabeledPointDF(dataSetDF):
            features = [colName for colName in dataSetDF.columns
                        if colName not in [self.columnId, self.columnLabel]]

            assembler = VectorAssembler(inputCols=features, outputCol='features')
            dataSetDF = assembler.transform(dataSetDF)

            dataSetDF = MLUtils.convertVectorColumnsFromML(dataSetDF, 'features')

            return dataSetDF.select(col(self.columnId).cast(StringType()),
                                    col(self.columnLabel).cast(FloatType()).alias('label'), 'features')

        def transformDataframeToBoxCoxScale(dataSetDF, lambdaCoefficient=0, shiftFactor=1):
            def transformToBoxCoxScale(real):
                transformedReal = 0
                if lambdaCoefficient == 0:
                    try:
                        transformedReal = mt.log(float(real) + shiftFactor)
                    except:
                        transformedReal = float(0)

                else:
                    try:
                        transformedReal = (mt.pow((float(real) + shiftFactor), lambdaCoefficient) - 1) / lambdaCoefficient
                    except:
                        transformedReal = float(0)

                return transformedReal

            myUdf = udf(transformToBoxCoxScale, FloatType())

            for column in self.columnsToTransform:
                dataSetDF = dataSetDF.withColumn("boxcox_" + column, myUdf(col(column)))

            return dataSetDF

        columns = inputDatasetDF.columns
        newColumns = []

        for column in columns:
            if column in self.columnsToTransform:
                newColumns.append("boxcox_" + column)

            else:
                newColumns.append(column)

        if isinstance(self.lambdaCoefficient, int):
            if isinstance(self.shiftFactor, int):
                normalizedDataSetDF = transformDataframeToBoxCoxScale(inputDatasetDF, self.lambdaCoefficient,
                                                                      self.shiftFactor)
            else:
                normalizedDataSetDF = transformDataframeToBoxCoxScale(inputDatasetDF, self.lambdaCoefficient)
        else:
            normalizedDataSetDF = transformDataframeToBoxCoxScale(inputDatasetDF)

        normalizedDataSetDF = normalizedDataSetDF.select(newColumns)

        # print("BoxCoxScaleDF")
        # normalizedDataSetDF.show()

        return transformToLabeledPointDF(normalizedDataSetDF)
