import importlib
import time

from DatioGaranti.commons.logging_tools import log
from DatioGaranti.commons.init_spark_session import spark_session
from DatioGaranti.garanti_job import Job

if __name__ == "__main__":
    # SparkSession, config parser and logging object are initiated in commons module
    spark = spark_session()

    module_name = "garanti_abt"
    log.info("Module name: " + module_name)

    job_name = 'DatioGaranti.garanti_job'
    log.info("Job name: " + job_name)
    start = time.time()

    log.info("Starting job %s" % module_name)

    job_module = importlib.import_module(job_name)

    # Instantiated job
    garantiJob = Job()

    # Started job
    garantiJob.start(spark)

    end = time.time()
    spark.stop()

    log.info("Finished job %s" % module_name)
    log.info("Execution of job %s took %s seconds" % (job_module, end - start))
