import unittest
import json
from main.DatioGaranti.PredictionJob.AnalyticBaseTableJob import AnalyticBaseTableJob
from main.DatioGaranti.PredictionJob.commons.init_spark_session import spark_session
from pyspark.sql import SQLContext


class TestAnalyticBaseTableJob(unittest.TestCase):
    """
    This class execute unit tests on the AnalyticBaseTableJob class, included in this module
    """

    @staticmethod
    def make_parameters(path):
        """
        Create the expected values of a config file
        :return: A dictionary with the expected proper values of a config file
        """
        with open(path) as params_json:
            params_dict = json.load(params_json)
        return params_dict

    def make_abt_instance(self):
        """
        Create a dummy instance of the AnalyticBaseTableJob class, which will be useful for some of the
        unit tests created below
        :return: An AnalyticBaseTableJob instance
        """
        test_year = 2017
        test_month = 6
        test_params = self.make_parameters("tests/python/data/test_params.json")
        test_instance = AnalyticBaseTableJob(test_year, test_month, test_params)
        return test_instance

    def assert_not_empty_data(self, abt_instance):
        """
        Checks that every loaded table has been initialized correctly
        :param abt_instance: Instance of AnalyticBaseTableJob which will be tested
        """
        self.assertIsNotNone(abt_instance.wtFide117DF)
        self.assertIsNotNone(abt_instance.wtInfoCte543DF)
        self.assertIsNotNone(abt_instance.wtContrato806DF)
        self.assertIsNotNone(abt_instance.wtVmidsatoDF)

    def test_loadTables(self):
        """
        Test the loadTables method, which reads the paths of all of the required tables for the execution of the
        model, which are persisted in HDFS, and create a dataframe for every table required
        Check that every table has been loaded properly
        """
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        self.assert_not_empty_data(test_instance)

    def test_vmidsatoFilters(self):
        """
        Test the vmidsatoFilters method, which generates a new dataframe with data on the VMIDSATO table
        Check that the new dataframe has been loaded properly
        """
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        self.assertIsNotNone(test_instance.wtVmidsatoFilteredDF)

    def test_generateCardLevelVariables(self):
        """
        Test the generateCardLevelVariables method, which generates a new dataframe
        Check that the new dataframe has been loaded properly
        """
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        self.assertIsNotNone(test_instance.cardLevelVariables)

    def test_getTargetsAndRecurrents(self):
        """
        Test the getTargetsAndRecurrents method, which generates a new dataframe
        Check that the new dataframe has been loaded properly
        """
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_instance.getTargetsAndRecurrents()
        self.assertIsNotNone(test_instance.targetsAndRecurrentes)

    def test_addTargetsAndRecurrents(self):
        """
        Test the addTargetsAndRecurrents method, which generates a new dataframe
        Check that the new dataframe has been loaded properly
        """
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_instance.getTargetsAndRecurrents()
        test_instance.addTargetsAndRecurrents()
        self.assertIsNotNone(test_instance.cardLevelVariables)

    def test_getCustomerInformation(self):
        """
        Test the getCustomerInformation method, which generates a new dataframe
        Check that the new dataframe has been loaded properly
        """
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_instance.getTargetsAndRecurrents()
        test_instance.addTargetsAndRecurrents()
        test_instance.getCustomerInformation()
        self.assertIsNotNone(test_instance.customerInformation)

    def test_addCustomerInformation(self):
        """
        Test the addCustomerInformation method, which generates a new dataframe
        Check that the new dataframe has been loaded properly
        """
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_instance.getTargetsAndRecurrents()
        test_instance.addTargetsAndRecurrents()
        test_instance.getCustomerInformation()
        test_instance.addCustomerInformation()
        self.assertIsNotNone(test_instance.cardLevelVariables)

    def test_generateCustomerLevelAggregations(self):
        """
        Test the generateCustomerLevelAggregations method, which generates a new dataframe
        Check that the new dataframe has been loaded properly
        """
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_instance.getTargetsAndRecurrents()
        test_instance.addTargetsAndRecurrents()
        test_instance.getCustomerInformation()
        test_instance.addCustomerInformation()
        test_instance.generateCustomerLevelAggregations()
        self.assertIsNotNone(test_instance.customerLevelVariables)

    def test_getCustomerFinancialInformation(self):
        """
        Test the getCustomerFinancialInformation method, which generates a new dataframe
        Check that the new dataframe has been loaded properly
        """
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_instance.getTargetsAndRecurrents()
        test_instance.addTargetsAndRecurrents()
        test_instance.getCustomerInformation()
        test_instance.addCustomerInformation()
        test_instance.generateCustomerLevelAggregations()
        test_instance.getCustomerFinancialInformation()
        self.assertIsNotNone(test_instance.customerFinancialInformation)

    def test_getPersonalCustomerInformation(self):
        """
        Test the getPersonalCustomerInformation method, which generates a new dataframe
        Check that the new dataframe has been loaded properly
        """
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_instance.getTargetsAndRecurrents()
        test_instance.addTargetsAndRecurrents()
        test_instance.getCustomerInformation()
        test_instance.addCustomerInformation()
        test_instance.generateCustomerLevelAggregations()
        test_instance.getCustomerFinancialInformation()
        test_instance.getPersonalCustomerInformation()
        self.assertIsNotNone(test_instance.personalCustomerInformation)

    def test_createABT(self):
        """
        Test the createABT method, which generates a final dataframe which will be the ABT to persist
        Check that the created ABT has been generated correctly
        """
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_instance.getTargetsAndRecurrents()
        test_instance.addTargetsAndRecurrents()
        test_instance.getCustomerInformation()
        test_instance.addCustomerInformation()
        test_instance.generateCustomerLevelAggregations()
        test_instance.getCustomerFinancialInformation()
        test_instance.getPersonalCustomerInformation()
        test_instance.createABT()
        self.assertIsNotNone(test_instance.abt)

    def test_addColumnToABT(self):
        """
        Test the addColumnToABT method, which appends a column with the execution ID of the job in order to persist
        the ABT into HDFS
        Check that the column has been correctly appended into the ABT
        """
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_instance.getTargetsAndRecurrents()
        test_instance.addTargetsAndRecurrents()
        test_instance.getCustomerInformation()
        test_instance.addCustomerInformation()
        test_instance.generateCustomerLevelAggregations()
        test_instance.getCustomerFinancialInformation()
        test_instance.getPersonalCustomerInformation()
        test_instance.createABT()
        test_abt = test_instance.abt
        test_abt_columns_number = len(test_abt.columns)
        test_expected_columns = len(test_abt.columns)
        self.assertEqual(test_expected_columns, test_abt_columns_number)

    def test_getABT(self):
        """
        Test the getABT method, which returns the processed ABT, which will be loaded into the second module
        Check that the ABT has been generated correctly
        """
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_instance = self.make_abt_instance()
        test_instance.loadTables(test_sql_context)
        test_instance.vmidsatoFilters()
        test_instance.generateCardLevelVariables()
        test_instance.getTargetsAndRecurrents()
        test_instance.addTargetsAndRecurrents()
        test_instance.getCustomerInformation()
        test_instance.addCustomerInformation()
        test_instance.generateCustomerLevelAggregations()
        test_instance.getCustomerFinancialInformation()
        test_instance.getPersonalCustomerInformation()
        test_instance.createABT()
        test_abt = test_instance.getABT()
        self.assertIsNotNone(test_abt)


if __name__ == '__main__':
    unittest.main()
