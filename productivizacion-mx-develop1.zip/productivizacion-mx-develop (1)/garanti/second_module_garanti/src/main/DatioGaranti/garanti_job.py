import sys
import hashlib

from pyspark.sql import HiveContext
from TrainingJob.GarantiTrainingJob import GarantiTrainingJob
from commons.logging_tools import log
import json

""" This is the Job component
    Contains all the logic to execute in order to start and generate the prediction models
"""


class Job:
    """ Constructor method suggested by the IDE
        Args: None
    """
    def __init__(self):
        pass

    """ Execute the Training and Testing Job
        Args: 
            spark: Spark context of the environment
    """
    @staticmethod
    def start(spark):
        log.info("Start Garanti Model")

        # Retrieve and show the path of the configuration file
        confFile = sys.argv[1]
        log.info("configurationFile: " + confFile)
        params = confFile

        # Load the configuration file into a dictionary
        with open(params) as params_json:
            p = json.load(params_json)

        fullArray = p['bines'] + p['commerces']
        fullHash = hashlib.sha256(str(fullArray).encode('utf-8', 'ignore')).hexdigest()
        run_id = str(p['periodMonths']) + str(p['recurrentMonths']) + str(p['targetMonth']) + str(p['targetYear']) + \
                 fullHash

        print("run_id: " + run_id)

        # Retrieve the training and testing models
        garantiTrainingJob = GarantiTrainingJob(p, run_id)
        garantiTrainingJob.loadABT(HiveContext(spark))

        garantiTrainingJob.startTraining()
        trainingPath = garantiTrainingJob.persistModel(spark.sparkContext, "train")

        testedDF = garantiTrainingJob.startTesting()
        testingPath = garantiTrainingJob.persistModelTest(testedDF, "test")

        # Show the storage paths for each model to the user
        print("Training model: " + trainingPath)
        print("Tested model: " + testingPath)
