import unittest

from main.DatioGaranti.TrainingJob.GarantiUtils.InputUtils import InputUtils
from pyspark.mllib.util import MLUtils
from pyspark.mllib.tree import RandomForest, RandomForestModel
from main.DatioGaranti.TrainingJob.AlgorithmAssemble import AlgorithmAssemble
from pyspark.ml.feature import VectorAssembler
from main.DatioGaranti.TrainingJob.spark_utils.readers import parquet
from main.DatioGaranti.commons.init_spark_session import spark_session
from pyspark.sql import functions as f
from pyspark.sql import SQLContext
from pyspark.sql.types import FloatType, StringType


class TestAlgorithmAssemble(unittest.TestCase):

    @staticmethod
    def make_test_instance():
        test_instance = AlgorithmAssemble(InputUtils.ABTColumnId)
        return test_instance

    @staticmethod
    def make_test_dataframe():
        test_sql_context = SQLContext(spark_session().sparkContext)
        test_dataframe = parquet.read_parquet_file(test_sql_context, 'tests/python/data/garanti_abt').dropna('any')
        test_dataframe_2 = test_dataframe.select(InputUtils.ABTInputScheme)
        columnId = InputUtils.ABTColumnId
        columnLabel = InputUtils.ABTColumnLabel
        features = [colName for colName in test_dataframe_2.columns
                    if colName not in [columnId, columnLabel]]
        assembler = VectorAssembler(inputCols=features, outputCol='features')
        dataSetDF = assembler.transform(test_dataframe_2)
        dataSetDF_2 = MLUtils.convertVectorColumnsFromML(dataSetDF, 'features')
        dataSetDF_3 =  dataSetDF_2.withColumn("label", f.col(columnLabel).cast(FloatType()).alias('label'))
        return dataSetDF_3

    def assert_generated_nodes(self, node1, node2):
        self.assertIsNotNone(node1)
        self.assertIsNotNone(node2)

    def test_zipLabelsAndPredictions(self):
        test_instance = self.make_test_instance()
        test_dataframe = self.make_test_dataframe()
        fractions = {0: 1.0, 1: 1.0}
        ratios = [0.6, 0.40]
        stratifiedDataDF = test_dataframe.sampleBy('label', fractions=fractions, seed=12345).cache()
        (trainingDataNode1DF, trainingDataNode2DF) = stratifiedDataDF.randomSplit(ratios, seed=12345)
        trainingDataNode1RDD = trainingDataNode1DF.rdd.map(test_instance.toLabeledPoint)
        trainingDataNode2RDD = trainingDataNode2DF.rdd.map(test_instance.toLabeledPoint)
        randomForestNode1 = RandomForest.trainRegressor(data=trainingDataNode1RDD, categoricalFeaturesInfo={},
                                                        impurity='variance', maxDepth=10, maxBins=70, numTrees=250,
                                                        seed=12345)
        predictionsNode1RDD = randomForestNode1.predict(trainingDataNode2RDD.map(test_instance.getFeatures))
        test_result = test_instance.zipLabelsAndPredictions(trainingDataNode2RDD, predictionsNode1RDD)
        self.assertIsNotNone(test_result)

    def test_fitAssemble(self):
        test_instance = self.make_test_instance()
        test_dataframe = self.make_test_dataframe()
        fractions = {0: 1.0, 1: 1.0}
        ratios = [0.6, 0.40]
        stratifiedDataDF = test_dataframe.sampleBy('label', fractions=fractions, seed=12345).cache()
        (trainingDataNode1DF, trainingDataNode2DF) = stratifiedDataDF.randomSplit(ratios, seed=12345)
        trainingDataNode1RDD = trainingDataNode1DF.rdd.map(test_instance.toLabeledPoint)
        trainingDataNode2RDD = trainingDataNode2DF.rdd.map(test_instance.toLabeledPoint)
        test_node1, test_node2 = test_instance.fitAssemble(trainingDataNode1RDD, trainingDataNode2RDD)
        self.assert_generated_nodes(test_node1, test_node2)
        return None

    def test_fit(self):
        test_instance = self.make_test_instance()
        test_dataframe = self.make_test_dataframe()
        test_result = test_instance.fit(test_dataframe, fractions={0: 1.0, 1: 1.0})
        self.assertIsNotNone(test_result)

    def test_saveRF(self):
        test_instance = self.make_test_instance()
        test_dataframe = self.make_test_dataframe()
        sc = spark_session()
        test_sql_context = SQLContext(sc.sparkContext)
        test_fitted_instance = test_instance.fit(test_dataframe, fractions={0: 1.0, 1: 1.0})
        test_fitted_instance.saveRF(sc.sparkContext, "tests/python/data/mock/garanti/")
        test_node1 = test_fitted_instance.randomForestNode1
        test_node2 = test_fitted_instance.randomForestNode2
        self.assert_generated_nodes(test_node1, test_node2)

    def test_predict(self):
        test_instance = self.make_test_instance()
        test_dataframe = self.make_test_dataframe()
        test_fitted_instance = test_instance.fit(test_dataframe, fractions={0: 1.0, 1: 1.0})
        test_predict_dataframe = test_fitted_instance.predict(test_dataframe)
        self.assertIsNotNone(test_predict_dataframe)


if __name__ == '__main__':
    unittest.main()
