import unittest
from main.DatioGaranti.PredictionJob.GarantiUtils.DateUtils import DateUtils


class TestDateUtils(unittest.TestCase):
    """
    This class execute unit tests to the DateUtils class, included in this module
    """

    @staticmethod
    def make_test_instance():
        """
        Create a dummy instance of Date Utils, required in order to execute this unit tests
        :return: A DateUtils instance
        """
        my_util = DateUtils(2, 2017, 0, 1)
        return my_util

    def assert_expected_date_type(self, date_util):
        """
        Validate the expected date types in the time frame
        :param date_util: A DateUtils instance
        """
        self.assertIsInstance(date_util.yearPredict, int)
        self.assertIsInstance(date_util.monthPredict, int)

    def test_constructor(self):
        """
        Checks the integrity of the data types generated in the constructor method of DateUtils
        """
        test_month_target = 2
        test_year_target = 2017
        test_months_offset = 0
        test_granularity = 1

        test_instance = DateUtils(test_month_target, test_year_target, test_months_offset, test_granularity)

        self.assert_expected_date_type(test_instance)

    def test_yearPredict(self):
        """
        Checks that the training year has been correctly generated
        """
        test_instance = self.make_test_instance()
        self.assertIsInstance(test_instance.yearPredict, int)

    def test_monthPredict(self):
        """
        Checks that the training month has been correctly generated
        """
        test_instance = self.make_test_instance()
        self.assertIsInstance(test_instance.monthPredict, int)


if __name__ == '__main__':
    unittest.main()
