from pyspark.mllib.tree import RandomForestModel
from pyspark.sql.functions import col as c, lit
from datetime import date

""" This is the Algorithm Assemble component
    contains an assemble of ml machine learning nodes (random forest) that computes de probability to 
    belong a binary category
"""


class AlgorithmAssemble:
    """ Constructor: Initializes an AlgorithmAssemble instance
        Args:
            columnId: Sort of primary key for the Dataframe
            threshold: Double that determine the threshold for the fit process
    """
    def __init__(self, columnId, threshold=0.5):
        self.columnId = columnId
        self.threshold = threshold
        self.randomForestNode1 = None
        self.randomForestNode2 = None
        self.randomForestNode1Path = None
        self.randomForestNode2Path = None

    def loadRandomForestNodes(self, sparkContext, path):
        randomForestNode1Path = '/data/master/mpyt/data/garanti/t_mpyt_garanti_tnt/train/' \
                                + path + '/randomForestNode1/'
        randomForestNode2Path = '/data/master/mpyt/data/garanti/t_mpyt_garanti_tnt/train/' \
                                + path + '/randomForestNode2/'

        self.randomForestNode1 = RandomForestModel.load(sparkContext, path=randomForestNode1Path)
        self.randomForestNode2 = RandomForestModel.load(sparkContext, path=randomForestNode2Path)

    """ Function that calculates a behavior prediction given a dataset
        Args:
            datasetToPredictDF: Dataframe with the data to implement in order to give a prediction
        Return a Dataframe with the data of the prediction
    """
    def predict(self, datasetToPredictDF):
        dataSetDF = datasetToPredictDF.select([self.columnId, 'features'])

        predictionsNode1DF = self.randomForestNode1 \
            .predict(dataSetDF.rdd.map(lambda r: r.features)) \
            .zip(dataSetDF.rdd) \
            .map(lambda r: (r[1][0], r[0], r[1][1])) \
            .toDF([self.columnId, 'prediction', 'features'])
        upperlabelsAndPredictionsNode1DF = predictionsNode1DF.select('*').where(c('prediction') >= self.threshold)
        lowerLabelsAndFeaturessNode1DF = predictionsNode1DF.select('*').where(c('prediction') < self.threshold) \
            .select([self.columnId, 'features'])
        predictionsNode2RDD = self.randomForestNode2.predict(lowerLabelsAndFeaturessNode1DF \
                                                             .rdd.map(lambda x: x.features)) \
            .zip(lowerLabelsAndFeaturessNode1DF.rdd) \
            .map(lambda r: (r[1][0], r[0], r[1][1]))

        resultDF =  upperlabelsAndPredictionsNode1DF.rdd.union(predictionsNode2RDD) \
            .map(lambda r: (r[0], float(r[1]), float(r[2][0]))) \
            .toDF([self.columnId, 'prediction', 'recurrent'])

        resultDF = resultDF.withColumn('execution_date', lit(date.today()))
        
        return resultDF
