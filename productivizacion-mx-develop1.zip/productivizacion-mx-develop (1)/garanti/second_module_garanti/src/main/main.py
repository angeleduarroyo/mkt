# coding=utf-8
import importlib
import time

from DatioGaranti.commons.logging_tools import log
from DatioGaranti.commons.init_spark_session import spark_session
from DatioGaranti.garanti_job import Job

""" This is the main script
    Read and load the job script, so it can be executed into a Spark context
"""

if __name__ == "__main__":
    """ Main method for this component
        Args: None
    """
    # SparkSession, config parser and logging object are initiated in commons module
    spark = spark_session()

    # Assign and retrieve the module name
    module_name = "garanti_tnt"
    log.info("module name: " + module_name)

    # Assign and retrieve the job name. This must have the same route value as the Job import
    job_name = 'DatioGaranti.garanti_job'
    log.info("job name: " + job_name)

    # Retrieve the start date and prompt that a job has been initialized
    start = time.time()
    log.info("starting job %s" % module_name)

    # importlib is used to run the module selected in conf. file
    job_module = importlib.import_module(job_name)

    # Start a Job
    garantiJob = Job()
    garantiJob.start(spark)

    # When the job finishes, retrieve the end date, stop the Spark context, and prompt to the user the elapsed time
    end = time.time()
    spark.stop()
    log.info("finished job %s" % module_name)
    log.info("execution of job %s took %s seconds" % (job_module, end - start))
