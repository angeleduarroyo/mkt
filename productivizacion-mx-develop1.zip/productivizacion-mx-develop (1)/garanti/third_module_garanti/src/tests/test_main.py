import unittest
from tests.python.test_algorithmAssemble import TestAlgorithmAssemble
from tests.python.test_analyticBaseTableJob import TestAnalyticBaseTableJob
from tests.python.test_analyticUtils import TestAnalyticUtils
from tests.python.test_dateUtils import TestDateUtils
from tests.python.test_featureTransformer import TestFeatureTransformer
from tests.python.test_garantiPredictionJob import TestGarantiPredictionJob


def suite():
    test_suite = unittest.TestSuite()

    test_suite.addTest(TestAlgorithmAssemble('test_loadRandomForestNodes'))
    test_suite.addTest(TestAlgorithmAssemble('test_predict'))

    test_suite.addTest(TestAnalyticBaseTableJob('test_loadTables'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_vmidsatoFilters'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_generateCardLevelVariables'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_getTargetsAndRecurrents'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_addTargetsAndRecurrents'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_getCustomerInformation'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_addCustomerInformation'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_generateCustomerLevelAggregations'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_getCustomerFinancialInformation'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_getPersonalCustomerInformation'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_createABT'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_addColumnToABT'))
    test_suite.addTest(TestAnalyticBaseTableJob('test_getABT'))

    test_suite.addTest(TestAnalyticUtils('test_parseDates'))

    test_suite.addTest(TestDateUtils('test_constructor'))
    test_suite.addTest(TestDateUtils('test_yearPredict'))
    test_suite.addTest(TestDateUtils('test_monthPredict'))

    test_suite.addTest(TestFeatureTransformer('test_transform'))

    test_suite.addTest(TestGarantiPredictionJob('test_getPredictABT'))
    test_suite.addTest(TestGarantiPredictionJob('test_startTesting'))
    test_suite.addTest(TestGarantiPredictionJob('test_persistModel'))

    return test_suite


if __name__ == '__main__':
    runner = unittest.TextTestRunner()
    runner.run(suite())