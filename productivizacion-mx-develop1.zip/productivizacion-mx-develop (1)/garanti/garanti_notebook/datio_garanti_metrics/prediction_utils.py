from pyspark.sql.functions import round


class PredictionUtils(object):

    def __init__(self, sc, abtHash, tntHash):
        """
            Constructor, initialize all the attribute variables
        """
        sql = sc
        fullPath = '/data/master/mpyt/data/garanti/t_mpyt_garanti_pred/' + abtHash + '/' + tntHash + '/*'
        self.data = sql.read.parquet(fullPath)
        self.customerList = None
        self.customerCount = None
        pass

    def getCustomerList(self, registers=None):
        if registers is None:
            self.customerList = self.data.select("*").orderBy("prediction", ascending=False)
        else:
            self.customerList = self.data.select("*").orderBy("prediction", ascending=False).limit(registers)
        answer = self.customerList.toPandas()
        return answer

    def getCustomerCount(self, per):
        self.customerCount = self.data.select("customer_id", round('prediction', per).alias('predictionR'))
        self.customerCount = self.customerCount.groupBy('predictionR').count().orderBy('predictionR')
        answer = self.customerCount.toPandas()
        return answer

    def savePredictionAsCSV(self, name):
        if self.customerList is None:
            dataOut = self.getCustomerList()
        else:
            dataOut = self.customerList.toPandas()
        fileName = name + ".csv"
        dataOut.to_csv(fileName, index=False)
        return "Customer list saved as: " + fileName

    def getCountCSV(self, name, per):
        dataOut = self.getCustomerCount(per)
        fileName = name + ".csv"
        dataOut.to_csv(fileName, index=False)
        return "Count list saved as: " + fileName
